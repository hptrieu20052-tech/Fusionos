-- v451 · Trạng thái campaign Meta (cron meta-insights cập nhật).
CREATE TABLE IF NOT EXISTS meta_campaigns (
  campaign_id text PRIMARY KEY,
  name text,
  status text,
  updated_at timestamptz DEFAULT now()
);
