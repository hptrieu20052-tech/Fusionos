-- v502 · Templates cho Manage Products WooCommerce (khuôn tạo listing nhanh).
CREATE TABLE IF NOT EXISTS woo_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL,
  name text NOT NULL,
  title text,
  description text,
  price text,
  sale_price text,
  category_ids jsonb NOT NULL DEFAULT '[]',
  tags text,
  status text NOT NULL DEFAULT 'publish',
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_woo_templates_store ON woo_templates (store_id);
