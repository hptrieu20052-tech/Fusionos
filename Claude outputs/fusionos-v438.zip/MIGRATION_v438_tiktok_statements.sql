-- v438 · Kho statement TikTok đồng bộ nền — trang Finance đọc DB, không chờ API.
-- Chạy trên Supabase SQL editor. Idempotent.
CREATE TABLE IF NOT EXISTS tiktok_statements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL,
  statement_id text NOT NULL,
  statement_time bigint NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT '',
  settlement numeric(14,2),
  revenue numeric(14,2),
  fee numeric(14,2),
  adjustment numeric(14,2),
  status text NOT NULL DEFAULT '',
  payment_id text NOT NULL DEFAULT '',
  paid_time bigint NOT NULL DEFAULT 0,
  synced_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_tt_statement ON tiktok_statements(store_id, statement_id);
CREATE INDEX IF NOT EXISTS idx_tt_statement_store ON tiktok_statements(store_id);
CREATE INDEX IF NOT EXISTS idx_tt_statement_time ON tiktok_statements(statement_time);
