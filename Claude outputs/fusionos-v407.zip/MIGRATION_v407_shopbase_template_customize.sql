-- v407 · ShopBase templates: Customize (buyer inputs) — Color/text khách tự chọn, không ăn variants.
-- Chạy trên Supabase SQL editor. Idempotent.
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS personalization jsonb NOT NULL DEFAULT '[]';
