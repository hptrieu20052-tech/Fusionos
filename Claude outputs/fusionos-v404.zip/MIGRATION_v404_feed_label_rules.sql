-- v404 · Feed labels (custom_label_0) quản lý trong FUSION — chạy trên Supabase SQL editor.
CREATE TABLE IF NOT EXISTS feed_label_rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL,
  collection_title text NOT NULL,
  label text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_feed_label_rules_store ON feed_label_rules (store_id);
