-- v507 · Nâng template Woo gần ShopBase: thumbnail mockup + lưu Product Types.
-- Chạy trên Supabase SQL Editor TRƯỚC khi deploy v507 (an toàn chạy lại nhiều lần).
ALTER TABLE woo_templates ADD COLUMN IF NOT EXISTS thumb text;
ALTER TABLE woo_templates ADD COLUMN IF NOT EXISTS wcp_styles jsonb NOT NULL DEFAULT '[]';
