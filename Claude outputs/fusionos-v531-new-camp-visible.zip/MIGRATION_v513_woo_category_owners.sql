-- v513 · Category riêng theo seller trong FUSION ("của ai người đó thấy"):
-- category không có dòng = của admin (mọi seller thấy + dùng);
-- có dòng = riêng seller đó (seller khác không thấy trong chip/filter FUSION).
-- Lưu ý: category vẫn là taxonomy thật trên store Woo.
-- Chạy trên Supabase SQL Editor TRƯỚC khi deploy v513 (an toàn chạy lại nhiều lần).
CREATE TABLE IF NOT EXISTS woo_category_owners (
  store_id    uuid   NOT NULL,
  category_id bigint NOT NULL,
  created_by  uuid,
  created_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (store_id, category_id)
);
