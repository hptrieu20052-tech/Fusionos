-- v512 · Phân quyền Product Type theo người tạo ("của ai người đó thấy" như listing/template):
-- style không có dòng = của admin (mọi seller thấy, không sửa được);
-- style có dòng = của seller đó (seller khác không thấy).
-- Chạy trên Supabase SQL Editor TRƯỚC khi deploy v512 (an toàn chạy lại nhiều lần).
CREATE TABLE IF NOT EXISTS woo_type_owners (
  store_id   uuid NOT NULL,
  style_name text NOT NULL,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (store_id, style_name)
);
