// ============================================================================
//  SHOPIFY PRODUCTS — two-way sync (kéo về + đẩy lên) qua GraphQL Admin API.
//  Dùng cho trang "Manage Products Shopify". REST products đã deprecate → GraphQL.
// ============================================================================
import { shopifyGraphQL, type ShopifyCred } from "@/lib/shopify";

export type SyncedVariant = {
  id: string; title: string; selectedOptions: { name: string; value: string }[];
  price: string; compareAtPrice: string | null; sku: string; barcode: string;
  inventoryItemId: string | null; inventoryQty: number | null;
};
export type SyncedImage = { id: string; src: string; altText: string; position: number };
export type SyncedOption = { name: string; position: number; values: string[] };
export type SyncedProduct = {
  shopifyProductId: string; handle: string; title: string; bodyHtml: string;
  vendor: string; productType: string; tags: string; status: string;
  seoTitle: string; seoDescription: string;
  category: { id: string; name: string } | null; collections: { id: string; title: string }[];
  options: SyncedOption[]; variants: SyncedVariant[]; images: SyncedImage[];
  onlineStoreUrl: string | null; totalInventory: number | null;
};

const money = (v: unknown): string => {
  // GraphQL trả price dạng "9.50" (chuỗi) hoặc {amount}
  if (v == null) return "";
  if (typeof v === "object" && v && "amount" in (v as Record<string, unknown>)) return String((v as { amount: unknown }).amount ?? "");
  return String(v);
};

const PRODUCTS_QUERY = `query Products($cursor: String) {
  products(first: 25, after: $cursor, sortKey: UPDATED_AT, reverse: true) {
    pageInfo { hasNextPage endCursor }
    nodes {
      id handle title descriptionHtml vendor productType status tags totalInventory onlineStoreUrl
      seo { title description }
      category { id fullName }
      collections(first: 30) { nodes { id title } }
      options { name position optionValues { name } }
      media(first: 20) { nodes { ... on MediaImage { id image { url altText } } } }
      variants(first: 100) {
        nodes { id title price compareAtPrice sku barcode inventoryQuantity
                selectedOptions { name value } inventoryItem { id } }
      }
    }
  }
}`;

type RawProduct = {
  id: string; handle?: string; title?: string; descriptionHtml?: string; vendor?: string;
  productType?: string; status?: string; tags?: string[]; totalInventory?: number | null; onlineStoreUrl?: string | null;
  seo?: { title?: string | null; description?: string | null } | null;
  category?: { id?: string; fullName?: string } | null;
  collections?: { nodes?: { id?: string; title?: string }[] } | null;
  options?: { name?: string; position?: number; optionValues?: { name?: string }[] }[];
  media?: { nodes?: { id?: string; image?: { url?: string; altText?: string | null } }[] };
  variants?: { nodes?: Record<string, unknown>[] };
};

function normalize(p: RawProduct): SyncedProduct {
  const options: SyncedOption[] = (p.options ?? []).map((o) => ({
    name: String(o.name ?? ""), position: Number(o.position ?? 0),
    values: (o.optionValues ?? []).map((v) => String(v.name ?? "")).filter(Boolean),
  }));
  const images: SyncedImage[] = (p.media?.nodes ?? []).filter((m) => m?.image?.url).map((m, i) => ({
    id: String(m.id ?? ""), src: String(m.image?.url ?? ""), altText: String(m.image?.altText ?? ""), position: i + 1,
  }));
  const variants: SyncedVariant[] = (p.variants?.nodes ?? []).map((v) => ({
    id: String(v.id ?? ""), title: String(v.title ?? ""),
    selectedOptions: Array.isArray(v.selectedOptions) ? (v.selectedOptions as { name: string; value: string }[]) : [],
    price: money(v.price), compareAtPrice: v.compareAtPrice == null ? null : money(v.compareAtPrice),
    sku: String(v.sku ?? ""), barcode: String(v.barcode ?? ""),
    inventoryItemId: (v.inventoryItem as { id?: string })?.id ?? null,
    inventoryQty: v.inventoryQuantity == null ? null : Number(v.inventoryQuantity),
  }));
  return {
    shopifyProductId: p.id, handle: String(p.handle ?? ""), title: String(p.title ?? ""),
    bodyHtml: String(p.descriptionHtml ?? ""), vendor: String(p.vendor ?? ""), productType: String(p.productType ?? ""),
    tags: (p.tags ?? []).join(", "), status: String(p.status ?? "DRAFT"),
    seoTitle: String(p.seo?.title ?? ""), seoDescription: String(p.seo?.description ?? ""),
    category: p.category?.id ? { id: String(p.category.id), name: String(p.category.fullName ?? "") } : null,
    collections: (p.collections?.nodes ?? []).map((c) => ({ id: String(c.id ?? ""), title: String(c.title ?? "") })).filter((c) => c.id),
    options, variants, images, onlineStoreUrl: p.onlineStoreUrl ?? null,
    totalInventory: p.totalInventory == null ? null : Number(p.totalInventory),
  };
}

// Kéo TOÀN BỘ sản phẩm của store (phân trang). Giới hạn 40 trang (~1000 sp) để an toàn thời gian chạy.
export async function fetchAllShopifyProducts(cred: ShopifyCred, maxPages = 40): Promise<SyncedProduct[]> {
  const out: SyncedProduct[] = [];
  let cursor: string | null = null;
  for (let i = 0; i < maxPages; i++) {
    const data: { products?: { pageInfo?: { hasNextPage?: boolean; endCursor?: string }; nodes?: RawProduct[] } } =
      await shopifyGraphQL(cred, PRODUCTS_QUERY, { cursor });
    const conn = data.products;
    for (const n of conn?.nodes ?? []) out.push(normalize(n));
    if (!conn?.pageInfo?.hasNextPage) break;
    cursor = conn.pageInfo.endCursor ?? null;
    if (!cursor) break;
  }
  return out;
}

// Lấy 1 sản phẩm theo GID (dùng sau khi productSet để đồng bộ lại bản local với variant GID mới).
const ONE_QUERY = `query One($id: ID!) {
  product(id: $id) {
    id handle title descriptionHtml vendor productType status tags totalInventory onlineStoreUrl
    seo { title description }
    category { id fullName }
    collections(first: 30) { nodes { id title } }
    options { name position optionValues { name } }
    media(first: 20) { nodes { ... on MediaImage { id image { url altText } } } }
    variants(first: 100) {
      nodes { id title price compareAtPrice sku barcode inventoryQuantity
              selectedOptions { name value } inventoryItem { id } }
    }
  }
}`;
export async function fetchOneShopifyProduct(cred: ShopifyCred, gid: string): Promise<SyncedProduct | null> {
  const data = await shopifyGraphQL<{ product?: RawProduct | null }>(cred, ONE_QUERY, { id: gid });
  return data.product ? normalize(data.product) : null;
}

// ---- PUSH: đẩy chỉnh sửa local lên Shopify ----
const PRODUCT_UPDATE = `mutation U($product: ProductUpdateInput!) {
  productUpdate(product: $product) { product { id } userErrors { field message } }
}`;
const VARIANTS_UPDATE = `mutation VU($productId: ID!, $variants: [ProductVariantsBulkInput!]!) {
  productVariantsBulkUpdate(productId: $productId, variants: $variants) { userErrors { field message } }
}`;
const MEDIA_DELETE = `mutation MD($productId: ID!, $mediaIds: [ID!]!) {
  productDeleteMedia(productId: $productId, mediaIds: $mediaIds) { deletedMediaIds userErrors { field message } }
}`;
const MEDIA_CREATE = `mutation MC($productId: ID!, $media: [CreateMediaInput!]!) {
  productCreateMedia(productId: $productId, media: $media) { media { id } mediaUserErrors { field message } }
}`;
const MEDIA_REORDER = `mutation MR($id: ID!, $moves: [MoveInput!]!) {
  productReorderMedia(id: $id, moves: $moves) { job { id } mediaUserErrors { field message } userErrors { field message } }
}`;
const MEDIA_LIST = `query M($id: ID!) {
  product(id: $id) { media(first: 50) { nodes { ... on MediaImage { id } } } }
}`;
// v540 · Shopify xử lý media BẤT ĐỒNG BỘ: productCreateMedia trả OK rồi mới tải ảnh về sau.
// Ảnh hỏng/URL không tải được sẽ FAILED trong im lặng → phải poll status để báo cho người dùng.
const MEDIA_STATUS = `query MSt($id: ID!) {
  product(id: $id) { media(first: 50) { nodes { ... on MediaImage { id status mediaErrors { message } } } } }
}`;

type LocalProduct = {
  shopifyProductId: string; title: string; bodyHtml: string | null; tags: string | null;
  status: string; vendor: string | null; productType: string | null;
  seoTitle?: string | null; seoDescription?: string | null;
  variants: SyncedVariant[]; images: SyncedImage[];
};

function ue(arr: unknown): string {
  const a = Array.isArray(arr) ? arr as { message?: string }[] : [];
  return a.map((e) => e.message).filter(Boolean).join("; ");
}

/**
 * Đẩy 1 sản phẩm: cập nhật field sản phẩm + giá/sku từng variant + ảnh (xóa/thêm/sắp xếp).
 * `remoteImages` = ảnh hiện đang có trên Shopify (để tính ảnh nào xóa). Ảnh mới = src http chưa có id GID.
 */
export async function pushProductToShopify(
  cred: ShopifyCred, local: LocalProduct,
): Promise<{ ok: boolean; error?: string; warn?: string }> {
  const pid = local.shopifyProductId;
  // 1) Field sản phẩm
  const r1 = await shopifyGraphQL<{ productUpdate?: { userErrors?: unknown } }>(cred, PRODUCT_UPDATE, {
    product: {
      id: pid, title: local.title, descriptionHtml: local.bodyHtml ?? "",
      status: (local.status || "DRAFT").toUpperCase(),
      vendor: local.vendor ?? undefined, productType: local.productType ?? undefined,
      tags: (local.tags ?? "").split(",").map((t) => t.trim()).filter(Boolean),
      ...((local.seoTitle != null || local.seoDescription != null)
        ? { seo: { title: local.seoTitle ?? "", description: local.seoDescription ?? "" } } : {}),
    },
  });
  const e1 = ue(r1.productUpdate?.userErrors); if (e1) return { ok: false, error: "product: " + e1 };

  // 2) Variants (giá/compare/sku) — chỉ variant có id GID (đã tồn tại trên Shopify)
  const vin = local.variants.filter((v) => v.id?.startsWith("gid://")).map((v) => ({
    id: v.id, price: v.price || "0",
    ...(v.compareAtPrice != null && String(v.compareAtPrice).trim() !== "" ? { compareAtPrice: v.compareAtPrice } : {}),
    ...(v.sku != null ? { inventoryItem: { sku: v.sku } } : {}),
    ...(v.barcode ? { barcode: v.barcode } : {}),
  }));
  if (vin.length) {
    const r2 = await shopifyGraphQL<{ productVariantsBulkUpdate?: { userErrors?: unknown } }>(cred, VARIANTS_UPDATE, { productId: pid, variants: vin });
    const e2 = ue(r2.productVariantsBulkUpdate?.userErrors); if (e2) return { ok: false, error: "variants: " + e2 };
  }

  // 3) Ảnh — truy vấn media HIỆN CÓ trên Shopify để tính ảnh cần xóa (local đã bỏ ảnh nào thì xóa ảnh đó).
  let remoteImageIds: string[] = [];
  try {
    const rl = await shopifyGraphQL<{ product?: { media?: { nodes?: { id?: string }[] } } }>(cred, MEDIA_LIST, { id: pid });
    remoteImageIds = (rl.product?.media?.nodes ?? []).map((n) => String(n.id ?? "")).filter(Boolean);
  } catch { /* nếu lỗi thì bỏ qua bước xóa cho an toàn */ }
  const localIds = new Set(local.images.filter((im) => im.id).map((im) => im.id));
  const toDelete = remoteImageIds.filter((id) => id && !localIds.has(id));
  if (toDelete.length) {
    const rd = await shopifyGraphQL<{ productDeleteMedia?: { userErrors?: unknown } }>(cred, MEDIA_DELETE, { productId: pid, mediaIds: toDelete });
    const ed = ue(rd.productDeleteMedia?.userErrors); if (ed) return { ok: false, error: "delete image: " + ed };
  }
  const toAdd = local.images.filter((im) => !im.id && /^https?:\/\//i.test(im.src));
  let mediaWarn = "";
  if (toAdd.length) {
    const rc = await shopifyGraphQL<{ productCreateMedia?: { media?: { id?: string }[]; mediaUserErrors?: unknown } }>(cred, MEDIA_CREATE, {
      productId: pid, media: toAdd.map((im) => ({ originalSource: im.src, alt: im.altText || undefined, mediaContentType: "IMAGE" })),
    });
    const ec = ue(rc.productCreateMedia?.mediaUserErrors); if (ec) return { ok: false, error: "add image: " + ec };
    // v540 · CHỜ Shopify xử lý ảnh mới (tối đa ~12s): FAILED → báo rõ thay vì im lặng mất ảnh.
    const newIds = (rc.productCreateMedia?.media ?? []).map((m) => String(m?.id ?? "")).filter(Boolean);
    for (let i = 0; i < 6 && newIds.length; i++) {
      await new Promise((res) => setTimeout(res, 2000));
      try {
        const st = await shopifyGraphQL<{ product?: { media?: { nodes?: { id?: string; status?: string; mediaErrors?: { message?: string }[] }[] } } }>(cred, MEDIA_STATUS, { id: pid });
        const nodes = (st.product?.media?.nodes ?? []).filter((n) => newIds.includes(String(n.id ?? "")));
        const failed = nodes.filter((n) => n.status === "FAILED");
        if (failed.length) {
          const msgs = failed.map((n) => (n.mediaErrors ?? []).map((e) => e.message).filter(Boolean).join(", ")).filter(Boolean).join("; ");
          mediaWarn = `${failed.length}/${toAdd.length} image(s) FAILED on Shopify${msgs ? ": " + msgs : " (URL ảnh không tải được?)"}`.slice(0, 200);
          break;
        }
        if (!nodes.some((n) => n.status === "PROCESSING" || n.status === "UPLOADED")) break; // tất cả READY
      } catch { break; /* poll lỗi không chặn — push chính đã xong */ }
    }
  }
  // Sắp xếp: đọc lại media HIỆN CÓ trên Shopify (sau add/delete) để chỉ move GID đang tồn tại —
  // GID cũ/không còn sẽ làm CẢ lệnh reorder lỗi. newPosition 0-based. KHÔNG nuốt lỗi nữa → trả warn.
  let warn: string | undefined;
  let curIds = new Set<string>();
  try {
    const rl2 = await shopifyGraphQL<{ product?: { media?: { nodes?: { id?: string }[] } } }>(cred, MEDIA_LIST, { id: pid });
    curIds = new Set((rl2.product?.media?.nodes ?? []).map((n) => String(n.id ?? "")).filter(Boolean));
  } catch { /* đọc lỗi → bỏ lọc, dùng id local */ }
  const ordered = local.images.filter((im) => im.id && (curIds.size === 0 || curIds.has(im.id)));
  if (ordered.length > 1) {
    const moves = ordered.map((im, i) => ({ id: im.id, newPosition: String(i) }));
    try {
      const rr = await shopifyGraphQL<{ productReorderMedia?: { mediaUserErrors?: unknown; userErrors?: unknown } }>(cred, MEDIA_REORDER, { id: pid, moves });
      const er = ue(rr.productReorderMedia?.mediaUserErrors) || ue(rr.productReorderMedia?.userErrors);
      if (er) warn = "reorder: " + er;
    } catch (e) { warn = "reorder: " + String((e as Error)?.message ?? e).slice(0, 140); }
  }
  const allWarn = [mediaWarn, warn].filter(Boolean).join("; ") || undefined;
  return { ok: true, warn: allWarn };
}
