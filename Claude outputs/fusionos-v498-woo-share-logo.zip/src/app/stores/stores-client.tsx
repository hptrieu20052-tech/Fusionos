"use client";
import { useCallback, useEffect, useState } from "react";
import { Flash } from "@/components/flash";
import { MarketplaceLogo } from "@/components/marketplace-logo";
import { useConfirm } from "@/components/confirm-provider";
import { useLang } from "@/components/lang-provider";
import { IconSettings, IconTrash, IconLink, IconPuzzle, IconRefresh, IconKey, IconDownload, IconWarn, IconCopy, IconStar } from "@/components/icons";

type Store = {
  id: string; name: string; marketplace: string; connectMethod: string; status: string;
  sellerName: string | null; sellerId: string | null; note: string | null; storeUrl: string | null;
  memberIds?: string[];   // v458 · seller được share store (Shopify/ShopBase)
  shop?: { live: boolean; checkFailed: boolean; sales: number | null; rating: number | null; reviews: number | null; listings: number | null; age: string | null; status: number | null; checkedAt: string } | null;
  // feeRate = % phí sàn ƯỚC TÍNH của shop (Etsy & TikTok mặc định 6.5) — sàn không trả phí theo đơn qua API
  currency: string; fxRate: string; feeRate?: string; ingestToken?: string | null; health?: { fxConvertedAt?: string; fxConvertedRate?: number; feeBackfilledAt?: string; feeBackfilledPct?: number } | null;
  orders30d: number; orders7d: number; revenue30d: number; lastOrderDays: number | null;
  live: boolean; hasCredentials: boolean; credentialKeys: string[];
  etsy?: { hasKeystring: boolean; keystring: string; connected: boolean; shopId: string };
  tiktok?: { hasApp: boolean; appKey: string; authLink: string; connected: boolean; shopId: string; shopName: string };
  shopify?: { shopDomain: string; hasApp: boolean; clientId: string };
  shopbase?: { subdomain: string; hasApp: boolean; lastSyncAt: string | null };
  woocommerce?: { storeUrl: string; hasKeys: boolean; lastSyncAt: string | null };
  amazon?: { region: string; marketplaceId: string; sellerId: string; lwaClientId: string; hasSecret: boolean; hasRefresh: boolean; configured: boolean; lastSyncAt: string | null };
};
type Opt = { id: string; name: string };

const MKS: [string, string][] = [["tiktok", "TikTok Shop"], ["amazon", "Amazon"], ["etsy", "Etsy"], ["shopify", "Shopify"], ["shopbase", "ShopBase"], ["woocommerce", "WooCommerce"], ["other", "Other"]];
const CONNECT: [string, string][] = [["extension", "Chrome Extension"], ["api", "API"], ["excel", "Excel Import"]];
const CURRENCIES: [string, string][] = [["USD", "USD ($)"], ["VND", "VND (₫)"], ["EUR", "EUR (€)"], ["GBP", "GBP (£)"], ["AUD", "AUD"], ["CAD", "CAD"], ["JPY", "JPY (¥)"]];
const FX_DEFAULT: Record<string, number> = { VND: 25400, EUR: 0.92, GBP: 0.79, AUD: 1.5, CAD: 1.36, JPY: 157 };
const MK_COLOR: Record<string, string> = { tiktok: "#25242A", amazon: "#FF9900", etsy: "#F1641E", shopify: "#5E8E3E", shopbase: "#2F6BFF", woocommerce: "#7F54B3", other: "#66788E" };
const money = (n: number) => "$" + (Math.round(n * 100) / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
// Field credentials theo từng sàn
const CRED_FIELDS: Record<string, [string, string][]> = {
  tiktok: [["app_key", "App Key"], ["app_secret", "App Secret"], ["access_token", "Access Token"], ["shop_id", "Shop ID"]],
  amazon: [["seller_id", "Seller ID"], ["mws_token", "MWS Auth Token"], ["access_key", "Access Key"], ["secret_key", "Secret Key"]],
  etsy: [["api_key", "API Key"], ["shared_secret", "Shared Secret"], ["oauth_token", "OAuth Token"], ["shop_id", "Shop ID"]],
  other: [["endpoint", "Endpoint"], ["token", "Token"]],
};

export function StoresClient({ canAdd, role }: { canAdd: boolean; role: string }) {
  const { t } = useLang();
  const confirm = useConfirm();
  const [stores, setStores] = useState<Store[]>([]);
  const [sellers, setSellers] = useState<Opt[]>([]);
  const [scoped, setScoped] = useState(false);
  const [fSeller, setFSeller] = useState(""); const [fMk, setFMk] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [edit, setEdit] = useState<Store | null>(null);
  const [msg, setMsg] = useState("");

  const load = useCallback(() => {
    const p = new URLSearchParams();
    if (fSeller) p.set("sellerId", fSeller);
    if (fMk) p.set("marketplace", fMk);
    fetch(`/api/stores?${p}`).then((r) => r.json()).then((j) => { if (j.ok) { setStores(j.stores); setSellers(j.sellers); setScoped(!!j.scoped); } });
  }, [fSeller, fMk]);
  useEffect(() => { load(); }, [load]);
  const flash = (m: string) => { setMsg(m); setTimeout(() => setMsg(""), 2500); };
  // Kết quả OAuth Etsy chuyển hướng về ?etsy=ok/err&msg=...
  useEffect(() => {
    const q = new URLSearchParams(window.location.search);
    const e = q.get("etsy");
    if (e) {
      setMsg((e === "ok" ? "✓ " : "✗ ") + (q.get("msg") || ""));
      setTimeout(() => setMsg(""), 4000);
      window.history.replaceState({}, "", "/stores");
    }
  }, []);

  const delStore = async (s: Store) => {
    if (!(await confirm({ message: t("st.deleteConfirm").replace("{name}", s.name), danger: true }))) return;
    const j = await fetch(`/api/stores/${s.id}`, { method: "DELETE" }).then((r) => r.json());
    if (j.ok) { flash(t("st.deletedStore")); load(); } else flash("✗ " + (j.error ?? t("st.error")));
  };

  const byMk = (mk: string) => stores.filter((s) => s.marketplace === mk);
  const total30 = stores.reduce((a, s) => a + s.revenue30d, 0);

  return (
    <>
      <Flash msg={msg} />

      {/* Page head */}
      <div className="page-head">
        <div className="page-actions">
          {canAdd && <button onClick={() => setShowAdd(true)} className="btn btn-primary">{t("s.addStore")}</button>}
        </div>
      </div>

      {/* Filter */}
      <div className="card" style={{ padding: "16px 18px", marginBottom: 14 }}>
        <div className="filters">
          {!(scoped && sellers.length <= 1) && (
          <div className="field">
            <label>{t("c.seller")}</label>
            <select value={fSeller} onChange={(e) => setFSeller(e.target.value)}>
              <option value="">All</option>
              {sellers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          )}
          <div className="field">
            <label>{t("c.marketplace")}</label>
            <select value={fMk} onChange={(e) => setFMk(e.target.value)}>
              <option value="">All</option>
              {MKS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </select>
          </div>
          <div className="field">
            <label>{t("s.totalRev30")}</label>
            <div style={{ padding: "9px 0", fontWeight: 800, fontSize: 16, color: "var(--green)" }}>{money(total30)}</div>
          </div>
        </div>
      </div>

      {/* Cột theo sàn */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(300px,1fr))", gap: 16 }}>
        {MKS.map(([mk, label]) => {
          const list = byMk(mk);
          return (
            <div key={mk} className="card" style={{ padding: 16, borderTop: `3px solid ${MK_COLOR[mk] ?? "#66788E"}` }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
                <MarketplaceLogo mk={mk} size={26} />
                <b style={{ fontSize: 15 }}>{label}</b>
                <span style={{ marginLeft: "auto", fontSize: 12, color: "var(--muted)", fontWeight: 700 }}>{list.length}</span>
              </div>
              {list.length === 0 && <div style={{ color: "var(--faint)", fontSize: 13, textAlign: "center", padding: "20px 0" }}>{t("s.empty")}</div>}
              {list.map((s) => (
                <div key={s.id} style={{ border: "1px solid var(--line)", borderLeft: `3px solid ${s.live ? "var(--green)" : "var(--red)"}`, borderRadius: 12, padding: "12px 14px", marginBottom: 10, transition: "border-color .15s" }}
                  onMouseEnter={(e) => { if (canAdd) { e.currentTarget.style.borderColor = "var(--accent)"; e.currentTarget.style.borderLeftColor = s.live ? "var(--green)" : "var(--red)"; } }}
                  onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--line)"; e.currentTarget.style.borderLeftColor = s.live ? "var(--green)" : "var(--red)"; }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 5 }}>
                    <b style={{ fontSize: 14 }}>{s.name}</b>
                    {/* Badge LIVE/DIE = có đơn trong 7 ngày hay không. Không dò được suspend nữa
                        (extension chỉ đọc DOM trang seller tự mở, không fetch gì) — nhưng shop bị khoá
                        thì seller không vào được Shop Manager → số liệu đứng yên → badge "stale" bên dưới. */}
                    <span style={{ display: "inline-flex", alignItems: "center", gap: 5, fontSize: 11, fontWeight: 700, padding: "2px 9px", borderRadius: 999,
                      background: s.live ? "var(--green-soft)" : "var(--red-soft)", color: s.live ? "var(--green)" : "var(--red)" }}>
                      <span style={{ width: 7, height: 7, borderRadius: "50%", background: s.live ? "var(--green)" : "var(--red)" }} />
                      {s.live ? t("s.live") : t("s.die")}
                    </span>
                    {canAdd && (
                      <span style={{ marginLeft: "auto", display: "inline-flex", gap: 4 }}>
                        {s.storeUrl && <a href={s.storeUrl} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="st-iconbtn" title={t("st.openShop")}><IconLink width={14} height={14} /></a>}
                        <button onClick={() => setEdit(s)} className="st-iconbtn" title={t("st.editStore")}><IconSettings width={15} height={15} /></button>
                        <button onClick={() => delStore(s)} className="st-iconbtn danger" title={t("st.deleteStore")}><IconTrash width={14} height={14} /></button>
                      </span>
                    )}
                  </div>
                  {/* Hàng 1: số liệu công khai của shop (extension đọc hộ, 1 lần/ngày) */}
                  {s.shop && (
                    <div style={{ fontSize: 12, color: "var(--muted)", marginBottom: 3, display: "flex", alignItems: "center", gap: 5, flexWrap: "wrap" }}>
                      {s.shop.rating != null && (
                        <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>
                          <IconStar width={12} height={12} style={{ color: "#F5A623" }} />
                          <b style={{ color: "var(--ink)" }}>{s.shop.rating}</b>
                          {s.shop.reviews != null && <span>({s.shop.reviews})</span>}
                        </span>
                      )}
                      {s.shop.sales != null && <>·<span><b style={{ color: "var(--ink)" }}>{s.shop.sales.toLocaleString()}</b> sales</span></>}
                      {s.shop.listings != null && <>·<span><b style={{ color: "var(--ink)" }}>{s.shop.listings.toLocaleString()}</b> listings</span></>}
                      {s.shop.age && <>·<span>{s.shop.age}</span></>}
                      {(() => {
                        const days = Math.floor((Date.now() - Date.parse(s.shop!.checkedAt)) / 86400000);
                        // Seller không mở Shop Manager quá 7 ngày → số liệu cũ.
                        // Nếu kéo dài, rất có thể shop đã bị khoá (seller không vào được nữa).
                        return days > 7 ? (
                          <span style={{ color: "var(--red)", fontWeight: 700 }} title={`Last read from Shop Manager on ${new Date(s.shop!.checkedAt).toLocaleString()}`}>
                            · {days}d stale
                          </span>
                        ) : null;
                      })()}
                    </div>
                  )}
                  {/* Hàng 2: seller + số đơn/doanh thu 30 ngày (từ DB của mình) */}
                  <div style={{ fontSize: 13, color: "var(--muted)" }}>
                    {s.sellerName ?? "—"} · <b style={{ color: "var(--ink)" }}>{s.orders30d}</b> orders · <b style={{ color: "var(--green)" }}>{money(s.revenue30d)}</b> / 30d
                  </div>
                  {s.lastOrderDays != null && s.lastOrderDays > 7 && (
                    <div style={{ fontSize: 11, color: "var(--red)", marginTop: 3 }}>⚠ {s.lastOrderDays} days without orders</div>
                  )}
                </div>
              ))}
            </div>
          );
        })}
      </div>

      {showAdd && <AddStoreModal sellers={sellers} isSeller={role === "seller"} close={() => setShowAdd(false)} reload={load} flash={flash} />}
      {edit && <EditStoreModal store={edit} sellers={sellers} isSeller={role === "seller"} close={() => setEdit(null)} reload={load} flash={flash} />}
    </>
  );
}

function AddStoreModal({ sellers, isSeller, close, reload, flash }: { sellers: Opt[]; isSeller: boolean; close: () => void; reload: () => void; flash: (m: string) => void }) {
  const { t } = useLang();
  const [f, setF] = useState({ name: "", marketplace: "tiktok", connectMethod: "extension", sellerId: "", note: "", storeUrl: "", currency: "USD", fxRate: "1", feeRate: "6.5" });
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    if (!f.name.trim()) return;
    setBusy(true);
    try {
      const r = await fetch("/api/stores", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
      const j = await r.json().catch(() => ({ ok: false, error: `HTTP ${r.status}` }));
      if (j.ok) { flash(t("st.addedStore")); reload(); close(); return; }
      flash("✗ " + (j.error ?? "Error"));
    } catch (e) { flash("✗ " + (e as Error).message); }
    setBusy(false);
  };
  return (
    <Modal title={t("st.addStoreNew")} close={close}>
      <L label={t("st.storeName")}><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="VD: gymwear.us" style={inp} /></L>
      <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <L label={t("st.marketplace")}><select value={f.marketplace} onChange={(e) => { const mk = e.target.value; setF({ ...f, marketplace: mk, connectMethod: (mk === "shopify" || mk === "shopbase" || mk === "woocommerce") ? "api" : f.connectMethod }); }} style={inp}>{MKS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></L>
      </div>
      {!isSeller && <L label={t("st.seller")}><select value={f.sellerId} onChange={(e) => setF({ ...f, sellerId: e.target.value })} style={inp}><option value="">—</option>{sellers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></L>}
      <L label={t("st.linkShop")}><input value={f.storeUrl} onChange={(e) => setF({ ...f, storeUrl: e.target.value })} placeholder="https://shop.tiktok.com/@yourshop" style={inp} /></L>
      {f.marketplace === "etsy" && (
        <div style={{ fontSize: 12, color: "var(--muted)", background: "var(--blue-soft)", border: "1px solid var(--line)", borderRadius: 10, padding: "8px 12px", margin: "2px 0 4px", lineHeight: 1.55 }}>
          New Etsy shops (0–100 sales) usually can&apos;t get an API key yet — pull orders with the{" "}
          <a href="/extension/" target="_blank" rel="noreferrer" style={{ color: "var(--blue)", fontWeight: 700 }}>FUSION Order Sync extension</a>{" "}
          instead. Once the shop has its own Etsy API approved, copy the connect link, open it in the shop's own browser profile, and orders switch to the official API.
        </div>
      )}
      {f.marketplace === "shopify" && (
        <div style={{ fontSize: 12, color: "var(--muted)", background: "#F3FBF6", border: "1px solid #CDEFD8", borderRadius: 10, padding: "8px 12px", margin: "2px 0 4px", lineHeight: 1.55 }}>
          Create the store first, then open its <b>Settings</b> to enter the Shopify app <b>Shop domain</b>, <b>Client ID</b> and <b>Client Secret</b>, check the connection and register webhooks. Orders then flow into FUSION automatically.
        </div>
      )}
      {f.marketplace === "shopbase" && (
        <div style={{ fontSize: 12, color: "var(--muted)", background: "#EEF3FF", border: "1px solid #CBD9FF", borderRadius: 10, padding: "8px 12px", margin: "2px 0 4px", lineHeight: 1.55 }}>
          Create the store first, then open its <b>Settings</b> to enter the ShopBase <b>Subdomain</b> ({"{store}"}.onshopbase.com), private-app <b>API key</b> and <b>Password</b>, check the connection, then <b>Sync orders</b>. Orders flow into the same stats as Shopify.
        </div>
      )}
      {f.marketplace === "woocommerce" && (
        <div style={{ fontSize: 12, color: "var(--muted)", background: "#F4EFFB", border: "1px solid #DCCDF2", borderRadius: 10, padding: "8px 12px", margin: "2px 0 4px", lineHeight: 1.55 }}>
          Create the store first, then open its <b>Settings</b> to enter the <b>Store URL</b> and a WooCommerce REST API <b>Consumer key/secret</b> (WooCommerce → Settings → Advanced → REST API → Add key, permission <b>Read</b>), check the connection, then <b>Sync orders</b>. Orders also auto-sync every cron tick.
        </div>
      )}
      <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <L label={t("st.shopCurrency")}><select value={f.currency} onChange={(e) => { const cur = e.target.value; setF({ ...f, currency: cur, fxRate: cur === "USD" ? "1" : (f.fxRate === "1" ? String(FX_DEFAULT[cur] ?? "") : f.fxRate) }); }} style={inp}>{CURRENCIES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></L>
        <L label={t("st.fxLabel").replace("{cur}", f.currency)}><input type="number" step="0.0001" value={f.fxRate} disabled={f.currency === "USD"} onChange={(e) => setF({ ...f, fxRate: e.target.value })} placeholder="vd 25400" style={{ ...inp, background: f.currency === "USD" ? "#EDEFF4" : "#fff" }} /></L>
      </div>
      {/* Fee (est.) — sàn không trả phí theo đơn qua API nên hệ thống ước tính theo % này */}
      <L label={t("st.feeLabel")}><input type="number" step="0.1" min="0" max="99" value={f.feeRate} onChange={(e) => setF({ ...f, feeRate: e.target.value })} placeholder="6.5" style={inp} /></L>
      <div style={{ fontSize: 11.5, color: "var(--muted)", lineHeight: 1.5, margin: "-2px 0 2px" }}>{t("st.feeHint")}</div>
      <L label={t("st.note")}><input value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} style={inp} /></L>
      <Actions close={close} onOk={submit} busy={busy} okLabel={t("st.addStore")} disabled={!f.name.trim()} />
    </Modal>
  );
}

function EditStoreModal({ store, sellers, isSeller, close, reload, flash }: { store: Store; sellers: Opt[]; isSeller: boolean; close: () => void; reload: () => void; flash: (m: string) => void }) {
  const { t } = useLang();
  const confirm = useConfirm();
  const [f, setF] = useState({ name: store.name, sellerId: store.sellerId ?? "", status: store.status, connectMethod: store.connectMethod, note: store.note ?? "", storeUrl: store.storeUrl ?? "", currency: store.currency ?? "USD", fxRate: store.fxRate ?? "1", feeRate: store.feeRate ?? "6.5" });
  const [cred, setCred] = useState<Record<string, string>>({});
  // v458 · SHARE STORE (chỉ Shopify/ShopBase): danh sách seller được thấy + dùng store này.
  const canShare = !isSeller && (store.marketplace === "shopify" || store.marketplace === "shopbase" || store.marketplace === "woocommerce"); // v498 · Woo share được cho nhiều seller
  const [members, setMembers] = useState<string[]>(store.memberIds ?? []);
  const [memPick, setMemPick] = useState("");
  const [busy, setBusy] = useState(false);
  const [health, setHealth] = useState<{ ok: boolean; message: string } | null>(null);
  const [tok, setTok] = useState(store.ingestToken ?? "");
  const [showTok, setShowTok] = useState(false);
  const regenToken = async () => {
    if (!(await confirm({ title: t("st.newToken"), message: t("st.newTokenConfirm"), danger: true, confirmText: t("st.create") }))) return;
    const j = await fetch(`/api/stores/${store.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ regenIngestToken: true }) }).then((r) => r.json());
    if (j.ok && j.ingestToken) { setTok(j.ingestToken); flash(t("st.tokenCreated")); } else flash(t("st.tokenErr"));
  };
  const ingestUrl = typeof window !== "undefined" ? `${window.location.origin}/api/ingest/etsy` : "/api/ingest/etsy";
  // Domain CHUẨN cho callback — không dùng window.origin vì mở qua *.vercel.app sẽ hiện sai URL đăng ký
  const CANONICAL = "https://os.fusiondn.com";
  const oauthCb = `${CANONICAL}/api/etsy/oauth/callback`;
  const [etsyKey, setEtsyKey] = useState(store.etsy?.keystring ?? "");
  const [etsySecret, setEtsySecret] = useState("");
  const [etsyBusy, setEtsyBusy] = useState(false);
  const [etsySaved, setEtsySaved] = useState(false);
  const [roEtsy, setRoEtsy] = useState(true); // readonly lúc mở để chặn Chrome autofill, bỏ khi focus
  const saveEtsyApi = async () => {
    if (!etsyKey.trim() || !etsySecret.trim()) { flash("✗ Enter Keystring + Shared Secret"); return; }
    setEtsyBusy(true);
    const j = await fetch("/api/etsy/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id, keystring: etsyKey.trim(), sharedSecret: etsySecret.trim() }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setEtsyBusy(false);
    if (j.ok) { flash("✓ Etsy app saved — now Copy connect link and open it in the shop's browser profile"); setEtsySaved(true); reload(); } else flash("✗ " + (j.error ?? "Error"));
  };
  // Copy link authorize Etsy → dán vào AdsPower nơi shop đang login.
  // PKCE verifier lưu server-side theo `state`, nên KHÔNG cần đăng nhập Fusion OS trong AdsPower.
  const etsyConnectLink = async () => {
    setEtsyBusy(true);
    const j = await fetch(`/api/etsy/oauth/start?storeId=${store.id}&copy=1`).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setEtsyBusy(false);
    if (!j.ok) { flash("✗ " + (j.error ?? "Error")); return; }
    navigator.clipboard?.writeText(j.url);
    flash("✓ Connect link copied — paste it into the shop's AdsPower browser and Authorize (valid 10 min)");
  };
  // ===== TikTok Shop API =====
  const [ttKey, setTtKey] = useState(store.tiktok?.appKey ?? "");
  const [ttSecret, setTtSecret] = useState("");
  const [ttAuthLink, setTtAuthLink] = useState(store.tiktok?.authLink ?? "");
  const [ttBusy, setTtBusy] = useState(false);
  const [ttSaved, setTtSaved] = useState(false); // Connect sáng ngay sau Save app, khỏi mở lại modal
  const [ttLive, setTtLive] = useState<{ connected: boolean; shopName?: string } | null>(null); // Check connection cập nhật badge tại chỗ
  const saveTtApi = async () => {
    if (!ttKey.trim() || !ttSecret.trim()) { flash("✗ Enter App Key + App Secret"); return; }
    setTtBusy(true);
    const j = await fetch("/api/tiktok/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id, appKey: ttKey.trim(), appSecret: ttSecret.trim(), authLink: ttAuthLink.trim() }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setTtBusy(false);
    if (j.ok) { flash("✓ TikTok app saved — now Copy connect link and open it in the shop’s browser profile"); setTtSaved(true); reload(); } else flash("✗ " + (j.error ?? "Error"));
  };
  // Link authorize tĩnh (TikTok không PKCE) → copy dán vào browser AdsPower của shop là đúng bài.
  // state PHẢI có tiền tố "sto_" để theyourlist forward code về os.fusiondn.com/api/tiktokshops/auth.
  const ttConnectLink = () => {
    const base = ttAuthLink.trim() || store.tiktok?.authLink || "";
    if (!base) { flash("✗ Save the Authorization link first"); return; }
    const link = `${base}${base.includes("?") ? "&" : "?"}state=sto_${store.id}`;
    navigator.clipboard?.writeText(link);
    flash("✓ Connect link copied — paste it into the shop's AdsPower browser and Authorize");
  };
  const checkTt = async () => {
    setTtBusy(true);
    const j = await fetch("/api/tiktok/check", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setTtBusy(false);
    if (j.ok) {
      const nm = (j.shops ?? []).map((x: { name: string }) => x.name).join(", ");
      setTtLive({ connected: true, shopName: nm || store.tiktok?.shopName || store.tiktok?.shopId });
      flash(`✓ Connection OK — ${nm || "authorized"}`);
    } else flash("✗ " + (j.error ?? "Error"));
  };
  // Trạng thái hiển thị: ưu tiên kết quả Check connection vừa chạy, chưa có thì lấy prop từ server.
  const ttConnected = ttLive?.connected ?? store.tiktok?.connected ?? false;
  const ttName = ttLive?.shopName || store.tiktok?.shopName || store.tiktok?.shopId;
  const pullEtsy = async () => {
    setEtsyBusy(true);
    const j = await fetch("/api/etsy/pull", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setEtsyBusy(false);
    if (j.ok) { flash(`✓ ${j.received} orders — created ${j.created}, skipped ${j.skipped}`); reload(); } else flash("✗ " + (j.error ?? "Error"));
  };
  // ===== Shopify API (app Dev Dashboard: Client ID + Client Secret → token client_credentials) =====
  const [shDomain, setShDomain] = useState(store.shopify?.shopDomain ?? "");
  const [shClientId, setShClientId] = useState(store.shopify?.clientId ?? "");
  const [shSecret, setShSecret] = useState("");
  const [shBusy, setShBusy] = useState(false);
  const [shSaved, setShSaved] = useState(store.shopify?.hasApp ?? false);
  const [shCheck, setShCheck] = useState<{ ok: boolean; text: string } | null>(null);
  const saveShopify = async () => {
    if (!shDomain.trim() || !shClientId.trim() || (!shSecret.trim() && !store.shopify?.hasApp)) {
      flash("✗ Enter Shop domain + Client ID + Client Secret"); return;
    }
    setShBusy(true);
    const j = await fetch("/api/shopify/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id, shopDomain: shDomain.trim(), clientId: shClientId.trim(), clientSecret: shSecret.trim() }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setShBusy(false);
    if (j.ok) { flash("✓ Shopify app saved — now Check connection"); setShSaved(true); setShSecret(""); reload(); } else flash("✗ " + (j.error ?? "Error"));
  };
  const checkShopify = async () => {
    setShBusy(true); setShCheck(null);
    const j = await fetch("/api/shopify/check", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setShBusy(false);
    if (j.ok) { setShCheck({ ok: true, text: `${j.shopName || "shop"} · ${j.myshopifyDomain || ""}${j.currency ? " · " + j.currency : ""}` }); flash("✓ Connected: " + (j.shopName || j.myshopifyDomain)); }
    else { setShCheck({ ok: false, text: j.error ?? "Error" }); flash("✗ " + (j.error ?? "Error")); }
  };
  const registerShopifyHooks = async () => {
    setShBusy(true);
    const j = await fetch("/api/shopify/register-webhooks", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setShBusy(false);
    const r0 = (j.results ?? [])[0] as { ok?: boolean; error?: string; topics?: string[] } | undefined;
    if (j.ok) { setShCheck({ ok: true, text: "Webhooks: " + ((r0?.topics ?? []).join(", ") || "registered") }); flash("✓ Webhooks registered"); }
    else { setShCheck({ ok: false, text: r0?.error ?? j.error ?? "Error" }); flash("✗ " + (r0?.error ?? j.error ?? "Error")); }
  };

  // ===== ShopBase (private app · Basic auth). Config lưu ở store.api_credentials.shopbase =====
  const [sbSubdomain, setSbSubdomain] = useState(store.shopbase?.subdomain ?? "");
  const [sbApiKey, setSbApiKey] = useState("");
  const [sbPassword, setSbPassword] = useState("");
  const [sbBusy, setSbBusy] = useState(false);
  const [sbSaved, setSbSaved] = useState(store.shopbase?.hasApp ?? false);
  const [sbCheck, setSbCheck] = useState<{ ok: boolean; text: string } | null>(null);
  const saveShopbase = async () => {
    if (!sbSubdomain.trim() || (!sbApiKey.trim() && !store.shopbase?.hasApp) || (!sbPassword.trim() && !store.shopbase?.hasApp)) {
      flash("✗ Enter Subdomain + API key + Password"); return;
    }
    setSbBusy(true);
    const j = await fetch("/api/shopbase/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id, subdomain: sbSubdomain.trim(), apiKey: sbApiKey.trim(), password: sbPassword.trim() }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setSbBusy(false);
    if (j.ok) { flash("✓ ShopBase saved — now Check connection"); setSbSaved(true); setSbApiKey(""); setSbPassword(""); reload(); } else flash("✗ " + (j.error ?? "Error"));
  };
  const checkShopbase = async () => {
    setSbBusy(true); setSbCheck(null);
    const j = await fetch("/api/shopbase/check", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setSbBusy(false);
    if (j.ok) { setSbCheck({ ok: true, text: `${j.shopName || "shop"} · ${j.domain || ""}${j.currency ? " · " + j.currency : ""}` }); flash("✓ Connected: " + (j.shopName || j.domain)); }
    else { setSbCheck({ ok: false, text: j.error ?? "Error" }); flash("✗ " + (j.error ?? "Error")); }
  };
  const syncShopbase = async () => {
    setSbBusy(true);
    const j = await fetch("/api/shopbase/sync-orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setSbBusy(false);
    if (j.ok) { setSbCheck({ ok: true, text: `Synced ${j.fetched ?? 0} fetched · ${j.created ?? 0} new · ${j.updated ?? 0} updated` }); flash(`✓ ShopBase orders synced (${j.created ?? 0} new)`); reload(); }
    else { setSbCheck({ ok: false, text: j.error ?? "Error" }); flash("✗ " + (j.error ?? "Error")); }
  };

  // ===== WooCommerce (REST API key). Config lưu ở store.api_credentials.woocommerce =====
  const [wcUrl, setWcUrl] = useState(store.woocommerce?.storeUrl ?? "");
  const [wcKey, setWcKey] = useState("");
  const [wcSecret, setWcSecret] = useState("");
  const [wcBusy, setWcBusy] = useState(false);
  const [wcSaved, setWcSaved] = useState(store.woocommerce?.hasKeys ?? false);
  const [wcCheck, setWcCheck] = useState<{ ok: boolean; text: string } | null>(null);
  const saveWoo = async () => {
    if (!wcUrl.trim() || (!wcKey.trim() && !store.woocommerce?.hasKeys) || (!wcSecret.trim() && !store.woocommerce?.hasKeys)) {
      flash("✗ Enter Store URL + Consumer key + Consumer secret"); return;
    }
    setWcBusy(true);
    const j = await fetch("/api/woocommerce/config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id, storeUrl: wcUrl.trim(), consumerKey: wcKey.trim(), consumerSecret: wcSecret.trim() }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setWcBusy(false);
    if (j.ok) { flash("✓ WooCommerce saved — now Check connection"); setWcSaved(true); setWcKey(""); setWcSecret(""); reload(); } else flash("✗ " + (j.error ?? "Error"));
  };
  const checkWoo = async () => {
    setWcBusy(true); setWcCheck(null);
    const j = await fetch("/api/woocommerce/check", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setWcBusy(false);
    if (j.ok) { setWcCheck({ ok: true, text: `${j.shopName || "site"} · ${j.domain || ""}` }); flash("✓ Connected: " + (j.shopName || j.domain)); }
    else { setWcCheck({ ok: false, text: j.error ?? "Error" }); flash("✗ " + (j.error ?? "Error")); }
  };
  const syncWoo = async () => {
    setWcBusy(true);
    const j = await fetch("/api/woocommerce/sync-orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ storeId: store.id }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setWcBusy(false);
    if (j.ok) { setWcCheck({ ok: true, text: `Synced ${j.fetched ?? 0} fetched · ${j.created ?? 0} new · ${j.updated ?? 0} updated` }); flash(`✓ WooCommerce orders synced (${j.created ?? 0} new)`); reload(); }
    else { setWcCheck({ ok: false, text: j.error ?? "Error" }); flash("✗ " + (j.error ?? "Error")); }
  };

  // ===== Amazon SP-API (LWA — không cần AWS IAM/SigV4). Config lưu ở store.api_credentials.spapi =====
  const [azRegion, setAzRegion] = useState(store.amazon?.region ?? "na");
  const [azMkId, setAzMkId] = useState(store.amazon?.marketplaceId ?? "ATVPDKIKX0DER");
  const [azSeller, setAzSeller] = useState(store.amazon?.sellerId ?? "");
  const [azClientId, setAzClientId] = useState(store.amazon?.lwaClientId ?? "");
  const [azSecret, setAzSecret] = useState("");
  const [azRefresh, setAzRefresh] = useState("");
  const [azBusy, setAzBusy] = useState(false);
  const [azSaved, setAzSaved] = useState(store.amazon?.configured ?? false);
  const [azCheck, setAzCheck] = useState<{ ok: boolean; text: string } | null>(null);
  const azBody = () => ({
    storeId: store.id, region: azRegion, marketplaceId: azMkId.trim(), sellerId: azSeller.trim(),
    lwaClientId: azClientId.trim(), lwaClientSecret: azSecret.trim(), refreshToken: azRefresh.trim(),
  });
  const saveAmazon = async (test: boolean) => {
    setAzBusy(true); setAzCheck(null);
    const j = await fetch("/api/amazon-config", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...azBody(), test }) }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setAzBusy(false);
    if (!j.ok) { flash("✗ " + (j.error ?? "Error")); return; }
    setAzSaved(true); setAzSecret(""); setAzRefresh("");
    if (test) {
      if (j.test === "ok") { setAzCheck({ ok: true, text: "Connected to Amazon SP-API" }); flash("✓ SP-API connected"); }
      else { setAzCheck({ ok: false, text: j.error ?? "Connection failed" }); flash("✗ " + (j.error ?? "Connection failed")); }
    } else flash("✓ SP-API saved");
    reload();
  };

  const fields = CRED_FIELDS[store.marketplace] ?? CRED_FIELDS.other;

  const save = async () => {
    setBusy(true);
    const body: Record<string, unknown> = { ...f };
    if (canShare) body.memberIds = members;   // v458
    if (Object.keys(cred).length) body.credentials = cred;
    try {
      const r = await fetch(`/api/stores/${store.id}`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const j = await r.json().catch(() => ({ ok: false, error: `HTTP ${r.status}` }));
      if (j.ok) { flash(t("st.savedStore")); reload(); close(); return; }
      flash("✗ " + (j.error ?? "Error"));
    } catch (e) { flash("✗ " + (e as Error).message); }
    setBusy(false);
  };
  const check = async () => {
    setBusy(true);
    const j = await fetch(`/api/stores/${store.id}`, { method: "POST" }).then((r) => r.json());
    setBusy(false);
    if (j.ok) setHealth(j.health);
  };
  async function fxConvert() {
    const rate = Number(store.fxRate);
    if (!(rate > 1)) { flash(t("st.fxNeedRate")); return; }
    const already = store.health?.fxConvertedAt;
    const warn = t("st.fxConfirmBody").replace("{name}", store.name).replace("{rate}", String(rate)) + (already ? t("st.fxConfirmRedo").replace("{time}", new Date(already).toLocaleString()) : "");
    if (!(await confirm({ title: t("st.fxConvertTitle"), message: warn, danger: true, confirmText: t("st.fxConvert"), cancelText: t("c.cancel") }))) return;
    setBusy(true);
    const j = await fetch(`/api/stores/${store.id}/fx-convert`, { method: "POST" }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setBusy(false);
    if (j.ok) { flash(t("st.fxConverted").replace("{n}", String(j.orders)).replace("{rate}", String(j.rate))); reload(); close(); }
    else flash("✗ " + (j.error ?? t("st.error")));
  }

  // Tính phí ƯỚC TÍNH cho đơn CŨ đang FEE $0.00 (đơn kéo về trước khi bật tính năng này).
  // An toàn: chỉ đụng đơn FEE = 0 → chạy lại nhiều lần không nhân đôi phí.
  async function feeBackfill() {
    const pct = Number(store.feeRate ?? 0);
    if (!(pct > 0)) { flash(t("st.feeNeedRate")); return; }
    const done = store.health?.feeBackfilledAt;
    const warn = t("st.feeBackfillBody").replace("{name}", store.name).replace("{pct}", String(pct))
      + (done ? "\n\n" + t("st.feeBackfillDoneAt").replace("{time}", new Date(done).toLocaleString()).replace("{pct}", String(store.health?.feeBackfilledPct ?? pct)) : "");
    if (!(await confirm({ title: t("st.feeBackfillTitle"), message: warn, confirmText: t("c.save"), cancelText: t("c.cancel") }))) return;
    setBusy(true);
    const j = await fetch(`/api/stores/${store.id}/fee-backfill`, { method: "POST" }).then((r) => r.json()).catch(() => ({ ok: false, error: "network" }));
    setBusy(false);
    if (j.ok) { flash(t("st.feeBackfilled").replace("{n}", String(j.orders)).replace("{pct}", String(j.pct))); reload(); close(); }
    else flash("✗ " + (j.error ?? t("st.error")));
  }

  return (
    <Modal title={<span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}><MarketplaceLogo mk={store.marketplace} size={22} /> {store.name}</span>} close={close}>
      <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <L label={t("st.storeName")}><input value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} style={inp} /></L>
        <L label={t("st.status")}><select value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })} style={inp}><option value="active">Active</option><option value="warning">Warning</option><option value="suspended">Suspended</option><option value="pending">Pending</option></select></L>
        {!isSeller && <L label="Seller"><select value={f.sellerId} onChange={(e) => setF({ ...f, sellerId: e.target.value })} style={inp}><option value="">—</option>{sellers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select></L>}
      </div>
      {/* v458 · Share store cho nhiều seller cùng thấy + dùng (chỉ Shopify/ShopBase; lưu khi bấm Save) */}
      {canShare && (
        <L label="Sellers with access (share store)">
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, alignItems: "center" }}>
            {members.map((id) => {
              const nm = sellers.find((x) => x.id === id)?.name ?? id.slice(0, 8);
              return (
                <span key={id} style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "#EDF3FF", color: "#1D4ED8", borderRadius: 999, padding: "3px 6px 3px 10px", fontSize: 12, fontWeight: 700 }}>
                  {nm}
                  <button onClick={() => setMembers((m) => m.filter((x) => x !== id))} title="Remove access"
                    style={{ border: "none", background: "#DBE7FF", color: "#1D4ED8", borderRadius: 999, width: 16, height: 16, lineHeight: "14px", fontSize: 11, cursor: "pointer", padding: 0 }}>×</button>
                </span>
              );
            })}
            {!members.length && <span style={{ fontSize: 12, color: "var(--muted)" }}>Chỉ chủ store (Seller ở trên) và admin thấy store này</span>}
            <select value={memPick} onChange={(e) => { const v = e.target.value; if (v && !members.includes(v)) setMembers((m) => [...m, v]); setMemPick(""); }}
              style={{ ...inp, width: "auto", minWidth: 140, padding: "5px 8px", fontSize: 12 }}>
              <option value="">+ Add seller…</option>
              {sellers.filter((x) => !members.includes(x.id) && x.id !== f.sellerId).map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}
            </select>
          </div>
        </L>
      )}
      <L label={t("st.linkShop")}><input value={f.storeUrl} onChange={(e) => setF({ ...f, storeUrl: e.target.value })} placeholder="https://shop.tiktok.com/@yourshop" style={inp} /></L>
      <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        <L label={t("st.shopCurrency")}><select value={f.currency} onChange={(e) => { const cur = e.target.value; setF({ ...f, currency: cur, fxRate: cur === "USD" ? "1" : (Number(f.fxRate) <= 1 ? String(FX_DEFAULT[cur] ?? "") : f.fxRate) }); }} style={inp}>{CURRENCIES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></L>
        <L label={t("st.fxLabel").replace("{cur}", f.currency)}><input type="number" step="0.0001" value={f.fxRate} disabled={f.currency === "USD"} onChange={(e) => setF({ ...f, fxRate: e.target.value })} placeholder="vd 25400" style={{ ...inp, background: f.currency === "USD" ? "#EDEFF4" : "#fff" }} /></L>
      </div>
      {f.currency !== "USD" && (
        <div style={{ border: "1px solid #F3D08A", background: "#FFF9EC", borderRadius: 10, padding: "10px 12px", display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
          <button onClick={fxConvert} disabled={busy} style={{ ...btnGhost, color: "#9A6B00", borderColor: "#F3D08A", fontWeight: 700, fontSize: 12.5 }}><IconDownload width={12} height={12} style={{ verticalAlign: "-2px", marginRight: 4 }} />{t("st.fxConvertImported")}</button>
          <span style={{ fontSize: 11.5, color: "var(--muted)", flex: 1 }}>
            {store.health?.fxConvertedAt
              ? t("st.fxDoneAt").replace("{time}", new Date(store.health.fxConvertedAt).toLocaleString()).replace("{rate}", String(store.health.fxConvertedRate))
              : t("st.fxHint")}
          </span>
        </div>
      )}
      {/* Fee (est.) — % phí sàn ước tính + nút tính cho đơn cũ đang FEE $0.00 */}
      <L label={t("st.feeLabel")}><input type="number" step="0.1" min="0" max="99" value={f.feeRate} onChange={(e) => setF({ ...f, feeRate: e.target.value })} placeholder="6.5" style={inp} /></L>
      <div style={{ border: "1px solid #F3D08A", background: "#FFF9EC", borderRadius: 10, padding: "10px 12px", display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
        <button onClick={feeBackfill} disabled={busy} style={{ ...btnGhost, color: "#9A6B00", borderColor: "#F3D08A", fontWeight: 700, fontSize: 12.5 }}><IconDownload width={12} height={12} style={{ verticalAlign: "-2px", marginRight: 4 }} />{t("st.feeBackfill")}</button>
        <span style={{ fontSize: 11.5, color: "var(--muted)", flex: 1 }}>
          {store.health?.feeBackfilledAt
            ? t("st.feeBackfillDoneAt").replace("{time}", new Date(store.health.feeBackfilledAt).toLocaleString()).replace("{pct}", String(store.health.feeBackfilledPct ?? ""))
            : t("st.feeHint")}
        </span>
      </div>
      <L label={t("st.note")}><input value={f.note} onChange={(e) => setF({ ...f, note: e.target.value })} style={inp} /></L>

      {/* Etsy API chính thức (Open API v3) — mỗi store 1 app riêng. Khuyên dùng thay cho extension. */}
      {store.marketplace === "etsy" && (
        <div style={{ border: "1px solid #CDEFD8", background: "#F3FBF6", borderRadius: 12, padding: "12px 14px", marginTop: 8 }}>
          <b style={{ fontSize: 13.5, display: "inline-flex", alignItems: "center", gap: 6 }}><IconKey width={15} height={15} /> Etsy API (official)</b>
          <div style={{ fontSize: 11.5, color: "var(--muted)", margin: "4px 0 10px" }}>
            Each store uses its own Etsy app. Create one at etsy.com/developers (enable 2FA), register the callback URL below, then paste the Keystring + Shared Secret here and connect.
          </div>
          <L label="Callback URL — register this in your Etsy app">
            <div style={{ display: "flex", gap: 6 }}>
              <input readOnly value={oauthCb} style={{ ...inp, flex: 1, fontSize: 12 }} onFocus={(e) => e.target.select()} />
              <button onClick={() => { navigator.clipboard?.writeText(oauthCb); flash(t("st.copiedUrl")); }} style={{ ...btnGhost, fontSize: 12 }}>Copy</button>
            </div>
          </L>
          <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <L label="Keystring (App API Key)"><input value={etsyKey} onChange={(e) => setEtsyKey(e.target.value)} onFocus={() => setRoEtsy(false)} readOnly={roEtsy} placeholder="e.g. 1aa2bb33c44d55…" style={inp} name="fusion-etsy-key" autoComplete="off" data-lpignore="true" data-1p-ignore data-form-type="other" /></L>
            <L label="Shared Secret"><input type="password" value={etsySecret} onChange={(e) => setEtsySecret(e.target.value)} onFocus={() => setRoEtsy(false)} readOnly={roEtsy} placeholder={store.etsy?.hasKeystring ? "••• (saved, leave blank to keep)" : "shared secret"} style={inp} name="fusion-etsy-secret" autoComplete="new-password" data-lpignore="true" data-1p-ignore data-form-type="other" /></L>
          </div>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 7, background: "#FFF6F4", border: "1px solid #F6D9D0", borderRadius: 9, padding: "8px 10px", fontSize: 11.5, fontWeight: 600, color: "#B4543C", marginTop: 10 }}>
            <IconWarn width={13} height={13} style={{ flexShrink: 0, marginTop: 1 }} />
            <span>Open the connect link <b>only inside the shop&apos;s own browser profile</b> (AdsPower). Authorizing from the wrong IP can get the shop suspended. The link works without logging in to Fusion OS there, and expires in 10 minutes.</span>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginTop: 8 }}>
            <button onClick={saveEtsyApi} disabled={etsyBusy} style={{ ...btnGhost, fontSize: 12.5 }}>Save app</button>
            <button onClick={etsyConnectLink} disabled={etsyBusy || !(store.etsy?.hasKeystring || etsySaved)} style={{ background: "var(--blue)", color: "#fff", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: (store.etsy?.hasKeystring || etsySaved) ? "pointer" : "default", opacity: (store.etsy?.hasKeystring || etsySaved) ? 1 : 0.5 }} title="Copy the authorize link and open it in the shop's own AdsPower profile. Never open it here — a wrong IP can get the shop suspended."><IconCopy width={12} height={12} style={{ verticalAlign: "-1px", marginRight: 4 }} />{store.etsy?.connected ? "Copy reconnect link" : "Copy connect link"}</button>
            {store.etsy?.connected && <button onClick={pullEtsy} disabled={etsyBusy} style={{ background: "#2E7D46", color: "#fff", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: "pointer" }}><IconDownload width={13} height={13} style={{ verticalAlign: "-2px", marginRight: 4 }} />Pull orders</button>}
            <span style={{ marginLeft: "auto", fontSize: 11.5, fontWeight: 700 }}>
              {store.etsy?.connected
                ? <span style={{ color: "#2E7D46" }}><IconKey width={11} height={11} style={{ verticalAlign: "-1px" }} /> Connected · shop {store.etsy?.shopId}</span>
                : <span style={{ color: "var(--muted)" }}>Not connected</span>}
            </span>
          </div>
        </div>
      )}

      {store.marketplace === "tiktok" && (
        <div style={{ border: "1px solid #E8D9F5", background: "#FBF7FF", borderRadius: 12, padding: "12px 14px", marginTop: 8 }}>
          <b style={{ fontSize: 13.5, display: "inline-flex", alignItems: "center", gap: 6 }}><IconKey width={15} height={15} /> TikTok Shop API (official)</b>
          <div style={{ fontSize: 11.5, color: "var(--muted)", margin: "4px 0 10px" }}>
            Create a <b>Custom app</b> on TikTok Shop Partner Center (target market US), register the Redirect URL below,
            apply Order scopes, then paste App Key + App Secret + the app&apos;s Authorization link here. One app can serve every shop.
          </div>
          <L label="Redirect URL — register this in your TikTok app">
            <div style={{ display: "flex", gap: 6 }}>
              <input readOnly value={`${CANONICAL}/api/tiktok/oauth/callback`} style={{ ...inp, flex: 1, fontSize: 12 }} onFocus={(e) => e.target.select()} />
              <button onClick={() => { navigator.clipboard?.writeText(`${CANONICAL}/api/tiktok/oauth/callback`); flash(t("st.copiedUrl")); }} style={{ ...btnGhost, fontSize: 12 }}>Copy</button>
            </div>
          </L>
          <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <L label="App Key"><input value={ttKey} onChange={(e) => setTtKey(e.target.value)} placeholder="e.g. 6h2k4…" style={inp} autoComplete="off" data-lpignore="true" data-1p-ignore /></L>
            <L label="App Secret"><input type="password" value={ttSecret} onChange={(e) => setTtSecret(e.target.value)} placeholder={store.tiktok?.hasApp ? "••• (saved, leave blank to keep)" : "app secret"} style={inp} autoComplete="new-password" data-lpignore="true" data-1p-ignore /></L>
          </div>
          <L label="Authorization link (Partner Center → app detail → copy authorize URL)">
            <input value={ttAuthLink} onChange={(e) => setTtAuthLink(e.target.value)} placeholder="https://services.tiktokshop.com/open/authorize?service_id=…" style={{ ...inp, fontSize: 12 }} autoComplete="off" />
          </L>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 7, background: "#FFF6F4", border: "1px solid #F6D9D0", borderRadius: 9, padding: "8px 10px", fontSize: 11.5, fontWeight: 600, color: "#B4543C", marginTop: 10 }}>
            <IconWarn width={13} height={13} style={{ flexShrink: 0, marginTop: 1 }} />
            <span>Open the connect link <b>only inside the shop&apos;s own browser profile</b> (AdsPower). Authorizing from the wrong IP can get the shop suspended.</span>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginTop: 8 }}>
            <button onClick={saveTtApi} disabled={ttBusy} style={{ ...btnGhost, fontSize: 12.5 }}>Save app</button>
            <button onClick={ttConnectLink} disabled={ttBusy || !(store.tiktok?.hasApp || ttSaved)} style={{ background: "var(--blue)", color: "#fff", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: (store.tiktok?.hasApp || ttSaved) ? "pointer" : "default", opacity: (store.tiktok?.hasApp || ttSaved) ? 1 : 0.5 }} title="Copy the authorize link and open it in the shop's own AdsPower profile. Never open it here - a wrong IP can get the shop suspended."><IconCopy width={12} height={12} style={{ verticalAlign: "-1px", marginRight: 4 }} />{ttConnected ? "Copy reconnect link" : "Copy connect link"}</button>
            {(ttConnected || store.tiktok?.hasApp || ttSaved) && <button onClick={checkTt} disabled={ttBusy} style={{ ...btnGhost, fontSize: 12.5 }}>Check connection</button>}
            {ttConnected && <span style={{ fontSize: 11.5, color: "var(--muted)", fontWeight: 600 }}>Orders auto-pull every 15 min</span>}
            <span style={{ marginLeft: "auto", fontSize: 11.5, fontWeight: 700 }}>
              {ttConnected
                ? <span style={{ color: "#2E7D46" }}><IconKey width={11} height={11} style={{ verticalAlign: "-1px" }} /> Connected · {ttName}</span>
                : <span style={{ color: "var(--muted)" }}>Not connected</span>}
            </span>
          </div>
        </div>
      )}

      {/* Shopify API (app Dev Dashboard — client_credentials). Nhập ở đây thay cho chạy SQL. */}
      {store.marketplace === "shopify" && (
        <div style={{ border: "1px solid #CDEFD8", background: "#F3FBF6", borderRadius: 12, padding: "12px 14px", marginTop: 8 }}>
          <b style={{ fontSize: 13.5, display: "inline-flex", alignItems: "center", gap: 6 }}><IconKey width={15} height={15} /> Shopify API (Dev Dashboard app)</b>
          <div style={{ fontSize: 11.5, color: "var(--muted)", margin: "4px 0 10px" }}>
            In the Shopify Dev Dashboard, release a version with scopes <b>read_orders, write_fulfillments, read_fulfillments, write/read_assigned_fulfillment_orders</b>, then copy Client ID + Client Secret from <b>Settings</b> and paste them here.
          </div>
          <L label="Shop domain (xxx.myshopify.com — NOT your custom domain)">
            <input value={shDomain} onChange={(e) => setShDomain(e.target.value)} placeholder="talewix-xxxx.myshopify.com" style={inp} autoComplete="off" data-lpignore="true" data-1p-ignore />
          </L>
          <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <L label="Client ID"><input value={shClientId} onChange={(e) => setShClientId(e.target.value)} placeholder="e.g. 85e245a2fbdd…" style={inp} autoComplete="off" data-lpignore="true" data-1p-ignore /></L>
            <L label="Client Secret"><input type="password" value={shSecret} onChange={(e) => setShSecret(e.target.value)} placeholder={store.shopify?.hasApp ? "••• (saved, leave blank to keep)" : "shpss_…"} style={inp} autoComplete="new-password" data-lpignore="true" data-1p-ignore data-form-type="other" /></L>
          </div>
          {shCheck && (
            <div style={{ fontSize: 12, padding: "7px 11px", borderRadius: 9, margin: "2px 0 8px", background: shCheck.ok ? "var(--green-soft)" : "var(--red-soft)", color: shCheck.ok ? "#2E7D46" : "var(--red)", fontWeight: 600 }}>
              {shCheck.ok ? "✓ " : "✗ "}{shCheck.text}
            </div>
          )}
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginTop: 8 }}>
            <button onClick={saveShopify} disabled={shBusy} style={{ ...btnGhost, fontSize: 12.5 }}>Save app</button>
            <button onClick={checkShopify} disabled={shBusy || !(store.shopify?.hasApp || shSaved)} style={{ background: "var(--blue)", color: "#fff", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: (store.shopify?.hasApp || shSaved) ? "pointer" : "default", opacity: (store.shopify?.hasApp || shSaved) ? 1 : 0.5 }}>Check connection</button>
            <button onClick={registerShopifyHooks} disabled={shBusy || !(store.shopify?.hasApp || shSaved)} style={{ background: "#2E7D46", color: "#fff", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: (store.shopify?.hasApp || shSaved) ? "pointer" : "default", opacity: (store.shopify?.hasApp || shSaved) ? 1 : 0.5 }}>Register webhooks</button>
            <span style={{ marginLeft: "auto", fontSize: 11.5, fontWeight: 700 }}>
              {store.shopify?.hasApp
                ? <span style={{ color: "#2E7D46" }}><IconKey width={11} height={11} style={{ verticalAlign: "-1px" }} /> App saved</span>
                : <span style={{ color: "var(--muted)" }}>Not configured</span>}
            </span>
          </div>
          <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 8, lineHeight: 1.5 }}>
            Flow: <b>Save app</b> → <b>Check connection</b> (confirms the shop name) → <b>Register webhooks</b>. After that, new Shopify orders arrive automatically and tracking is pushed back to Shopify.
          </div>
        </div>
      )}

      {/* ShopBase (private app · Basic auth). Nhập creds → Check → Sync orders. Độc lập với Shopify. */}
      {store.marketplace === "shopbase" && (
        <div style={{ border: "1px solid #CBD9FF", background: "#EEF3FF", borderRadius: 12, padding: "12px 14px", marginTop: 8 }}>
          <b style={{ fontSize: 13.5, display: "inline-flex", alignItems: "center", gap: 6 }}><IconKey width={15} height={15} /> ShopBase API (private app)</b>
          <div style={{ fontSize: 11.5, color: "var(--muted)", margin: "4px 0 10px", lineHeight: 1.5 }}>
            In ShopBase admin → <b>Apps → Manage private apps → Create private app</b>, grant <b>Admin API</b> read access to Orders, then copy the <b>API key + Password</b> here.
          </div>
          <L label="Subdomain ({store}.onshopbase.com — or just the store name)">
            <input value={sbSubdomain} onChange={(e) => setSbSubdomain(e.target.value)} placeholder="talewix.onshopbase.com" style={inp} autoComplete="off" data-lpignore="true" data-1p-ignore />
          </L>
          <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <L label="API key"><input value={sbApiKey} onChange={(e) => setSbApiKey(e.target.value)} placeholder={store.shopbase?.hasApp ? "••• (saved, leave blank to keep)" : "e.g. 3a5f…"} style={inp} autoComplete="off" data-lpignore="true" data-1p-ignore /></L>
            <L label="Password"><input type="password" value={sbPassword} onChange={(e) => setSbPassword(e.target.value)} placeholder={store.shopbase?.hasApp ? "••• (saved, blank = keep)" : "shppass_…"} style={inp} autoComplete="new-password" data-lpignore="true" data-1p-ignore data-form-type="other" /></L>
          </div>
          {sbCheck && (
            <div style={{ fontSize: 12, padding: "7px 11px", borderRadius: 9, margin: "2px 0 8px", background: sbCheck.ok ? "var(--green-soft)" : "var(--red-soft)", color: sbCheck.ok ? "#2E7D46" : "var(--red)", fontWeight: 600 }}>
              {sbCheck.ok ? "✓ " : "✗ "}{sbCheck.text}
            </div>
          )}
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginTop: 8 }}>
            <button onClick={saveShopbase} disabled={sbBusy} style={{ ...btnGhost, fontSize: 12.5 }}>Save</button>
            <button onClick={checkShopbase} disabled={sbBusy || !(store.shopbase?.hasApp || sbSaved)} style={{ background: "var(--blue)", color: "#fff", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: (store.shopbase?.hasApp || sbSaved) ? "pointer" : "default", opacity: (store.shopbase?.hasApp || sbSaved) ? 1 : 0.5 }}>Check connection</button>
            <button onClick={syncShopbase} disabled={sbBusy || !(store.shopbase?.hasApp || sbSaved)} style={{ background: "#2F6BFF", color: "#fff", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: (store.shopbase?.hasApp || sbSaved) ? "pointer" : "default", opacity: (store.shopbase?.hasApp || sbSaved) ? 1 : 0.5 }}>Sync orders</button>
            <span style={{ marginLeft: "auto", fontSize: 11.5, fontWeight: 700 }}>
              {(store.shopbase?.hasApp || sbSaved)
                ? <span style={{ color: "#2E7D46" }}><IconKey width={11} height={11} style={{ verticalAlign: "-1px" }} /> Configured{store.shopbase?.lastSyncAt ? " · synced " + new Date(store.shopbase.lastSyncAt).toLocaleDateString() : ""}</span>
                : <span style={{ color: "var(--muted)" }}>Not configured</span>}
            </span>
          </div>
          <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 8, lineHeight: 1.5 }}>
            Flow: <b>Save</b> → <b>Check connection</b> → <b>Sync orders</b>. Orders land in the same tables as Shopify, so Product Sales &amp; Video performance include ShopBase automatically. Secrets are stored server-side — leave blank to keep the saved value.
          </div>
        </div>
      )}

      {store.marketplace === "woocommerce" && (
        <div style={{ border: "1px solid #DCCDF2", background: "#F4EFFB", borderRadius: 12, padding: "12px 14px", marginTop: 8 }}>
          <b style={{ fontSize: 13.5, display: "inline-flex", alignItems: "center", gap: 6 }}><IconKey width={15} height={15} /> WooCommerce REST API</b>
          <div style={{ fontSize: 11.5, color: "var(--muted)", margin: "4px 0 10px", lineHeight: 1.5 }}>
            In WordPress admin → <b>WooCommerce → Settings → Advanced → REST API → Add key</b>, permission <b>Read</b>, then copy the <b>Consumer key + secret</b> here.
          </div>
          <L label="Store URL (e.g. https://sorawix.com)">
            <input value={wcUrl} onChange={(e) => setWcUrl(e.target.value)} placeholder="https://sorawix.com" style={inp} autoComplete="off" data-lpignore="true" data-1p-ignore />
          </L>
          <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <L label="Consumer key"><input value={wcKey} onChange={(e) => setWcKey(e.target.value)} placeholder={store.woocommerce?.hasKeys ? "••• (saved, leave blank to keep)" : "ck_…"} style={inp} autoComplete="off" data-lpignore="true" data-1p-ignore /></L>
            <L label="Consumer secret"><input type="password" value={wcSecret} onChange={(e) => setWcSecret(e.target.value)} placeholder={store.woocommerce?.hasKeys ? "••• (saved, blank = keep)" : "cs_…"} style={inp} autoComplete="new-password" data-lpignore="true" data-1p-ignore data-form-type="other" /></L>
          </div>
          {wcCheck && (
            <div style={{ fontSize: 12, padding: "7px 11px", borderRadius: 9, margin: "2px 0 8px", background: wcCheck.ok ? "var(--green-soft)" : "var(--red-soft)", color: wcCheck.ok ? "#2E7D46" : "var(--red)", fontWeight: 600 }}>
              {wcCheck.ok ? "✓ " : "✗ "}{wcCheck.text}
            </div>
          )}
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginTop: 8 }}>
            <button onClick={saveWoo} disabled={wcBusy} style={{ ...btnGhost, fontSize: 12.5 }}>Save</button>
            <button onClick={checkWoo} disabled={wcBusy || !(store.woocommerce?.hasKeys || wcSaved)} style={{ background: "var(--blue)", color: "#fff", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: (store.woocommerce?.hasKeys || wcSaved) ? "pointer" : "default", opacity: (store.woocommerce?.hasKeys || wcSaved) ? 1 : 0.5 }}>Check connection</button>
            <button onClick={syncWoo} disabled={wcBusy || !(store.woocommerce?.hasKeys || wcSaved)} style={{ background: "#7F54B3", color: "#fff", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: (store.woocommerce?.hasKeys || wcSaved) ? "pointer" : "default", opacity: (store.woocommerce?.hasKeys || wcSaved) ? 1 : 0.5 }}>Sync orders</button>
            <span style={{ marginLeft: "auto", fontSize: 11.5, fontWeight: 700 }}>
              {(store.woocommerce?.hasKeys || wcSaved)
                ? <span style={{ color: "#2E7D46" }}><IconKey width={11} height={11} style={{ verticalAlign: "-1px" }} /> Configured{store.woocommerce?.lastSyncAt ? " · synced " + new Date(store.woocommerce.lastSyncAt).toLocaleDateString() : ""}</span>
                : <span style={{ color: "var(--muted)" }}>Not configured</span>}
            </span>
          </div>
          <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 8, lineHeight: 1.5 }}>
            Flow: <b>Save</b> → <b>Check connection</b> → <b>Sync orders</b>. After that the cron pulls new orders automatically every tick — no manual sync needed. Personalization the buyer enters (names, photo links) lands in each order line. Secrets are stored server-side — leave blank to keep the saved value.
          </div>
        </div>
      )}

      {/* Amazon SP-API (LWA — refresh_token → access_token, không cần AWS IAM/SigV4). Tự lấy ASIN/đơn. */}
      {store.marketplace === "amazon" && (
        <div style={{ border: "1px solid #FFE2B8", background: "#FFF9F0", borderRadius: 12, padding: "12px 14px", marginTop: 8 }}>
          <b style={{ fontSize: 13.5, display: "inline-flex", alignItems: "center", gap: 6 }}><IconKey width={15} height={15} /> Amazon SP-API (Selling Partner API)</b>
          <div style={{ fontSize: 11.5, color: "var(--muted)", margin: "4px 0 10px", lineHeight: 1.5 }}>
            In Seller Central → <b>Develop Apps</b>, create a private app (self-authorize) to get <b>LWA Client ID + Client Secret + Refresh Token</b>. Seller ID is your <b>Merchant token</b> (Settings → Account Info). No AWS IAM key needed since 2024.
          </div>
          <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <L label="Region"><select value={azRegion} onChange={(e) => setAzRegion(e.target.value)} style={inp}><option value="na">North America</option><option value="eu">Europe</option><option value="fe">Far East</option></select></L>
            <L label="Marketplace ID"><input value={azMkId} onChange={(e) => setAzMkId(e.target.value)} placeholder="ATVPDKIKX0DER (US)" style={{ ...inp, fontFamily: "monospace", fontSize: 12 }} autoComplete="off" data-lpignore="true" data-1p-ignore /></L>
          </div>
          <L label="Seller ID (Merchant token)"><input value={azSeller} onChange={(e) => setAzSeller(e.target.value)} placeholder="e.g. A1B2C3D4E5F6G7" style={{ ...inp, fontFamily: "monospace", fontSize: 12 }} autoComplete="off" data-lpignore="true" data-1p-ignore /></L>
          <L label="LWA Client ID"><input value={azClientId} onChange={(e) => setAzClientId(e.target.value)} placeholder="amzn1.application-oa2-client…" style={{ ...inp, fontFamily: "monospace", fontSize: 11.5 }} autoComplete="off" data-lpignore="true" data-1p-ignore /></L>
          <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <L label="LWA Client Secret"><input type="password" value={azSecret} onChange={(e) => setAzSecret(e.target.value)} placeholder={store.amazon?.hasSecret ? "••• (saved, blank = keep)" : "amzn1.oa2-cs…"} style={{ ...inp, fontFamily: "monospace", fontSize: 11.5 }} autoComplete="new-password" data-lpignore="true" data-1p-ignore data-form-type="other" /></L>
            <L label="Refresh Token"><input type="password" value={azRefresh} onChange={(e) => setAzRefresh(e.target.value)} placeholder={store.amazon?.hasRefresh ? "••• (saved, blank = keep)" : "Atzr|…"} style={{ ...inp, fontFamily: "monospace", fontSize: 11.5 }} autoComplete="new-password" data-lpignore="true" data-1p-ignore data-form-type="other" /></L>
          </div>
          {azCheck && (
            <div style={{ fontSize: 12, padding: "7px 11px", borderRadius: 9, margin: "2px 0 8px", background: azCheck.ok ? "var(--green-soft)" : "var(--red-soft)", color: azCheck.ok ? "#2E7D46" : "var(--red)", fontWeight: 600 }}>
              {azCheck.ok ? "✓ " : "✗ "}{azCheck.text}
            </div>
          )}
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginTop: 8 }}>
            <button onClick={() => saveAmazon(false)} disabled={azBusy} style={{ ...btnGhost, fontSize: 12.5 }}>Save</button>
            <button onClick={() => saveAmazon(true)} disabled={azBusy} style={{ background: "#FF9900", color: "#111", border: 0, borderRadius: 10, padding: "8px 14px", fontWeight: 800, fontSize: 12.5, cursor: "pointer" }}>Save &amp; test connection</button>
            <span style={{ marginLeft: "auto", fontSize: 11.5, fontWeight: 700 }}>
              {(store.amazon?.configured || azSaved)
                ? <span style={{ color: "#2E7D46" }}><IconKey width={11} height={11} style={{ verticalAlign: "-1px" }} /> Configured{store.amazon?.lastSyncAt ? " · synced " + new Date(store.amazon.lastSyncAt).toLocaleDateString() : ""}</span>
                : <span style={{ color: "var(--muted)" }}>Not configured</span>}
            </span>
          </div>
          <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 8, lineHeight: 1.5 }}>
            Once connected, <b>Manage Products Amazon → ⟳ Sync from Amazon</b> pulls ASIN + live status automatically. Secrets are stored server-side and never shown again — leave a field blank to keep the saved value.
          </div>
        </div>
      )}

      {/* Extension: Kéo đơn Etsy về FUSION (chỉ store Etsy) */}
      {store.marketplace === "etsy" && (
        <div style={{ border: "1px solid #CDE3FA", background: "#F3F9FF", borderRadius: 12, padding: "12px 14px", marginTop: 8 }}>
          <b style={{ fontSize: 13.5, display: "flex", alignItems: "center", gap: 6 }}><IconPuzzle width={16} height={16} />{t("st.extTitle")}</b>
          <div style={{ fontSize: 11.5, color: "var(--muted)", margin: "4px 0 10px" }}>{t("st.extDesc")}{" "}<a href="/extension/" target="_blank" rel="noreferrer" style={{ color: "var(--blue)", fontWeight: 800 }}>Download extension ↗</a></div>
          <L label="Ingest URL">
            <div style={{ display: "flex", gap: 6 }}>
              <input readOnly value={ingestUrl} style={{ ...inp, flex: 1, fontSize: 12 }} onFocus={(e) => e.target.select()} />
              <button onClick={() => { navigator.clipboard?.writeText(ingestUrl); flash(t("st.copiedUrl")); }} style={{ ...btnGhost, fontSize: 12 }}>Copy</button>
            </div>
          </L>
          <L label="Store token (Bearer)">
            <div style={{ display: "flex", gap: 6 }}>
              <input readOnly type={showTok ? "text" : "password"} value={tok} style={{ ...inp, flex: 1, fontSize: 12, letterSpacing: showTok ? 0 : 2 }} onFocus={(e) => e.target.select()} />
              <button onClick={() => setShowTok((v) => !v)} style={{ ...btnGhost, fontSize: 12 }}>{showTok ? t("st.hide") : t("st.show")}</button>
              <button onClick={() => { navigator.clipboard?.writeText(tok); flash(t("st.copiedToken")); }} style={{ ...btnGhost, fontSize: 12 }}>Copy</button>
            </div>
          </L>
          <button onClick={regenToken} style={{ ...btnGhost, color: "var(--red)", borderColor: "#F3C0C0", fontSize: 12, marginTop: 4 }}><IconRefresh width={12} height={12} style={{ verticalAlign: "-2px", marginRight: 4 }} />{t("st.newToken")}</button>
        </div>
      )}

      {/* Setup API (generic) — Etsy/TikTok/Shopify/Amazon có khu riêng nên ẩn */}
      {store.marketplace !== "etsy" && store.marketplace !== "tiktok" && store.marketplace !== "shopify" && store.marketplace !== "amazon" && (
        <div style={{ border: "1px solid var(--line)", borderRadius: 12, padding: "12px 14px", marginTop: 8 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
            <b style={{ fontSize: 13.5 }}>{t("st.apiConfig")}</b>
            {store.hasCredentials && <span style={{ fontSize: 11, color: "var(--green)", fontWeight: 700 }}><IconKey width={12} height={12} style={{ verticalAlign: "-2px" }} /> {t("st.apiHas")}: {store.credentialKeys.join(", ")}</span>}
            <button onClick={check} disabled={busy} style={{ ...btnGhost, marginLeft: "auto", fontSize: 12 }}>{t("st.checkConn")}</button>
          </div>
          {health && (
            <div style={{ fontSize: 12.5, padding: "6px 10px", borderRadius: 8, marginBottom: 8, background: health.ok ? "var(--green-soft)" : "var(--red-soft)", color: health.ok ? "var(--green)" : "var(--red)" }}>
              {health.ok ? "✓" : "✗"} {health.message}
            </div>
          )}
          <div className="m-stack-sm" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            {fields.map(([k, label]) => (
              <L key={k} label={label}>
                <input type="password" placeholder={store.credentialKeys.includes(k) ? t("st.savedKept") : t("st.enterValue")}
                  onChange={(e) => setCred({ ...cred, [k]: e.target.value })} style={inp} autoComplete="new-password" data-lpignore="true" data-1p-ignore data-form-type="other" />
              </L>
            ))}
          </div>
          <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 6 }}>Credentials are encrypted on the server and never shown again. Leave a field blank to keep the current value.</div>
        </div>
      )}
      <Actions close={close} onOk={save} busy={busy} okLabel={t("st.saveStore")} />
    </Modal>
  );
}

function Modal({ title, close, children }: { title: React.ReactNode; close: () => void; children: React.ReactNode }) {
  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(42,48,60,.45)", zIndex: 95, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }} onClick={close}>
      <div className="modal-card" style={{ background: "#fff", borderRadius: 16, width: 560, maxWidth: "95vw", maxHeight: "92vh", overflowY: "auto", padding: 24 }} onClick={(e) => e.stopPropagation()}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <b style={{ fontSize: 15 }}>{title}</b>
          <button onClick={close} style={{ background: "none", border: "none", fontSize: 17, cursor: "pointer", color: "var(--muted)" }}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
function L({ label, children }: { label: string; children: React.ReactNode }) {
  return <label style={{ display: "block", marginBottom: 12 }}><span style={{ fontSize: 12.5, fontWeight: 600, color: "var(--muted)", display: "block", marginBottom: 5 }}>{label}</span>{children}</label>;
}
function Actions({ close, onOk, busy, okLabel, disabled }: { close: () => void; onOk: () => void; busy: boolean; okLabel: string; disabled?: boolean }) {
  const { t } = useLang();
  return (
    <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 16 }}>
      <button onClick={close} style={btnGhost}>{t("c.cancel")}</button>
      <button onClick={onOk} disabled={busy || disabled} className="btn btn-primary" style={{ opacity: busy || disabled ? 0.6 : 1 }}>{busy ? t("st.saving") : okLabel}</button>
    </div>
  );
}

const inp: React.CSSProperties = { width: "100%", padding: "9px 12px", border: "1px solid var(--line)", borderRadius: 10, fontSize: 13, background: "#fff" };
const btnGhost: React.CSSProperties = { background: "#fff", color: "var(--muted)", border: "1px solid var(--line)", borderRadius: 10, padding: "9px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" };
