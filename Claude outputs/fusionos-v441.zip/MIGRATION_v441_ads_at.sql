-- v441 · Đánh dấu sản phẩm đã chạy Meta ads (set khi export Meta bulk file từ Meta Ads Kit).
ALTER TABLE shopify_products ADD COLUMN IF NOT EXISTS ads_at timestamptz;
