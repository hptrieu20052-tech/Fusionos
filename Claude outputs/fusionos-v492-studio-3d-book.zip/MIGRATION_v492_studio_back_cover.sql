-- v492 · Studio: preview sách 3D có mặt trước + mặt sau.
-- Supabase SQL Editor.
ALTER TABLE studio_templates ADD COLUMN IF NOT EXISTS back_image_url text NOT NULL DEFAULT '';
ALTER TABLE studio_templates ADD COLUMN IF NOT EXISTS gen_back boolean NOT NULL DEFAULT false;
ALTER TABLE studio_previews ADD COLUMN IF NOT EXISTS preview_back_key text NOT NULL DEFAULT '';
