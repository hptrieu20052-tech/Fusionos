-- v459 · Template Shopify ghi người tạo (seller chỉ thấy/sửa template mình tạo; admin thấy hết).
ALTER TABLE shopify_templates ADD COLUMN IF NOT EXISTS created_by uuid;
