-- v411 · Store ShopBase dùng CHUNG nhiều seller:
--   1. cột created_by: gắn listing/template với NGƯỜI TẠO (thay vì chủ store)
--   2. store ShopBase có seller = TRỐNG (NULL) ⇒ store chung — mọi user có quyền products đều thấy/dùng
-- Chạy trên Supabase SQL editor. Idempotent.
ALTER TABLE shopbase_products  ADD COLUMN IF NOT EXISTS created_by uuid;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS created_by uuid;
