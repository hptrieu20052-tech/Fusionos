-- v494 · Lưu ảnh gốc khách upload (designer cần khi sản xuất ruột sách).
ALTER TABLE studio_previews ADD COLUMN IF NOT EXISTS photo_key text NOT NULL DEFAULT '';
