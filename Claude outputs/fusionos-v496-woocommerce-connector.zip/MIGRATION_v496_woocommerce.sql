-- v496 · Thêm marketplace 'woocommerce' vào enum (store Woo như Sorawix).
-- Chạy TRƯỚC khi deploy code v496. Supabase SQL Editor: chạy riêng 1 câu này
-- (ALTER TYPE ADD VALUE không được nằm chung transaction với câu khác).
ALTER TYPE marketplace ADD VALUE IF NOT EXISTS 'woocommerce';
