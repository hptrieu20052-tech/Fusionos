-- v504 · Ghi template dùng khi tạo sản phẩm Woo (lọc "All templates" trong Manage Products).
ALTER TABLE woo_product_owners ADD COLUMN IF NOT EXISTS template_id uuid;
