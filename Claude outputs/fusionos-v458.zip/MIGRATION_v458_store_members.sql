-- v458 · Share store (Shopify/ShopBase) cho nhiều seller cùng thấy & dùng.
CREATE TABLE IF NOT EXISTS store_members (
  store_id uuid NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_store_members ON store_members (store_id, user_id);
CREATE INDEX IF NOT EXISTS idx_store_members_user ON store_members (user_id);
