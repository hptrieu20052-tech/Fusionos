import { NextRequest, NextResponse } from "next/server";
import { db, schema } from "@/lib/db";
import { eq, inArray } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { levelOf } from "@/lib/rbac";
import { storeOwnerScopeIds, sharedStoreIds } from "@/lib/scope";
import { hitsSummary, type PolicyHit } from "@/lib/policy-scan";
import { orChatJSON } from "@/lib/ai/openrouter";
import { getPrompt } from "@/lib/ai/prompt-store";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

/**
 * POST /api/shopify-products/policy-ai { ids, model? }
 *
 * v179 · AI POLICY AUDIT — phân tích TOÀN BỘ listing bằng model 👁 người dùng chọn:
 *   ảnh (artwork) + title + description + tags + SEO title + SEO meta + Google feed title/description.
 * Trả về từng vấn đề: nằm ở đâu, nặng nhẹ, và CẦN SỬA THẾ NÀO (fix cụ thể, dùng được ngay).
 *
 * Phạm vi soi (v188 · đa sàn — mọi kênh catalog này chảy tới):
 *   - Trademark/IP: thương hiệu, nhân vật có bản quyền, likeness nghệ sĩ/người nổi tiếng — cả trong
 *     ARTWORK lẫn text (kể cả viết lái/che chữ).
 *   - Google Shopping/GMC: chữ khuyến mãi trong title/feed title ("free shipping", "sale", "% off"),
 *     ALL CAPS, số điện thoại/URL nhét trong text, claim y tế, "officially licensed" không có license,
 *     replica/dupe, claim tuyệt đối gian dối; ẢNH có chữ khuyến mãi đè lên / watermark (GMC disapprove).
 *   - Meta (FB/IG Shops & ads): câu chữ khẳng định/ám chỉ đặc điểm cá nhân của người mua/người nhận
 *     (bệnh lý, tôn giáo, chủng tộc, tài chính — "for your autistic son"...), claim before/after,
 *     nội dung gợi dục.
 *   - Pinterest shopping: clickbait/thúc ép quá đà ("you won't believe", "miracle", "last chance"),
 *     nhét contact info vào description, giá/tồn kho ghi trong text không khớp listing.
 *   - SEO fields: meta/feed sai bản chất sản phẩm (misrepresentation), nhồi từ khoá lộ liễu.
 *   - KHÔNG flag sản phẩm tôn giáo (Bible/baptism hợp lệ trên mọi sàn — chỉ bị Limited personalized
 *     ads, không phải vi phạm) — tránh báo láo trên đúng dòng hàng chủ lực.
 *
 * Kết quả GHI ĐÈ policy_risk/policy_hits (nguồn sự thật duy nhất). HIGH → nút Push chặn cho tới khi
 * sửa xong và chạy lại audit ra sạch. AI là máy sàng lọc, không phải luật sư — người duyệt cuối.
 */
const MAX_PER_CALL = 6;
const IMG_MAX = 3;
const clip = (s: unknown, n: number) => String(s ?? "").replace(/\s+/g, " ").trim().slice(0, n);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function imgUrls(v: unknown): string[] {
  const arr = (Array.isArray(v) ? v : []) as { src?: string; position?: number }[];
  return arr.slice().sort((a, b) => (a?.position ?? 99) - (b?.position ?? 99))
    .map((i) => String(i?.src ?? "").trim())
    .filter((s) => /^https:\/\//i.test(s))
    .slice(0, IMG_MAX)
    .map((s) => s + (s.includes("?") ? "&" : "?") + "width=900");
}

const FIELDS = ["title", "description", "tags", "seo_title", "seo_description", "feed_title", "feed_description", "image", "other"] as const;

// Prompt sống ở src/lib/ai/prompt-defs.ts (id "shopify.policy") — admin sửa qua Manager Prompts.

export async function POST(req: NextRequest) {
  const SYSTEM = await getPrompt("shopify.policy"); // admin ghi đè qua Manager Prompts
  const deadline = Date.now() + 290_000;
  const session = await getSession();
  if (!session || (await levelOf(session, "products")) < 2) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });
  const b = await req.json().catch(() => null);
  const ids = (Array.isArray(b?.ids) ? b.ids : []).filter((x: unknown) => /^[0-9a-f-]{36}$/i.test(String(x))).slice(0, MAX_PER_CALL);
  if (!ids.length) return NextResponse.json({ ok: false, error: "ids required" }, { status: 400 });
  const model = typeof b?.model === "string" && b.model.trim() ? b.model.trim() : undefined;

  const rows = await db.select({
    id: schema.shopifyProducts.id, title: schema.shopifyProducts.title, body: schema.shopifyProducts.bodyHtml,
    tags: schema.shopifyProducts.tags, images: schema.shopifyProducts.images,
    seoTitle: schema.shopifyProducts.seoTitle, seoDescription: schema.shopifyProducts.seoDescription,
    feedTitle: schema.shopifyProducts.feedTitle, feedDescription: schema.shopifyProducts.feedDescription,
    productType: schema.shopifyProducts.productType, vendor: schema.shopifyProducts.vendor,
    seller: schema.stores.sellerId, sStoreId: schema.stores.id,
  }).from(schema.shopifyProducts).leftJoin(schema.stores, eq(schema.stores.id, schema.shopifyProducts.storeId))
    .where(inArray(schema.shopifyProducts.id, ids));
  const scopeIds = await storeOwnerScopeIds(session);
  const shared = await sharedStoreIds(scopeIds);
  if (scopeIds && rows.some((r) => !((r.seller && scopeIds.includes(r.seller)) || (r.sStoreId && shared.includes(r.sStoreId))))) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });

  const results = await Promise.all(rows.map(async (r, idx): Promise<{ id: string; title: string; ok: boolean; risk?: string; summary?: string; findings?: PolicyHit[]; error?: string }> => {
    try {
      await sleep(idx * 400); // lệch pha tránh 429
      const plain = (r.body ?? "").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
      const user = `LISTING FIELDS
title: ${clip(r.title, 250)}
tags: ${clip(r.tags, 500) || "(empty)"}
description: ${clip(plain, 1500) || "(empty)"}
seo_title: ${clip(r.seoTitle, 120) || "(empty)"}
seo_description: ${clip(r.seoDescription, 250) || "(empty)"}
feed_title: ${clip(r.feedTitle, 200) || "(empty)"}
feed_description: ${clip(r.feedDescription, 1500) || "(empty)"}
product_type: ${clip(r.productType, 80) || "(empty)"} · vendor: ${clip(r.vendor, 80) || "(empty)"}`;

      const o = await orChatJSON<{ risk?: string; findings?: { issue?: string; where?: string; severity?: string; fix?: string }[] }>(
        SYSTEM, user,
        { model, maxTokens: 3000, temperature: 0.2, reasoning: "low", images: imgUrls(r.images), timeoutMs: Math.min(45000, deadline - Date.now() - 2000) },
      );

      const findings: PolicyHit[] = (Array.isArray(o?.findings) ? o!.findings! : [])
        .map((f) => ({
          term: clip(f?.issue, 160),
          field: (FIELDS.includes(String(f?.where) as typeof FIELDS[number]) ? f!.where : "other") as PolicyHit["field"],
          severity: (f?.severity === "high" ? "high" : "medium") as PolicyHit["severity"],
          fix: clip(f?.fix, 300) || undefined,
          src: "ai" as const,
        }))
        .filter((h) => h.term);

      const risk = findings.some((h) => h.severity === "high") || o?.risk === "high" ? "high"
        : findings.length || o?.risk === "medium" ? "medium" : "clean";

      await db.update(schema.shopifyProducts)
        .set({ policyRisk: risk, policyHits: findings, policyCheckedAt: new Date(), updatedAt: new Date() })
        .where(eq(schema.shopifyProducts.id, r.id));
      return { id: r.id, title: r.title, ok: true, risk, summary: findings.length ? hitsSummary(findings) : "", findings };
    } catch (e) {
      return { id: r.id, title: r.title, ok: false, error: String((e as Error)?.message ?? e).slice(0, 200) };
    }
  }));

  const clean = results.filter((r) => r.ok && r.risk === "clean").length;
  const medium = results.filter((r) => r.ok && r.risk === "medium").length;
  const high = results.filter((r) => r.ok && r.risk === "high").length;
  const failed = results.filter((r) => !r.ok).length;
  return NextResponse.json({ ok: results.some((r) => r.ok), checked: results.length, clean, medium, high, failed, results });
}
