<?php
/**
 * Plugin Name: WCP Fusion Bridge
 * Description: Cầu nối REST cho FUSION OS đọc/ghi danh sách Product Types (data/products.json) của plugin Woo Custom Pro. Không sửa file nào của Woo Custom Pro — cài như 1 plugin riêng, xoá đi là hết. Auth bằng đúng cặp Consumer key/secret WooCommerce (namespace wc- nên WooCommerce tự áp key auth).
 * Version: 1.0.0
 * Author: FUSION OS
 */

if (!defined('ABSPATH')) exit;

/** Đường dẫn products.json của Woo Custom Pro (nguồn dữ liệu style hiện tại). */
function wcpfb_json_path() {
    return WP_PLUGIN_DIR . '/woo-custom-pro/data/products.json';
}

add_action('rest_api_init', function () {
    // Namespace bắt đầu bằng "wc-" => WooCommerce coi đây là request tới Woo REST
    // và áp dụng xác thực Consumer key/secret y như /wp-json/wc/v3/*.
    register_rest_route('wc-fusion/v1', '/product-types', array(
        array(
            'methods'             => 'GET',
            'callback'            => 'wcpfb_get_types',
            'permission_callback' => 'wcpfb_can_manage',
        ),
        array(
            'methods'             => 'POST',
            'callback'            => 'wcpfb_save_types',
            'permission_callback' => 'wcpfb_can_manage',
        ),
    ));
    register_rest_route('wc-fusion/v1', '/ping', array(
        'methods'             => 'GET',
        'callback'            => function () { return rest_ensure_response(array('ok' => true, 'plugin' => 'wcp-fusion-bridge', 'version' => '1.0.0')); },
        'permission_callback' => 'wcpfb_can_manage',
    ));
});

/** Chỉ user/key có quyền quản lý WooCommerce (key Read/Write của FUSION đạt). */
function wcpfb_can_manage() {
    return current_user_can('manage_woocommerce');
}

/** GET /wp-json/wc-fusion/v1/product-types → { ok, styles: [...] } */
function wcpfb_get_types() {
    $path = wcpfb_json_path();
    if (!file_exists($path)) {
        return new WP_Error('wcpfb_no_file', 'Không tìm thấy products.json của Woo Custom Pro', array('status' => 404));
    }
    $raw  = file_get_contents($path);
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        return new WP_Error('wcpfb_bad_json', 'products.json hiện tại không phải JSON hợp lệ', array('status' => 500));
    }
    return rest_ensure_response(array('ok' => true, 'styles' => $data));
}

/**
 * POST /wp-json/wc-fusion/v1/product-types  body: { "styles": [ {styles, image, sizes[], colors[], designs[]}, ... ] }
 * Ghi ĐÈ toàn bộ products.json (FUSION luôn gửi danh sách đầy đủ). Tự backup bản cũ trước khi ghi.
 */
function wcpfb_save_types(WP_REST_Request $req) {
    $body   = $req->get_json_params();
    $styles = isset($body['styles']) ? $body['styles'] : null;
    if (!is_array($styles) || count($styles) === 0) {
        return new WP_Error('wcpfb_bad_body', 'Body cần dạng { "styles": [ ... ] } và không được rỗng', array('status' => 400));
    }
    if (count($styles) > 200) {
        return new WP_Error('wcpfb_too_many', 'Quá 200 style — kiểm tra lại dữ liệu gửi lên', array('status' => 400));
    }

    // Validate đúng cấu trúc Woo Custom Pro đang đọc: styles(tên), sizes["S-18.99"], colors["Tên|#hex"], designs.
    $clean = array();
    $seen  = array();
    foreach ($styles as $i => $s) {
        if (!is_array($s)) return wcpfb_err($i, 'không phải object');
        $name = isset($s['styles']) ? trim((string) $s['styles']) : '';
        if ($name === '') return wcpfb_err($i, 'thiếu tên style (khoá "styles")');
        $key = strtolower($name);
        if (isset($seen[$key])) return wcpfb_err($i, 'trùng tên style "' . $name . '"');
        $seen[$key] = true;

        $sizes = isset($s['sizes']) && is_array($s['sizes']) ? $s['sizes'] : array();
        if (count($sizes) === 0) return wcpfb_err($i, 'style "' . $name . '" chưa có size nào');
        $cleanSizes = array();
        foreach ($sizes as $sz) {
            $sz = trim((string) $sz);
            // Định dạng "TênSize-Giá", giá là số > 0 (vd "2XL-26.99", "One Size-19.99").
            if (!preg_match('/^.+-\d+(\.\d{1,2})?$/', $sz)) {
                return wcpfb_err($i, 'size "' . $sz . '" sai định dạng — cần "Tên-Giá" như "M-18.99"');
            }
            $price = (float) substr($sz, strrpos($sz, '-') + 1);
            if ($price <= 0) return wcpfb_err($i, 'size "' . $sz . '" giá phải > 0');
            $cleanSizes[] = $sz;
        }

        $cleanColors = array();
        if (isset($s['colors']) && is_array($s['colors'])) {
            foreach ($s['colors'] as $c) {
                $c = trim((string) $c);
                if ($c !== '') $cleanColors[] = $c; // "Tên|#hex" hoặc chỉ "Tên"
            }
        }
        $cleanDesigns = array();
        if (isset($s['designs']) && is_array($s['designs'])) {
            foreach ($s['designs'] as $d) {
                $d = trim((string) $d);
                if ($d !== '') $cleanDesigns[] = $d;
            }
        }
        if (count($cleanDesigns) === 0) $cleanDesigns = array('front', 'back');

        $clean[] = array(
            'styles'  => $name,
            'image'   => isset($s['image']) ? esc_url_raw(trim((string) $s['image'])) : '',
            'sizes'   => $cleanSizes,
            'colors'  => $cleanColors,
            'designs' => $cleanDesigns,
        );
    }

    $path = wcpfb_json_path();
    $dir  = dirname($path);
    if (!is_dir($dir) || !wp_is_writable($dir)) {
        return new WP_Error('wcpfb_not_writable', 'Thư mục data/ của Woo Custom Pro không ghi được (kiểm tra quyền file trên host)', array('status' => 500));
    }

    // Backup bản cũ (giữ tối đa 10 bản gần nhất).
    if (file_exists($path)) {
        @copy($path, $path . '.bak-' . gmdate('Ymd-His'));
        $baks = glob($path . '.bak-*');
        if (is_array($baks) && count($baks) > 10) {
            sort($baks);
            foreach (array_slice($baks, 0, count($baks) - 10) as $old) @unlink($old);
        }
    }

    $json = wp_json_encode($clean, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $ok   = file_put_contents($path, $json, LOCK_EX);
    if ($ok === false) {
        return new WP_Error('wcpfb_write_fail', 'Ghi products.json thất bại', array('status' => 500));
    }
    return rest_ensure_response(array('ok' => true, 'count' => count($clean)));
}

function wcpfb_err($i, $msg) {
    return new WP_Error('wcpfb_invalid_style', 'Style thứ ' . ($i + 1) . ': ' . $msg, array('status' => 400));
}
