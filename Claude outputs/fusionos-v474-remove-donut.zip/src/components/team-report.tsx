"use client";
import { useLang } from "@/components/lang-provider";
import { useEffect, useState } from "react";

type Team = { name: string; orders: number; items: number; revenue: number; aov: number; members: { name: string; role: string; orders: number; revenue: number }[]; daily: { o: number; r: number }[] };
type Data = { buckets: string[]; teams: Team[]; totals: { orders: number; items: number; revenue: number } };

const PALETTE = ["#1D5FAE", "#E0A45E", "#5FAE87", "#D583AB", "#9D89D4", "#CE7B7B"];

const money = (n: number) => "$" + (Math.round(n * 100) / 100).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });

type RangeProps = { range: string; from?: string; to?: string; title?: string };
export default function TeamReport({ range, from, to, title }: RangeProps) {
  const { t: tr } = useLang();
  const [metric, setMetric] = useState<"r" | "o">("r"); // r = doanh thu, o = đơn
  const [data, setData] = useState<Data | null>(null);
  const [tip, setTip] = useState<{ x: number; y: number; bi: number } | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/stats/team-report?range=${range}${from ? `&from=${from}` : ""}${to ? `&to=${to}` : ""}`).then((r) => r.json())
      .then((j) => { if (j.ok) setData(j); }).finally(() => setLoading(false));
  }, [range, from, to]);

  if (!data) return <div className="card" style={{ padding: 24, color: "var(--muted)" }}>{tr("rep.loadingTeam")}</div>;

  const { buckets, teams, totals } = data;
  const colTotal = buckets.map((_, bi) => teams.reduce((a, t) => a + t.daily[bi][metric], 0));
  const max = Math.max(...colTotal, 1);
  const H = 210;

  return (
    <div className="card" style={{ padding: "20px 22px", position: "relative" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap", marginBottom: 12 }}>
        <a href="/stats/orders" style={{ fontWeight: 700, fontSize: 15, color: "var(--ink)", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 6 }}>{title ?? "Team Report"} <span style={{ color: "var(--sky)", fontSize: 12.5 }}>{tr("rep.viewDetails")}</span></a>
        <div style={{ display: "flex", border: "1px solid var(--line)", borderRadius: 10, overflow: "hidden" }}>
          {([["r", tr("rep.revenueTab")], ["o", tr("rep.ordersTab")]] as const).map(([k, label]) => (
            <button key={k} onClick={() => setMetric(k)} style={{
              padding: "6px 12px", fontSize: 12.5, border: "none", cursor: "pointer",
              background: metric === k ? "var(--blue-soft)" : "#fff", color: metric === k ? "var(--blue)" : "var(--muted)", fontWeight: 600,
            }}>{label}</button>
          ))}
        </div>
        <div style={{ marginLeft: "auto", fontWeight: 700, fontSize: 14 }}>
          <span style={{ color: "var(--green)" }}>{money(totals.revenue)}</span> · {totals.orders.toLocaleString()} {tr("rep.ordersWord")} ({totals.items.toLocaleString()} items)
        </div>
      </div>

      {loading && <div style={{ position: "absolute", inset: 0, background: "rgba(255,255,255,.5)", borderRadius: 18, zIndex: 5 }} />}

      <div className="rep-grid" style={{ ["--rep-side" as string]: "340px" } as React.CSSProperties}>
        {/* Stacked bar theo thời gian */}
        <div className="rep-bars" style={{ gap: buckets.length > 20 ? 3 : 8, height: H + 40 }}>
          {buckets.map((b, bi) => {
            const t = colTotal[bi];
            return (
              <div key={bi} style={{ flex: "1 1 0", minWidth: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end", height: "100%" }}
                onMouseEnter={(e) => setTip({ x: e.clientX, y: e.clientY, bi })} onMouseLeave={() => setTip(null)}>
                <div style={{ fontSize: 10.5, fontWeight: 700, marginBottom: 3, whiteSpace: "nowrap", overflow: "visible" }}>{t ? (metric === "r" ? money(t) : t) : ""}</div>
                <div style={{ width: "100%", maxWidth: 44, height: Math.max((t / max) * H, t ? 3 : 0), display: "flex", flexDirection: "column-reverse", borderRadius: 6, overflow: "hidden" }}>
                  {teams.map((s, si) => {
                    const v = s.daily[bi][metric];
                    return v ? <div key={si} style={{ height: `${(v / t) * 100}%`, background: PALETTE[si % PALETTE.length] }} /> : null;
                  })}
                </div>
                <div style={{ fontSize: 10.5, color: "var(--muted)", marginTop: 5, whiteSpace: "nowrap" }}>{b}</div>
              </div>
            );
          })}
        </div>

        {/* v474 · Bỏ donut — dành trọn cột phải cho xếp hạng team */}
        <div className="rep-side">
          <div>
            {teams.map((t, ti) => (
              <div key={ti} style={{ borderTop: "1px solid var(--line)", padding: "8px 0" }}>
                <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 3 }}>
                  <span style={{ fontSize: 11, fontWeight: 800, color: ti === 0 ? "var(--blue)" : "var(--muted)", border: "1.5px solid currentColor", borderRadius: 7, padding: "0 6px" }}>#{ti + 1}</span>
                  <span style={{ width: 9, height: 9, borderRadius: 3, background: PALETTE[ti % PALETTE.length] }} />
                  <b style={{ fontSize: 13, flex: 1 }}>{t.name}</b>
                  <b style={{ fontSize: 13.5, color: "var(--green)" }}>{money(t.revenue)}</b>
                </div>
                <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11.5, color: "var(--muted)", paddingLeft: 24 }}>
                  <span>{t.orders} {tr("rep.ordersWord")} ({t.items} items)</span>
                  <span>AOV {money(t.aov)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {tip && (
        <div style={{
          position: "fixed", left: Math.min(tip.x + 14, typeof window !== "undefined" ? window.innerWidth - 240 : tip.x), top: tip.y + 10, zIndex: 50,
          background: "#fff", border: "1px solid var(--line)", borderRadius: 12, boxShadow: "0 8px 24px rgba(17,24,39,.12)", padding: "10px 14px", minWidth: 210, pointerEvents: "none",
        }}>
          <div style={{ fontWeight: 700, fontSize: 12.5, marginBottom: 6 }}>
            {buckets[tip.bi]} — {metric === "r" ? money(colTotal[tip.bi]) : `${colTotal[tip.bi]} ${tr("rep.ordersWord")}`}
          </div>
          {teams.map((s, si) => {
            const v = s.daily[tip.bi][metric];
            return v ? (
              <div key={si} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, padding: "1.5px 0" }}>
                <span style={{ width: 9, height: 9, borderRadius: 3, background: PALETTE[si % PALETTE.length] }} />
                <span style={{ flex: 1 }}>{s.name}</span><b>{metric === "r" ? money(v) : v}</b>
              </div>
            ) : null;
          })}
        </div>
      )}
    </div>
  );
}
