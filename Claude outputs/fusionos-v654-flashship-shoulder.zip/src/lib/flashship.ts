// ===== FlashShip POD API v2 (seller) =====
// Docs: https://docs.flashship.net/
// - Base MẶC ĐỊNH: https://api2.flashship.net/seller-api-v2 — endpoint KHÔNG cần whitelist IP
//   (FlashShip support xác nhận 07/2026; api.flashship.net yêu cầu whitelist IP tĩnh, Vercel không có).
// - UAT: https://uat-api.flashship.net/seller-api-v2
// - Auth: "Authorization: Bearer <token>" — dùng API token sinh trên web (hạn 1 năm),
//   hoặc POST /token {username,password} → data.access_token (expires_in 18000s).
// - Response chung: { code: "FLS_200"|"FLS-406"|..., msg, data, err }
//   FLS-406 = hết balance → ĐƠN VẪN TẠO, payment PENDING, trả tiền trên web admin.

const FS_API = "https://api2.flashship.net/seller-api-v2";

type Cred = { accessToken: string; endpoint?: string | null };
// Timeout 20s, signal tạo MỚI mỗi lần gọi (module-level sẽ hết hạn 1 lần rồi abort mọi call sau).
const ft = () => ({ signal: AbortSignal.timeout(20000) });
const base = (c: Cred) => (c.endpoint && c.endpoint.trim() ? c.endpoint.trim().replace(/\/+$/, "") : FS_API);
const headers = (c: Cred) => ({ Authorization: `Bearer ${c.accessToken}`, "Content-Type": "application/json" }) as Record<string, string>;

type FsEnvelope = { code?: string; msg?: string; data?: unknown; err?: unknown };
const okCode = (code?: string) => !!code && /200/.test(code);
const isBalancePending = (code?: string) => !!code && /406/.test(code);

// ---- Variants: GET /orders/list-variant-sku → data: [{variant_id, product_type, brand, style, size, color}] ----
export type FsVariant = { variant_id: number; product_type: string; brand: string; style: string; size: string; color: string };
export async function listFlashshipVariants(c: Cred): Promise<FsVariant[]> {
  const r = await fetch(`${base(c)}/orders/list-variant-sku`, { headers: headers(c), ...ft() });
  const j = (await r.json().catch(() => ({}))) as FsEnvelope;
  if (!r.ok || !okCode(j.code)) throw new Error(`FlashShip list variants failed: ${j.code ?? r.status} ${j.msg ?? ""} ${JSON.stringify(j.err ?? "").slice(0, 120)}`.trim());
  return (Array.isArray(j.data) ? j.data : []) as FsVariant[];
}

// ---- Create order: POST /orders/shirt-add | /orders/ornament-add → data = order_code ----
// FlashShip TÁCH endpoint theo loại hàng. Gửi variant ORNAMENT vào shirt-add sẽ bị chặn:
//   FLS_400 "API add SHIRT can't use for variant ORNAMENT"
// Loại hàng lấy từ product_type của GET /orders/list-variant-sku (đã lưu vào skuMappings.productType
// dạng "SHIRT GILDAN G5000" / "ORNAMENT ...").
export type FsKind = "shirt" | "ornament";

/**
 * Suy ra endpoint FlashShip từ nhãn sản phẩm trong SKU mapping.
 * override = extraJson.fsKind — ép tay khi mapping nhập thủ công không có product_type.
 * Không nhận ra được thì trả "shirt" (giữ nguyên hành vi cũ, không gây hồi quy).
 */
export function flashshipKind(productLabel?: string | null, override?: unknown): FsKind {
  const o = String(override ?? "").trim().toLowerCase();
  if (o === "ornament" || o === "shirt") return o;
  return /\bORNAMENT\b/.test(String(productLabel ?? "").toUpperCase()) ? "ornament" : "shirt";
}

// Ornament chỉ in mặt trước/sau — KHÔNG có tay áo, mũ, cổ, túi, và không có DTF/DTG.
// Gửi thừa field của áo sang ornament-add là mời validation lỗi, nên lọc sạch trước khi POST.
const ORNAMENT_FIELDS = new Set<keyof FsProduct>([
  "variant_id", "quantity", "note",
  "printer_design_front_url", "printer_design_back_url",
  "mockup_front_url", "mockup_back_url",
]);
const trimForOrnament = (p: FsProduct): FsProduct => {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(p)) {
    if (ORNAMENT_FIELDS.has(k as keyof FsProduct) && v !== null && v !== undefined) out[k] = v;
  }
  return out as unknown as FsProduct;
};

export type FsProduct = {
  variant_id: number;
  quantity: number;
  note?: string;
  printType?: 1 | 2; // 1 DTF, 2 DTG — cả đơn phải cùng loại
  printer_design_front_url?: string | null;
  printer_design_back_url?: string | null;
  printer_design_right_url?: string | null;
  printer_design_left_url?: string | null;
  printer_design_neck_url?: string | null;
  printer_design_pocket_url?: string | null;
  printer_design_hood_url?: string | null;
  printer_design_neck_inner_url?: string | null;
  // v654 · in cầu vai (DTF only — doc: "URL of shoulder front/back design image, DTF only")
  printer_design_shoulder_front_url?: string | null;
  printer_design_shoulder_back_url?: string | null;
  mockup_front_url?: string | null;
  mockup_back_url?: string | null;
  mockup_right_url?: string | null;
  mockup_left_url?: string | null;
  mockup_neck_url?: string | null;
  mockup_pocket_url?: string | null;
  mockup_hood_url?: string | null;
  mockup_neck_inner_url?: string | null;
};
export type FsCreateOrder = {
  order_id: string; // partner order id — trống thì FlashShip tự sinh
  buyer_first_name: string;
  buyer_last_name?: string;
  buyer_email?: string;
  buyer_phone?: string;
  buyer_address1: string;
  buyer_address2?: string;
  buyer_city: string;
  buyer_province_code: string; // viết tắt bang US (IN, CA...)
  buyer_zip: string;
  buyer_country_code: string; // mặc định US
  shipment: number; // 1 FirstClass · 2 Priority · 3 RushProduction · 4 OverNight · 6 Expedite
  link_label?: string | null;
  products: FsProduct[];
};
export async function createFlashshipOrder(
  c: Cred, payload: FsCreateOrder, kind: FsKind = "shirt",
): Promise<{ orderCode: string; paymentPending: boolean; raw: unknown }> {
  const body: FsCreateOrder = kind === "ornament"
    ? { ...payload, products: payload.products.map(trimForOrnament) }
    : payload;
  const r = await fetch(`${base(c)}/orders/${kind}-add`, { method: "POST", headers: headers(c), body: JSON.stringify(body), ...ft() });
  const j = (await r.json().catch(() => ({}))) as FsEnvelope;
  const pending = isBalancePending(j.code);
  if (!okCode(j.code) && !pending) {
    throw new Error(`FlashShip create order failed: ${j.code ?? r.status} ${j.msg ?? ""} ${JSON.stringify(j.err ?? "").slice(0, 200)}`.trim());
  }
  const orderCode = typeof j.data === "string" ? j.data : String((j.data as Record<string, unknown>)?.order_code ?? payload.order_id);
  return { orderCode, paymentPending: pending, raw: j };
}

// ---- Cancel: POST /orders/seller-reject { order_code_list, reject_note } (status không được là COMPLETED) ----
export async function cancelFlashshipOrders(c: Cred, orderCodes: string[], note = ""): Promise<{ ok: boolean; message: string }> {
  const r = await fetch(`${base(c)}/orders/seller-reject`, {
    method: "POST", headers: headers(c),
    body: JSON.stringify({ order_code_list: orderCodes, reject_note: note }),
    ...ft(),
  });
  const j = (await r.json().catch(() => ({}))) as FsEnvelope;
  return { ok: r.ok && okCode(j.code), message: `${j.code ?? r.status} ${j.msg ?? ""}`.trim() };
}

// ---- Detail theo lô: POST /orders/list-order-code { list_order_code } (max 20/lần) ----
export type FsOrderDetail = {
  order_code: string; partner_order_id: string; status: string;
  /** FlashShip tách RIÊNG trạng thái thanh toán: "Pending" (chưa trả) / "Success" (đã trả) */
  payment?: string | null; payment_status?: string | null;
  tracking_number: string | null; tracking_status: string | null; carrier: string | null;
  total_fee: number | null; reject_note: string | null;
};
export async function getFlashshipOrdersByCodes(c: Cred, codes: string[]): Promise<FsOrderDetail[]> {
  const r = await fetch(`${base(c)}/orders/list-order-code`, {
    method: "POST", headers: headers(c),
    body: JSON.stringify({ list_order_code: codes.slice(0, 20) }),
    ...ft(),
  });
  const j = (await r.json().catch(() => ({}))) as FsEnvelope;
  if (!r.ok || (j.code && !okCode(j.code))) throw new Error(`FlashShip list-order-code failed: ${j.code ?? r.status} ${j.msg ?? ""}`.trim());
  const d = j.data ?? j;
  return (Array.isArray(d) ? d : [d].filter(Boolean)) as FsOrderDetail[];
}

// ---- Map trạng thái FlashShip → trạng thái ffo của FUSION ----
/**
 * QUY TẮC CHUNG (mọi nhà in): Push → pushed · ĐÃ TRẢ TIỀN → in_production · CÓ TRACKING → shipped.
 *
 * FlashShip có HAI cột riêng biệt:
 *   Payment: Pending  | Status: Confirmed  → đơn đã nhận nhưng CHƯA TRẢ TIỀN  → pushed
 *   Payment: Success  | Status: Producing  → ĐÃ TRẢ TIỀN, đang sản xuất       → in_production
 * ⇒ KHÔNG được coi CONFIRMED là đã trả tiền.
 * Trả "" = không đổi trạng thái hiện tại.
 */
export function mapFsStatus(status: string, trackingStatus?: string | null, hasTracking = false, payment?: string | null): string {
  const s = (status || "").toUpperCase();
  const t = (trackingStatus || "").toLowerCase();
  const p = (payment || "").toUpperCase();

  // Huỷ/hold xét TRƯỚC tracking (đơn huỷ mà có tracking không được đánh shipped)
  if (/CANCEL|REFUND|REJECT/.test(s)) return "cancelled";
  if (s === "HOLD") return "error";
  if (/deliver/.test(t)) return "delivered";
  if (hasTracking || /transit|pre-shipment|shipment|shipped|picked/.test(t)) return "shipped";

  // ĐÃ TRẢ TIỀN: payment = Success, hoặc status đã sang Producing/Completed
  const paid = /SUCCESS|PAID|COMPLET/.test(p) || /PRODUC|PROCESS|COMPLET|PRINT/.test(s);
  if (paid) return "in_production";

  // CONFIRMED + payment Pending → vẫn là "pushed" (chưa trừ tiền)
  return "";
}
