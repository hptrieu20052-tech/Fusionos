-- v598 · XOÁ MỀM STORE — seller bấm xoá store thì store chỉ ẨN đi (status='deleted'),
-- KHÔNG xoá dòng khỏi DB nữa. Nhờ vậy listing ở Manage Products · Etsy/Shopify, đơn, design
-- và mọi liên kết (etsy_products → store → seller) GIỮ NGUYÊN. Sự cố 24/9: seller xoá store
-- Etsy → listing Shopify "mất gốc", đơn webhook rơi hết về admin.
ALTER TYPE store_status ADD VALUE IF NOT EXISTS 'deleted';
