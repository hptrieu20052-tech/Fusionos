-- v602 · GALLERY ảnh cho Studio template — bộ ảnh của listing Shopify (ảnh trong sách) hiện ở
-- trang chi tiết wizard Create Your Own. Chỉ để XEM: AI vẫn chỉ gen ảnh BÌA như cũ.
ALTER TABLE studio_templates ADD COLUMN IF NOT EXISTS gallery_images jsonb NOT NULL DEFAULT '[]';
