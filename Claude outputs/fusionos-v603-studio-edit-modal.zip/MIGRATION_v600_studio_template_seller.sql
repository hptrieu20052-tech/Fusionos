-- v600 · SELLER cho Studio template ("Create Your Own"). Gán seller trên template →
-- đồng thời đóng dấu created_by lên listing Shopify tương ứng (khớp variant id) →
-- đơn khách đặt qua wizard tự chia về seller (webhook v597), thống kê ads/doanh số ăn theo.
ALTER TABLE studio_templates ADD COLUMN IF NOT EXISTS seller_id uuid;
