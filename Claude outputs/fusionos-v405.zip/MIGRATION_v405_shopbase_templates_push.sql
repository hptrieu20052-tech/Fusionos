-- v405 · ShopBase: Manage Templates + Push từ Etsy/TikTok + Manage Collections.
-- Chạy trên Supabase SQL editor. Idempotent — chạy lại không sao.

-- 1) Bảng template ShopBase (bản rút gọn của shopify_templates).
CREATE TABLE IF NOT EXISTS shopbase_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL,
  name text NOT NULL,
  thumb_url text,
  options jsonb NOT NULL DEFAULT '[]',
  variants jsonb NOT NULL DEFAULT '[]',
  collections jsonb NOT NULL DEFAULT '[]',
  status text NOT NULL DEFAULT 'DRAFT',
  product_type text,
  vendor text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_shopbase_templates_store ON shopbase_templates(store_id);

-- 2) shopbase_products: cột stage (bản nháp từ Etsy/TikTok, shopbase_product_id = '').
ALTER TABLE shopbase_products ADD COLUMN IF NOT EXISTS etsy_product_id uuid;
ALTER TABLE shopbase_products ADD COLUMN IF NOT EXISTS tiktok_product_id uuid;
ALTER TABLE shopbase_products ADD COLUMN IF NOT EXISTS template_id uuid;
CREATE INDEX IF NOT EXISTS idx_shopbase_products_etsy ON shopbase_products(etsy_product_id);
