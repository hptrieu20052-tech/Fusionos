-- v484 · STUDIO "Create Your Own" (wizard khách trên talewix.com)
-- Chạy trong Supabase SQL Editor.

CREATE TABLE IF NOT EXISTS studio_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  thumb_url text NOT NULL DEFAULT '',
  base_image_url text NOT NULL DEFAULT '',
  variant_id text NOT NULL DEFAULT '',
  price text NOT NULL DEFAULT '',
  prompt_extra text NOT NULL DEFAULT '',
  active boolean NOT NULL DEFAULT true,
  sort integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS studio_previews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id uuid REFERENCES studio_templates(id),
  child_name text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  preview_key text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  cost numeric NOT NULL DEFAULT 0,
  ip text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'done',
  error text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_studio_previews_ip ON studio_previews(ip, created_at);
CREATE INDEX IF NOT EXISTS idx_studio_previews_created ON studio_previews(created_at);

CREATE TABLE IF NOT EXISTS studio_settings (
  id text PRIMARY KEY DEFAULT 'default',
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
