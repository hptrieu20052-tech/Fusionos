-- v503 · "Của ai người đó thấy" cho store Woo share nhiều seller (mirror quy tắc v459 ShopBase):
-- ghi lại AI TẠO sản phẩm nào qua FUSION. Sản phẩm không có dòng (import Etsy cũ / tạo thẳng
-- trên Woo admin) coi như của admin: mọi seller trong store THẤY nhưng không sửa.
CREATE TABLE IF NOT EXISTS woo_product_owners (
  store_id uuid NOT NULL,
  product_id bigint NOT NULL,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (store_id, product_id)
);
