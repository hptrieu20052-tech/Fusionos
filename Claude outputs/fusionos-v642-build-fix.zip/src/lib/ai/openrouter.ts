// Tầng AI qua OPENROUTER (1 key cho mọi model: Claude/GPT/Gemini…). Env: OPENROUTER_API_KEY.
// Model text mặc định có thể override qua OPENROUTER_TEXT_MODEL. Provider-agnostic: đổi model = đổi slug.
import { getPrompt } from "@/lib/ai/prompt-store"; // system prompt Book Studio: admin ghi đè qua Manager Prompts
const OR_CHAT = "https://openrouter.ai/api/v1/chat/completions";
const KEY = () => (process.env.OPENROUTER_API_KEY ?? "").trim();
const TEXT_MODEL = () => (process.env.OPENROUTER_TEXT_MODEL ?? "anthropic/claude-3.5-sonnet").trim();

// Dọn ký tự "rác Unicode" trước khi nhét vào JSON gửi OpenRouter. Nguồn dữ liệu (title/mô tả Etsy…)
// có thể chứa emoji bị đứt đôi (lone surrogate) — hoặc do slice() cắt trúng giữa cặp surrogate.
// JSON.stringify vẫn tạo ra chuỗi "hợp lệ" nhưng provider trả HTTP 400 "no low surrogate in string".
// Xoá: (1) high surrogate không có low theo sau, (2) low surrogate không có high đứng trước,
// (3) ký tự điều khiển C0 (trừ \t \n \r) — cũng hay làm hỏng thân JSON.
function sanitizeForJSON(s: string): string {
  return String(s ?? "")
    .replace(/[\uD800-\uDBFF](?![\uDC00-\uDFFF])/g, "")
    .replace(/(?<![\uD800-\uDBFF])[\uDC00-\uDFFF]/g, "")
    // eslint-disable-next-line no-control-regex
    .replace(/[\x00-\x08\x0B\x0C\x0E-\x1F]/g, "");
}

// Gọi chat completions, ÉP trả JSON object. Ném lỗi rõ ràng để UI hiện.
//
// reasoning: model dòng suy luận (GPT-5.x, o-series, Gemini Thinking, Claude thinking) tiêu token
// SUY NGHĨ trước khi viết, và phần đó ĐẾM VÀO max_tokens. Cạn token trong lúc nghĩ ⇒ content rỗng
// kèm finish_reason=length ⇒ cả lần gọi mất trắng. Việc viết copy không cần suy luận sâu, nên các
// route copywriting truyền "low" để token dồn vào phần chữ. Model không suy luận bỏ qua field này.
export async function orChatJSON<T>(system: string, user: string, opts?: { model?: string; maxTokens?: number; temperature?: number; images?: string[]; timeoutMs?: number; reasoning?: "low" | "medium" | "high" }): Promise<T> {
  const key = KEY();
  if (!key) throw new Error("OPENROUTER_API_KEY chưa cấu hình trong env (Vercel → Settings → Environment Variables).");
  // Dọn lone-surrogate / ký tự điều khiển trước khi dựng JSON — nếu không, provider trả HTTP 400
  // "no low surrogate in string" và đổi model bao nhiêu cũng vẫn hỏng (lỗi ở dữ liệu, không ở model).
  const systemSafe = sanitizeForJSON(system);
  const userSafe = sanitizeForJSON(user);
  // Nếu có ảnh (data URL) → gửi multimodal: [text, image_url…]. Model text phải hỗ trợ vision.
  const imgs = (opts?.images ?? []).filter(Boolean);
  const userContent = imgs.length
    ? [{ type: "text", text: userSafe }, ...imgs.map((u) => ({ type: "image_url", image_url: { url: u } }))]
    : userSafe;
  let res: Response;
  try {
    res = await fetch(OR_CHAT, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
        "HTTP-Referer": "https://fusionos.app",
        "X-Title": "FUSION Book Studio",
      },
      body: JSON.stringify({
        model: opts?.model ?? TEXT_MODEL(),
        messages: [{ role: "system", content: systemSafe }, { role: "user", content: userContent }],
        response_format: { type: "json_object" },
        max_tokens: opts?.maxTokens ?? 3000,
        temperature: opts?.temperature ?? 0.8,
        ...(opts?.reasoning ? { reasoning: { effort: opts.reasoning } } : {}),
      }),
      // Fail SỚM (75s) trước mốc ~100s của Cloudflare → trả lỗi JSON rõ ràng thay vì gateway 502.
      // Route nào chạy trên Vercel maxDuration 60s PHẢI truyền timeoutMs < 60000, nếu không function
      // bị Vercel giết trước khi kịp trả lỗi JSON → client chỉ thấy "Network error" vô nghĩa.
      signal: AbortSignal.timeout(opts?.timeoutMs ?? 75000),
    });
  } catch (e) {
    const m = String((e as Error)?.message ?? e);
    if (/abort|timeout|signal|timed out/i.test(m)) throw new Error("Model text phản hồi quá lâu (>75s). Đổi Model text (⚙ Model AI) sang con NHANH: Claude Haiku / Gemini Flash / GPT‑4o‑mini; hoặc giảm số trang.");
    throw new Error("Lỗi gọi OpenRouter: " + m.slice(0, 160));
  }
  const text = await res.text();
  if (!res.ok) throw new Error(`OpenRouter HTTP ${res.status}: ${text.slice(0, 300)}`);
  let data: { choices?: { message?: { content?: string } }[] };
  try { data = JSON.parse(text); } catch { throw new Error("OpenRouter trả về không phải JSON."); }
  const content = data?.choices?.[0]?.message?.content;
  const finish = (data as { choices?: { finish_reason?: string }[] })?.choices?.[0]?.finish_reason ?? "";
  if (!content) {
    throw new Error(
      finish === "length"
        ? "Model tiêu hết token vào phần suy nghĩ nên không viết được chữ nào (finish_reason=length). Đổi Model AI sang con KHÔNG suy luận (Claude Sonnet / Gemini Flash / GPT-4o) hoặc báo dev nâng maxTokens."
        : "OpenRouter: nội dung rỗng." + (finish ? ` (finish_reason=${finish})` : ""),
    );
  }
  const parsed = parseLooseJSON<T>(content);
  if (parsed === null) {
    const cleaned = content.trim().slice(0, 200);
    throw new Error(
      finish === "length"
        ? `Model bị cắt giữa chừng vì hết max_tokens (JSON không đóng). Tăng maxTokens hoặc đổi sang model khác.`
        : "Model trả về không phải JSON hợp lệ: " + cleaned,
    );
  }
  return parsed;
}

// ===== Parse JSON "chịu lỗi" =====
// Model hay trả JSON bọc trong ```json, kèm lời dẫn, hoặc BỊ CẮT CỤT khi chạm max_tokens.
// Cắt cụt = mất trắng cả lần gọi (tốn tiền, user thấy "failed"). Ở đây ta vá lại: đóng chuỗi/ngoặc
// còn thiếu, nếu vẫn hỏng thì lùi dần về dấu phẩy trước đó để giữ các field đã hoàn chỉnh.
function scanJson(s: string) {
  const stack: string[] = []; const commas: number[] = [];
  let inStr = false, esc = false;
  for (let i = 0; i < s.length; i++) {
    const c = s[i];
    if (inStr) {
      if (esc) { esc = false; continue; }
      if (c === "\\") { esc = true; continue; }
      if (c === '"') inStr = false;
      continue;
    }
    if (c === '"') { inStr = true; continue; }
    else if (c === "{" || c === "[") stack.push(c);
    else if (c === "}" || c === "]") stack.pop();
    else if (c === "," && stack.length === 1) commas.push(i);
  }
  return { stack, inStr, esc, commas };
}
function closeWith(body: string, stack: string[]) {
  return body + stack.slice().reverse().map((c) => (c === "{" ? "}" : "]")).join("");
}
export function parseLooseJSON<T>(raw: string): T | null {
  let s = String(raw ?? "").trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  const first = s.indexOf("{");
  if (first > 0) s = s.slice(first);          // bỏ lời dẫn kiểu "Here is the JSON:"
  const tryParse = (x: string): T | null => { try { return JSON.parse(x) as T; } catch { return null; } };
  const direct = tryParse(s);
  if (direct !== null) return direct;

  // 1) Đóng nốt chuỗi/ngoặc còn dở — giữ được cả field cuối (dù nội dung bị cụt).
  const info = scanJson(s);
  let base = info.esc ? s.slice(0, -1) : s;
  if (info.inStr) base += '"'; else base = base.replace(/\s*[,:]\s*$/, "");
  const closed = tryParse(closeWith(base, info.stack));
  if (closed !== null) return closed;

  // 2) Lùi về các dấu phẩy top-level gần cuối — bỏ field dở, giữ field đã xong.
  for (let k = info.commas.length - 1, n = 0; k >= 0 && n < 6; k--, n++) {
    const cut = s.slice(0, info.commas[k]);
    const st = scanJson(cut);
    const cand = tryParse(closeWith(st.inStr ? cut + '"' : cut, st.stack));
    if (cand !== null) return cand;
  }
  return null;
}

const OR_IMAGE = "https://openrouter.ai/api/v1/images";
const IMAGE_MODEL = () => (process.env.OPENROUTER_IMAGE_MODEL ?? "google/gemini-2.5-flash-image").trim();

// Sinh 1 ẢNH: prompt + ảnh reference (giữ nhân vật). Trả base64 + media type + chi phí.
export async function orGenerateImage(prompt: string, refDataUrls: string[], opts?: { model?: string; outputFormat?: string; aspectRatio?: string; quality?: string; resolution?: string }): Promise<{ b64: string; mediaType: string; cost: number }> {
  const key = KEY();
  if (!key) throw new Error("OPENROUTER_API_KEY chưa cấu hình trong env.");
  const body: Record<string, unknown> = {
    model: opts?.model ?? IMAGE_MODEL(),
    prompt,
    output_format: opts?.outputFormat ?? "png",
  };
  if (opts?.quality) body.quality = opts.quality;          // không ép → dùng mặc định model (nhanh hơn)
  if (opts?.aspectRatio) body.aspect_ratio = opts.aspectRatio;
  if (opts?.resolution) body.resolution = opts.resolution;
  const refs = refDataUrls.filter(Boolean);
  if (refs.length) body.input_references = refs.map((u) => ({ type: "image_url", image_url: { url: u } }));
  const res = await fetch(OR_IMAGE, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json", "HTTP-Referer": "https://fusionos.app", "X-Title": "FUSION Book Studio" },
    body: JSON.stringify(body),
    // 85s < trần gateway ~100s → lỗi trả về là JSON sạch (client tự retry được), không phải 502 HTML của Cloudflare.
    signal: AbortSignal.timeout(85000),
  }).catch((e) => {
    if ((e as Error)?.name === "TimeoutError" || (e as Error)?.name === "AbortError") throw new Error("Image model timed out (>85s) — auto-retry or switch to a faster image model (Gemini Flash Image).");
    throw e;
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`OpenRouter image HTTP ${res.status}: ${text.slice(0, 300)}`);
  let data: { data?: { b64_json?: string; media_type?: string }[]; usage?: { cost?: number } };
  try { data = JSON.parse(text); } catch { throw new Error("OpenRouter image trả về không phải JSON."); }
  const img = data?.data?.[0];
  if (!img?.b64_json) throw new Error("OpenRouter image: không có ảnh trả về (" + text.slice(0, 200) + ")");
  return { b64: img.b64_json, mediaType: img.media_type ?? "image/png", cost: data?.usage?.cost ?? 0 };
}

// Danh sách model trên OpenRouter để UI chọn theo khâu.
//   text   — sinh chữ (kịch bản/ý tưởng/AI Optimize)
//   image  — vẽ/mockup
//   vision — ĐỌC được ảnh và trả ra chữ (alt text ảnh). Model text thuần mà nhét ảnh vào là lỗi,
//            nên nút alt text phải lọc theo danh sách này chứ không dùng bừa model đang chọn.
export async function listModels(type: "text" | "image" | "vision" = "text"): Promise<{ id: string; name: string }[]> {
  const key = KEY();
  const res = await fetch("https://openrouter.ai/api/v1/models", { headers: key ? { Authorization: `Bearer ${key}` } : {}, signal: AbortSignal.timeout(20000) });
  const j = (await res.json().catch(() => ({}))) as { data?: { id?: string; name?: string; architecture?: { input_modalities?: string[]; output_modalities?: string[]; modality?: string } }[] };
  const data = Array.isArray(j?.data) ? j.data : [];
  const want = type === "image" ? "image" : "text";
  const list = data
    .filter((m) => {
      const out = m?.architecture?.output_modalities;
      const mod = m?.architecture?.modality ?? "";
      const okOut = Array.isArray(out) ? out.includes(want) : (mod.split("->")[1]?.includes(want) ?? (want === "text"));
      if (!okOut || type !== "vision") return okOut;
      const inp = m?.architecture?.input_modalities;
      return Array.isArray(inp) ? inp.includes("image") : (mod.split("->")[0]?.includes("image") ?? false);
    })
    .map((m) => ({ id: String(m.id), name: String(m.name ?? m.id) }))
    .sort((a, b) => a.name.localeCompare(b.name));
  // Seedream v4 (fal.ai) không có trên OpenRouter — thêm vào CUỐI danh sách ảnh khi đã cấu hình FAL_KEY (không ưu tiên).
  if (want === "image" && (process.env.FAL_KEY ?? "").trim()) {
    list.push({ id: "fal-ai/bytedance/seedream/v4/edit", name: "Seedream v4 (fal.ai)" });
  }
  return list;
}

export type BookIdea = { name: string; hook: string; angle: string; usp: string; outline: string[] };

// Ý TƯỞNG: brief → nhiều concept đầu sách.
export async function generateBookIdeas(brief: { occasion?: string; audience?: string; pages?: number; notes?: string; count?: number; model?: string; refImages?: string[]; competitor?: string }): Promise<BookIdea[]> {
  const n = Math.min(Math.max(brief.count ?? 4, 1), 8);
  const pages = brief.pages ?? 12;
  const refs = (brief.refImages ?? []).filter(Boolean);
  const comp = (brief.competitor ?? "").trim();
  const system = await getPrompt("book.ideas");
  const user = `Sinh ${n} ý tưởng đầu sách KHÁC NHAU (mọi trường trả về bằng TIẾNG ANH).
Dịp/ngách: ${brief.occasion || "tuỳ bạn đề xuất"}
Đối tượng: ${brief.audience || "trẻ nhỏ / quà tặng cha mẹ"}
Số trang: ${pages}
Ghi chú: ${brief.notes || "không"}
${comp ? `\n===== PHÂN TÍCH ẢNH ĐỐI THỦ (BÁM SÁT) =====\n${comp}\n→ Ý tưởng của bạn PHẢI cùng NGÁCH / THỂ LOẠI với đối thủ ở trên (vd họ làm sách nàng tiên cá thì bạn cũng làm cùng ngách đó), nhưng KHÁC BIỆT & hấp dẫn hơn. Ghi rõ điểm khác biệt ở "usp". TUYỆT ĐỐI không lạc sang ngách khác.\n` : ""}
${refs.length ? `\nCÓ ĐÍNH KÈM ${refs.length} ẢNH LISTING ĐỐI THỦ. Đọc phong cách, ngách, bố cục, điểm bán; đề xuất ý tưởng CẠNH TRANH & KHÁC BIỆT (tránh sao chép).` : ""}

Mỗi ý tưởng cần:
- name: tên sách tiếng Anh hấp dẫn, chuẩn Etsy SEO
- hook: 1 câu chốt hạ vì sao khách mua
- angle: góc bán / cảm xúc chính
- usp: điểm khác biệt so với sách cùng loại (đặc biệt so với đối thủ nếu có ảnh)
- outline: mảng 4–6 câu TÓM TẮT diễn biến chính (KHÔNG cần đủ ${pages} trang — kịch bản chi tiết sẽ viết ở bước sau)

Trả JSON đúng dạng: {"ideas":[{"name":"","hook":"","angle":"","usp":"","outline":["",""]}]}`;
  const out = await orChatJSON<{ ideas: BookIdea[] }>(system, user, { maxTokens: 3000, model: brief.model, images: refs });
  return (out.ideas ?? []).map((i) => ({ name: i.name ?? "", hook: i.hook ?? "", angle: i.angle ?? "", usp: i.usp ?? "", outline: Array.isArray(i.outline) ? i.outline : [] }));
}

// BÌA: sinh TIÊU ĐỀ (baked mặt trước) + BRIEF cảnh wraparound từ chủ đề + phong cách (Bible).
export async function generateBookCover(
  concept: { name: string; occasion?: string; audience?: string; angle?: string; notes?: string },
  bible?: { artStyle?: string; palette?: string } | null,
  opts?: { model?: string; varKeys?: string[] },
): Promise<{ text: string; brief: string }> {
  // Placeholder theo ĐÚNG key biến của sách — CẤM điền tên thật (đổi biến sau này cover mới ăn theo).
  const keys = (opts?.varKeys ?? []).filter(Boolean);
  const phRule = keys.length
    ? `Personalization placeholders available: ${keys.map((k) => `{${k}}`).join(", ")}. Wherever a personalized value (child's name…) appears in the title, you MUST write the placeholder (e.g. {${keys[0]}}) — NEVER a real example name, even if the theme/notes mention one.`
    : "Keep the {name} placeholder if the story personalizes a child's name — never write a real example name.";
  const system = (await getPrompt("book.cover")) + phRule;
  const user = `Theme/title: "${concept.name}"
Occasion: ${concept.occasion || "(infer)"}
Audience: ${concept.audience || "young child / gift"}
Angle: ${concept.angle || ""}
Notes: ${concept.notes || ""}
Art style: ${bible?.artStyle || "(as set)"}
Palette: ${bible?.palette || ""}

Return EXACTLY:
{
  "text": "the cover TITLE to print on the front — short, warm; use {name} where the child's name goes (e.g. \\"God Loves {name} So Much\\"). 1 line, optional short subtitle.",
  "brief": "ONE continuous wraparound scene. RIGHT half = front: the hero (warm, magical) + a calm clear area for the title. LEFT half = back: the SAME scenery continuing seamlessly, no text, no extra characters. Match the art style & palette above."
}`;
  const out = await orChatJSON<{ text?: unknown; brief?: unknown }>(system, user, { maxTokens: 500, model: opts?.model, temperature: 0.6 });
  const str = (v: unknown) => (typeof v === "string" ? v : v == null ? "" : String(v)).trim();
  return { text: str(out?.text).slice(0, 400), brief: str(out?.brief).slice(0, 800) };
}

export type BookScriptPage = { page_no: number; text: string; illustration: string };

// KỊCH BẢN: concept → lời văn + brief từng trang. Hỗ trợ sinh THEO LÔ (from..to) để sách nhiều trang không timeout.
export async function generateBookScript(concept: { name: string; angle?: string; outline?: string[]; hook?: string; usp?: string }, opts?: { pages?: number; vars?: string[]; model?: string; from?: number; to?: number; spreadPairs?: [number, number][]; textLayout?: "split" | "both"; prevPages?: { page_no: number; text: string }[] }): Promise<BookScriptPage[]> {
  const total = opts?.pages ?? concept.outline?.length ?? 12;
  const from = Math.max(1, opts?.from ?? 1);
  const to = Math.min(total, opts?.to ?? total);
  const vars = (opts?.vars && opts.vars.length ? opts.vars : ["name"]);
  const prev = (opts?.prevPages ?? []).slice(-6);
  const system = await getPrompt("book.script");
  const user = `Book: "${concept.name}". Angle: ${concept.angle || ""}
${concept.hook ? `Hook (what makes THIS book special — weave it through every page): ${concept.hook}` : ""}
${concept.usp ? `USP: ${concept.usp}` : ""}
Outline (story arc):
${(concept.outline ?? []).map((o, i) => `${i + 1}. ${o}`).join("\n") || "(develop freely)"}
${prev.length ? `\nSTORY SO FAR (the pages right before this batch — continue the flow, and do NOT reuse their imagery or sentence patterns):\n${prev.map((p) => `p${p.page_no}: ${p.text}`).join("\n")}` : ""}

This book has ${total} pages total. Generate ONLY pages ${from} to ${to} (${to - from + 1} pages), consistent with the outline arc and previous pages.
${(opts?.spreadPairs ?? []).length ? `DOUBLE-PAGE SPREADS: pages ${(opts?.spreadPairs ?? []).map(([a, b]) => `${a}+${b}`).join(", ")} are each drawn as ONE connected artwork. The pair shares ONE illustration brief — write it on the LEFT page of the pair: ONE continuous scene flowing across both pages.
${(opts?.textLayout ?? "split") === "split"
  ? `TEXT LAYOUT (text one side · art the other): for EACH pair, write the FULL text (2–4 short gentle lines, storybook-verse feel) on ONLY ONE page and set the other page's "text" to "" (empty string). Alternate which side carries the text from pair to pair. Place the MAIN SUBJECT on the page WITHOUT text; describe the text-side half as a calm, open, softly-lit part of the same continuous scene.`
  : `TEXT LAYOUT (text on both pages): EACH page of the pair gets its own short text (1–3 sentences continuing the story). In the shared brief, keep a calm, uncluttered caption area on EACH half, and keep the main subject away from both caption areas and the center fold.`}
` : ""}- Insert personalization variables as {${vars.join("}, {")}} (e.g. {name}) in the text where natural. Use ONLY these placeholders — NEVER invent others (no {photo}, {image}, {petPhoto}…; photos are drawing references, not text).
- text: ENGLISH, 1–3 short sentences per page, warm and child-friendly.
- VARIETY (critical): every page must add a NEW concrete micro-moment — an action, a discovery, a playful question, a small surprise, dialogue, or an interaction — never just scenery + feelings. Vary sentence rhythm and openings; consecutive pages must NOT start with the same word or repeat imagery.
- BAN stock filler ("gentle breeze", "soft moonlight", "warm glow", "love wraps around you") unless the theme demands it — use specific, sensory, theme-tied details instead (what exactly does the character see/hear/touch/do?).
- ARC: build genuine progression across the book — setup → escalating adventures/moments (each different in place, activity and mood) → emotional peak → satisfying close that calls back to page 1.
- illustration: ENGLISH, CONCISE 1–2 sentences (setting · main character pose/emotion · key props · mood). Each page's scene must differ clearly from neighbors (location, time of day, activity, camera angle). Leave a calm area for a text caption. Do NOT describe any text/name drawn in the scene.

Return JSON with the ACTUAL page numbers (${from}..${to}): {"pages":[{"page_no":${from},"text":"","illustration":""}]}`;
  const out = await orChatJSON<Record<string, unknown>>(system, user, { maxTokens: 4000, model: opts?.model, temperature: 0.85 });
  // Chịu lỗi dạng: {pages:[…]} | mảng trực tiếp | object có 1 mảng bất kỳ (một số model đặt key khác).
  const asArr = (x: unknown): BookScriptPage[] | null => (Array.isArray(x) ? (x as BookScriptPage[]) : null);
  const arr: BookScriptPage[] = asArr((out as { pages?: unknown })?.pages)
    ?? asArr(out)
    ?? (asArr(Object.values(out ?? {}).find((v) => Array.isArray(v))) ?? []);
  if (!arr.length) throw new Error("Model returned no pages — try a faster/stronger text model, or click again.");
  return arr.map((p, i) => ({ page_no: Number(p?.page_no) || (from + i), text: p?.text ?? "", illustration: p?.illustration ?? "" }));
}

// ===== STYLE BIBLE + COMPOSER (prompt chi tiết từng trang) =====
// Bible = khối "bí kíp" khai báo 1 LẦN cho mỗi tựa, ráp y hệt vào MỌI trang → giữ nhân vật/phong cách nhất quán.
export type BookBible = {
  format?: string;       // khổ trang + chất lượng
  character?: string;    // đặc điểm nhân vật (khoá mặt)
  wardrobe?: string;     // trang phục/đạo cụ cố định (để trống nếu không có)
  artStyle?: string;     // phong cách vẽ
  palette?: string;      // bảng màu
  textStyle?: string;    // quy tắc chữ (baked vào ảnh)
  restrictions?: string; // danh sách cấm
};

// Bible mặc định cho sách tranh personalized trẻ nhỏ — admin chỉnh lại theo từng tựa.
export function defaultBible(): BookBible {
  return {
    format:
      "Single horizontal landscape page, aspect ratio 23:17 (print 3450×2550px at 300 DPI). " +
      "Premium, professionally published children's picture-book quality. Keep the child's face and all text safely inside the trim margins.",
    character:
      "- approximately {age} years old\n- the SAME face, hair color, hairstyle and skin tone as the attached reference photo\n- soft round cheeks\n- warm, gentle, cheerful expression\n- realistic toddler body proportions\n- kind, curious and caring personality",
    wardrobe: "",
    artStyle:
      "Premium magical children's storybook digital painting. Soft cinematic lighting, expressive but gentle facial features, " +
      "realistic fabric texture, detailed dreamy backgrounds, warm golden highlights, polished professional illustration quality.",
    palette: "deep navy blue, soft sky blue, warm cream, teal blue, glowing golden accents",
    textStyle:
      "Use a clear, elegant, child-friendly serif font. Dark navy text on a clean, light-colored area. " +
      "All words correctly spelled, easy to read and professionally typeset. Do not place text over faces or visually busy areas. " +
      "Do not add page titles, page numbers, or any extra words.",
    restrictions:
      "- No copyrighted characters, costumes, symbols or logos\n- No distorted hands, fingers, faces or body proportions\n" +
      "- No misspelled text\n- No extra children except those described in the scene\n- No dark or frightening atmosphere\n" +
      "- No harsh yellow color cast\n- No overly cartoonish or exaggerated proportions\n" +
      "- Generate the flat page artwork only — no page mockup, no hands holding the book, no surrounding background",
  };
}

export type BookSetup = { bible: BookBible; vars: { key: string; label: string; type?: "text" | "image" }[] };

// AI TỰ DỰNG Style Bible + bộ biến TỪ CHỦ ĐỀ. Đây là lời giải "1 form cho vô số chủ đề":
// form chỉ nhận mô tả chủ đề, AI sinh phần riêng (nhân vật/trang phục/màu/cấm + biến hợp chủ đề).
export async function generateBookSetup(concept: { name: string; occasion?: string; audience?: string; angle?: string; notes?: string }, opts?: { model?: string; keepStyle?: { artStyle?: string; palette?: string; textStyle?: string } }): Promise<BookSetup> {
  const system = await getPrompt("book.setup");
  const user = `Chủ đề: "${concept.name}".
Dịp/ngách: ${concept.occasion || "(tự suy luận)"}
Đối tượng: ${concept.audience || "trẻ nhỏ / quà tặng"}
Góc: ${concept.angle || ""}
Ghi chú: ${concept.notes || ""}

Sinh JSON đúng dạng:
{
  "bible": {
    "character": "đặc điểm NHÂN VẬT CHÍNH hợp chủ đề, khoá mặt theo ảnh reference; giữ placeholder {age} nếu tuổi quan trọng; gạch đầu dòng",
    "wardrobe": "trang phục/đạo cụ CỐ ĐỊNH đặc trưng chủ đề (vd đuôi tiên cá lấp lánh / áo choàng siêu anh hùng); để '' nếu chủ đề không cần",
    "artStyle": "phong cách vẽ (premium children's storybook digital painting…)",
    "palette": "bảng màu chủ đạo hợp chủ đề, liệt kê 4-6 màu",
    "textStyle": "quy tắc chữ baked: elegant child-friendly serif, dark navy on clean light area, correctly spelled, not over faces, no page numbers",
    "restrictions": "danh sách cấm phù hợp: an toàn trẻ em, không nhân vật/bản quyền, không lỗi tay/mặt, không chữ sai, flat artwork only… (gạch đầu dòng)",
    "format": "Single horizontal landscape page, aspect ratio 23:17 (print 3450×2550px at 300 DPI). Premium published picture-book quality."
  },
  "vars": [ {"key":"name","label":"Tên bé","type":"text"}, {"key":"age","label":"Tuổi","type":"text"}, … 3-6 biến HỢP CHỦ ĐỀ ]
}

QUY TẮC BIẾN (quan trọng):
- Mỗi biến có "type": "text" hoặc "image".
- Dùng "image" cho MỌI NHÂN VẬT có ẢNH THẬT của khách. Nếu chủ đề là "custom photo / face reference / dùng ảnh khách", HOẶC có nhiều người (bé, bố, mẹ, ông bà, thú cưng), thì BẮT BUỘC thêm biến ảnh cho TỪNG người: vd {"key":"babyPhoto","label":"Ảnh bé","type":"image"}, {"key":"dadPhoto","label":"Ảnh bố","type":"image"}, {"key":"momPhoto","label":"Ảnh mẹ","type":"image"}.
- Các biến còn lại (tên, tuổi, màu tóc, biệt danh, lời chúc…) để "type":"text".
- KHÔNG bỏ sót ảnh: chủ đề có bao nhiêu người dùng ảnh thật thì có bấy nhiêu biến "image".`;
  const out = await orChatJSON<BookSetup>(system, user, { maxTokens: 2500, model: opts?.model });
  const d = defaultBible();
  const rb = (out?.bible ?? {}) as BookBible;
  const bible: BookBible = {
    format: rb.format?.trim() || d.format,
    character: rb.character?.trim() || d.character,
    wardrobe: typeof rb.wardrobe === "string" ? rb.wardrobe : (d.wardrobe ?? ""),
    artStyle: rb.artStyle?.trim() || d.artStyle,
    palette: rb.palette?.trim() || d.palette,
    textStyle: rb.textStyle?.trim() || d.textStyle,
    restrictions: rb.restrictions?.trim() || d.restrictions,
  };
  // GIỮ phong cách đã KHOÁ từ ảnh mẫu (Match reference style) — không để AI vẽ lại style khác.
  const ks = opts?.keepStyle;
  if (ks?.artStyle?.trim()) bible.artStyle = ks.artStyle.trim();
  if (ks?.palette?.trim()) bible.palette = ks.palette.trim();
  if (ks?.textStyle?.trim()) bible.textStyle = ks.textStyle.trim();
  const seen = new Set<string>();
  const vars = (Array.isArray(out?.vars) ? out.vars : [])
    .map((v) => ({ key: String(v?.key ?? "").replace(/[^a-zA-Z0-9_]/g, ""), label: String(v?.label ?? v?.key ?? ""), type: (v?.type === "image" ? "image" : "text") as "text" | "image" }))
    .filter((v) => v.key && !seen.has(v.key) && (seen.add(v.key), true));
  if (!vars.some((v) => v.key === "name")) vars.unshift({ key: "name", label: "Tên bé", type: "text" });
  // Bảo hiểm: chủ đề dùng ẢNH thật mà AI quên → thêm biến ảnh nhân vật.
  const usesPhoto = /photo|ảnh|anh khach|custom photo|face|reference|chân dung|hình thật/i.test(`${concept.name} ${concept.notes ?? ""} ${concept.occasion ?? ""}`);
  if (usesPhoto && !vars.some((v) => v.type === "image")) vars.unshift({ key: "photo", label: "Ảnh nhân vật", type: "image" });
  return { bible, vars };
}

// Ráp PROMPT CHI TIẾT cho 1 trang từ Bible + brief cảnh + lời văn. Có cấu trúc như prompt "chuẩn vàng".
// baked=true → hướng dẫn AI vẽ chữ thẳng vào tranh; baked=false → chừa vùng trống, không vẽ chữ (để overlay).
export function buildMasterPrompt(opts: { bookName: string; bible?: BookBible | null; brief: string; text: string; hasRef: boolean; baked?: boolean; format?: string }): string {
  const B = { ...defaultBible(), ...(opts.bible ?? {}) };
  const baked = opts.baked !== false;
  // format override: khổ CHUẨN theo sản phẩm (vuông/ngang/spread/cover) — thắng khổ mặc định trong Bible.
  const fmt = (opts.format ?? "").trim() || B.format;
  const S: string[] = [];
  S.push(`Create a children's storybook illustration for "${opts.bookName}".`);
  S.push(`\nPAGE FORMAT:\n${fmt}`);
  S.push(
    `\nIMPORTANT CHARACTER CONSISTENCY:\n` +
    (opts.hasRef ? "Use the attached photograph of the child as the exact character reference.\n" : "") +
    `Preserve the child's recognizable features:\n${B.character}\n` +
    "Transform the child into a polished storybook illustration while keeping the face clearly recognizable. " +
    "Do not create a different child. Do not change the child's age, hair color, hairstyle, eye color, skin tone or face shape.",
  );
  if ((B.wardrobe ?? "").trim()) S.push(`\nWARDROBE & PROPS (identical on every page):\n${B.wardrobe}`);
  S.push(`\nART STYLE:\n${B.artStyle}\nColor palette: ${B.palette}`);
  S.push(`\nSCENE:\n${opts.brief || "(describe the scene for this page)"}`);
  const text = (opts.text ?? "").trim();
  if (baked && text) {
    S.push(
      `\nTEXT (render exactly, baked into the artwork):\n${B.textStyle}\n` +
      `Place this exact English text on the page:\n"${text}"\n` +
      "Leave a clean, softly-colored area for the text, away from the face and busy areas.",
    );
  } else if (text) {
    S.push(`\nTEXT AREA:\nLeave a clean, softly-colored empty area (upper or lower third) for a text caption to be overlaid later. Do NOT render any text, letters or words in the image.`);
  }
  S.push(`\nRESTRICTIONS:\n${B.restrictions}`);
  return S.join("\n");
}

// Thay biến cá nhân hoá vào prompt/chữ. Nhận {key}/[key], {label}/[label], và các PLACEHOLDER AI hay tự đặt
// như [Child's Name], {childName}, [Pet's Name]… (không phân biệt hoa/thường, dấu nháy, gạch dưới).
export function resolveVars(tpl: string, vars: { key: string; value?: string; label?: string; type?: string }[] | null | undefined): string {
  let out = tpl ?? "";
  const list = vars ?? [];
  const norm = (s: string) => String(s ?? "").toLowerCase().replace(/['’`]/g, "").replace(/[_\s]+/g, " ").trim();

  // 1) Thay theo {key}/[key] và {label}/[label].
  //    Biến ẢNH ({photo}, {dadPhoto}…) là reference vẽ — nếu lỡ lọt vào text/prompt thì XÓA token (kèm dòng trống thừa), không để chữ "{photo}" bị nướng vào tranh.
  for (const v of list) {
    const isImage = v.type === "image";
    const val = String(v.value ?? "").trim();
    if (!isImage && !val) continue;
    for (const token of [v.key, v.label]) {
      const t = String(token ?? "").trim();
      if (!t) continue;
      const esc = t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      if (isImage) out = out.replace(new RegExp(`[ \\t]*[\\{\\[]\\s*${esc}\\s*[\\}\\]][ \\t]*\\n?`, "gi"), "");
      else out = out.replace(new RegExp(`[\\{\\[]\\s*${esc}\\s*[\\}\\]]`, "gi"), () => val);
    }
  }

  // 2) Alias: bắt placeholder mô tả (AI/tiêu đề tự đặt) cho biến TÊN bé & THÚ CƯNG.
  const pick = (re: RegExp) => {
    const v = list.find((x) => re.test(norm(x.key)) || re.test(norm(x.label ?? "")));
    return String(v?.value ?? "").trim();
  };
  const nameVal = pick(/\bname\b|\bten be\b|\bten\b/);
  const petVal = pick(/\bpet\b|\bdog\b|\bcat\b|thu cung/);
  const NAME_SET = new Set(["name", "child name", "childs name", "children name", "childrens name", "kid name", "kids name", "baby name", "babys name", "the child name", "your child name", "your childs name", "first name", "childname", "little ones name"]);
  const PET_SET = new Set(["pet name", "pets name", "dog name", "dogs name", "cat name", "cats name", "petname", "the pets name", "your pets name"]);
  if (nameVal || petVal) {
    out = out.replace(/[\[\{]([^\[\]\{\}]{1,40})[\]\}]/g, (m, inner: string) => {
      const n = norm(inner);
      if (nameVal && NAME_SET.has(n)) return nameVal;
      if (petVal && PET_SET.has(n)) return petVal;
      return m;
    });
  }
  return out;
}
