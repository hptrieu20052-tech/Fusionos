import { NextRequest, NextResponse } from "next/server";
import { db, schema } from "@/lib/db";
import { and, eq, inArray, desc, or, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { levelOf } from "@/lib/rbac";
import { storeOwnerScopeIds, sharedStoreIds, adminUserIds } from "@/lib/scope";

export const dynamic = "force-dynamic";

type Variant = { id: string; price: string; compareAtPrice: string | null; sku: string; selectedOptions: { name: string; value: string }[]; inventoryQty: number | null; barcode?: string; title?: string; inventoryItemId?: string | null };
type Img = { id: string; src: string; altText: string; position: number };

// v631 · Chủ listing theo CHUỖI ETSY (giống webhook đơn v597/v623): listing chưa gán created_by
// nhưng có listing Etsy gốc → chủ = seller của store Etsy nguồn. Dùng để seller "chỉ thấy của mình".
async function etsyChainOwner(etsyPid: string | null, gid: string | null): Promise<string | null> {
  try {
    if (!etsyPid && !gid) return null;
    const conds = [
      ...(etsyPid ? [eq(schema.etsyProducts.id, etsyPid)] : []),
      ...(gid ? [eq(schema.etsyProducts.shopifyProductId, gid)] : []),
    ];
    const [e] = await db.select({ sellerId: schema.stores.sellerId }).from(schema.etsyProducts)
      .leftJoin(schema.stores, eq(schema.stores.id, schema.etsyProducts.storeId))
      .where(conds.length > 1 ? or(...conds) : conds[0]).limit(1);
    return e?.sellerId ?? null;
  } catch { return null; }
}

// GET /api/shopify-products            → danh sách (tóm tắt)
// GET /api/shopify-products?id=<uuid>  → chi tiết 1 sản phẩm (full)
export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session || (await levelOf(session, "products")) < 1) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });
  const scopeIds = await storeOwnerScopeIds(session);
  const shared = await sharedStoreIds(scopeIds);
  const id = req.nextUrl.searchParams.get("id");

  if (id) {
    const [r] = await db.select({
      p: schema.shopifyProducts, storeName: schema.stores.name, storeSeller: schema.stores.sellerId, sStoreId: schema.stores.id,
      videoCode: schema.productVideos.videoCode, videoTitle: schema.productVideos.title, videoThumbUrl: schema.productVideos.thumbUrl,
    })
      .from(schema.shopifyProducts)
      .leftJoin(schema.stores, eq(schema.stores.id, schema.shopifyProducts.storeId))
      .leftJoin(schema.productVideos, eq(schema.productVideos.id, schema.shopifyProducts.videoId))
      .where(eq(schema.shopifyProducts.id, id)).limit(1);
    if (!r) return NextResponse.json({ ok: false, error: "not found" }, { status: 404 });
    if (scopeIds && !((r.storeSeller && scopeIds.includes(r.storeSeller)) || (r.sStoreId && shared.includes(r.sStoreId)))) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });
    // v631 · SELLER CHỈ MỞ ĐƯỢC LISTING CỦA MÌNH: createdBy = mình, hoặc listing chưa gán chủ nhưng
    // listing Etsy gốc thuộc store của mình (chuỗi v597/v623). Store của CHÍNH MÌNH → thấy hết như cũ.
    if (session.role === "seller" && scopeIds && r.storeSeller !== session.sub && r.p.createdBy !== session.sub) {
      const owner = r.p.createdBy ? null : await etsyChainOwner(r.p.etsyProductId ?? null, r.p.shopifyProductId ?? null);
      if (owner !== session.sub) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });
    }
    // v567 · role khác (không phải seller/admin) giữ nếp cũ: mở được listing mình tạo / admin tạo / chưa rõ chủ.
    if (session.role !== "admin" && session.role !== "seller" && scopeIds && r.storeSeller !== session.sub && r.p.createdBy && r.p.createdBy !== session.sub) {
      const admins = await adminUserIds();
      if (!admins.includes(r.p.createdBy)) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });
    }
    return NextResponse.json({ ok: true, product: { ...r.p, storeName: r.storeName, videoCode: r.videoCode, videoTitle: r.videoTitle, videoThumbUrl: r.videoThumbUrl } });
  }

  const rows = await db.select({
    p: schema.shopifyProducts, storeName: schema.stores.name, sellerName: schema.users.fullName, storeSeller: schema.stores.sellerId, sStoreId: schema.stores.id,
    videoCode: schema.productVideos.videoCode, videoThumbUrl: schema.productVideos.thumbUrl,
  })
    .from(schema.shopifyProducts)
    .leftJoin(schema.stores, eq(schema.stores.id, schema.shopifyProducts.storeId))
    .leftJoin(schema.users, eq(schema.users.id, schema.stores.sellerId))
    .leftJoin(schema.productVideos, eq(schema.productVideos.id, schema.shopifyProducts.videoId))
    .orderBy(desc(schema.shopifyProducts.updatedAt));

  let scoped = scopeIds ? rows.filter((r) => (r.storeSeller && scopeIds.includes(r.storeSeller)) || shared.includes(r.p.storeId ?? "")) : rows;

  // v181 · Listing Etsy GỐC của từng sản phẩm (để nút "Etsy" nhảy về Manage Products · Etsy):
  //   - flow mới (v172): shopify_products.etsy_product_id
  //   - flow cũ: etsy_products.shopify_product_id = gid
  // v631 · dựng TRƯỚC bộ lọc hiển thị + kèm sellerId để tính CHỦ listing theo chuỗi Etsy.
  const linkEtsyIds = Array.from(new Set(scoped.map((r) => r.p.etsyProductId).filter(Boolean))) as string[];
  const linkGids = Array.from(new Set(scoped.map((r) => r.p.shopifyProductId).filter(Boolean))) as string[];
  const etsyRows = (linkEtsyIds.length || linkGids.length)
    ? await db.select({ id: schema.etsyProducts.id, gid: schema.etsyProducts.shopifyProductId, title: schema.etsyProducts.title, storeName: schema.stores.name, sellerName: schema.users.fullName, sellerId: schema.stores.sellerId })
        .from(schema.etsyProducts)
        .leftJoin(schema.stores, eq(schema.stores.id, schema.etsyProducts.storeId))
        .leftJoin(schema.users, eq(schema.users.id, schema.stores.sellerId))
        .where(or(
          linkEtsyIds.length ? inArray(schema.etsyProducts.id, linkEtsyIds) : sql`FALSE`,
          linkGids.length ? inArray(schema.etsyProducts.shopifyProductId, linkGids) : sql`FALSE`,
        ))
    : [];
  const etsyById = new Map(etsyRows.map((e) => [e.id, e]));
  const etsyByGid = new Map<string, typeof etsyRows[number]>();
  for (const e of etsyRows) { if (e.gid && !etsyByGid.has(e.gid)) etsyByGid.set(e.gid, e); }
  const chainOwnerOf = (r: (typeof scoped)[number]): string | null => {
    const e = (r.p.etsyProductId ? etsyById.get(r.p.etsyProductId) : undefined)
      ?? (r.p.shopifyProductId ? etsyByGid.get(r.p.shopifyProductId) : undefined);
    return e?.sellerId ?? null;
  };

  // v631 · SELLER CHỈ THẤY LISTING CỦA MÌNH (thay rule v567 "admin tạo thì ai cũng thấy"):
  //   - store CỦA CHÍNH MÌNH → thấy hết như cũ;
  //   - store share: createdBy = mình, HOẶC chưa gán chủ nhưng listing Etsy gốc thuộc store mình.
  if (session.role === "seller" && scopeIds) {
    scoped = scoped.filter((r) => r.storeSeller === session.sub || r.p.createdBy === session.sub || (!r.p.createdBy && chainOwnerOf(r) === session.sub));
  } else if (session.role !== "admin" && scopeIds) {
    // v567 · role khác (designer/support/content…) giữ nếp cũ: mình tạo + admin tạo + chưa rõ chủ.
    const admins = await adminUserIds();
    scoped = scoped.filter((r) => r.storeSeller === session.sub || !r.p.createdBy || r.p.createdBy === session.sub || admins.includes(r.p.createdBy));
  }
  // v567 · Tên người tạo từng listing (cột/filter Seller lọc theo CHỦ LISTING, không phải chủ store)
  const creatorIds = Array.from(new Set(scoped.map((r) => r.p.createdBy).filter(Boolean))) as string[];
  const creators = creatorIds.length
    ? await db.select({ id: schema.users.id, name: schema.users.fullName }).from(schema.users).where(inArray(schema.users.id, creatorIds))
    : [];
  const creatorById = new Map(creators.map((c) => [c.id, c.name]));

  // v119: SẮP XẾP MỚI → CŨ. Trước đây orderBy updated_at: cột đó bị ghi lại mỗi lần AI Optimize,
  // feed copy, Save hay Push chạm vào sản phẩm, nên chạy AI vài con là cả bảng đảo thứ tự —
  // đúng cái "lộn xộn" đang thấy. Product ID của Shopify tăng dần theo thời gian tạo ⇒ ID lớn = mới hơn.
  const pidNum = (gid: string | null) => { const m = String(gid ?? "").match(/(\d+)\s*$/); return m ? Number(m[1]) : 0; };
  // v172: bản NHÁP stage từ Etsy (chưa có Shopify ID) lên ĐẦU bảng — đó là những con đang cần
  // hoàn thiện để Push, không được để chìm xuống trang cuối vì pid = 0.
  const draftFirst = (gid: string | null) => (gid ? 0 : 1);
  scoped.sort((a, b) =>
    (draftFirst(b.p.shopifyProductId) - draftFirst(a.p.shopifyProductId)) ||
    (pidNum(b.p.shopifyProductId) - pidNum(a.p.shopifyProductId)) ||
    (new Date(b.p.createdAt ?? 0).getTime() - new Date(a.p.createdAt ?? 0).getTime()));

  // Template FUSION của từng listing: gán tay (templateId) > tự khớp theo Product type (cùng store).
  const tpls = await db.select({ id: schema.shopifyTemplates.id, storeId: schema.shopifyTemplates.storeId, name: schema.shopifyTemplates.name, productType: schema.shopifyTemplates.productType, status: schema.shopifyTemplates.status, baseDescription: schema.shopifyTemplates.baseDescription, productDetails: schema.shopifyTemplates.productDetails, shippingInfo: schema.shopifyTemplates.shippingInfo, personalization: schema.shopifyTemplates.personalization }).from(schema.shopifyTemplates);
  const byId = new Map(tpls.map((t) => [t.id, t]));
  const matchTpl = (storeId: string, productType: string | null) => {
    const list = tpls.filter((t) => t.storeId === storeId);
    const pt = (productType ?? "").trim().toLowerCase();
    if (pt) { const m = list.find((t) => (t.productType ?? "").trim().toLowerCase() === pt); if (m) return m; }
    const active = list.filter((t) => t.status === "ACTIVE");
    if (active.length === 1) return active[0];
    if (list.length === 1) return list[0];
    return null;
  };

  // v286 · Đã đẩy sang Manage Products Amazon chưa (badge AMZ) — chỉ chở tập id nguồn, rất nhẹ.
  const amzRows = await db.select({ sid: schema.amazonProducts.shopifyProductId }).from(schema.amazonProducts).catch(() => [] as { sid: string | null }[]);
  const amzSet = new Set(amzRows.map((x) => x.sid).filter(Boolean) as string[]);

  // v381 · Số ĐƠN theo listing: khớp phần SỐ của shopify_product_id ↔ order_items.etsy_listing_id
  // (giống cách webhook/Product Sales map). Loại đơn new/cancel/trash. Một query gộp → map theo id số.
  const orderCountByPid = new Map<string, number>();
  try {
    const oc = (await db.execute(sql`
      SELECT regexp_replace(coalesce(oi.etsy_listing_id, ''), '[^0-9]', '', 'g') AS pid,
             count(DISTINCT oi.order_id)::int AS n
      FROM order_items oi
      JOIN orders o ON o.id = oi.order_id
      WHERE o.status NOT IN ('new','cancel','trash')
      GROUP BY 1
    `)).rows as { pid: string; n: number }[];
    for (const r of oc) if (r.pid) orderCountByPid.set(r.pid, Number(r.n));
  } catch { /* bảng trống / lỗi → để 0 */ }

  // v596 · Số đơn ETSY của listing GỐC — cột tham khảo khi chọn design đưa vào ads (demand đã
  // chứng minh bên Etsy). etsy_products KHÔNG lưu listing id số bên Etsy nên không join id được;
  // khớp theo TITLE chuẩn hoá (lower + gộp khoảng trắng) của order item Etsy ↔ title listing Etsy
  // gốc đã link (v181). Title Etsy dài & đặc thù nên trùng giả gần như không có. Không loại đơn
  // 'new' như cột Shopify: đây là tổng demand lịch sử, chỉ bỏ cancel/trash.
  const etsyOrderByTitle = new Map<string, number>();
  try {
    const ec = (await db.execute(sql`
      SELECT lower(regexp_replace(trim(oi.product_title), '\\s+', ' ', 'g')) AS t,
             count(DISTINCT oi.order_id)::int AS n
      FROM order_items oi
      JOIN orders o ON o.id = oi.order_id
      WHERE o.platform = 'etsy' AND o.status NOT IN ('cancel','trash')
      GROUP BY 1
    `)).rows as { t: string; n: number }[];
    for (const r of ec) if (r.t) etsyOrderByTitle.set(r.t, Number(r.n));
  } catch { /* bảng trống / lỗi → để 0 */ }
  const normT = (s: string) => s.trim().toLowerCase().replace(/\s+/g, " ");

  const list = scoped.map((r) => {
    // v596 · resolve link Etsy MỘT lần — dùng cho cả etsyListing (v181) lẫn đếm đơn Etsy.
    const eln = (r.p.etsyProductId ? etsyById.get(r.p.etsyProductId) : undefined)
      ?? (r.p.shopifyProductId ? etsyByGid.get(r.p.shopifyProductId) : undefined);
    const vs = (Array.isArray(r.p.variants) ? r.p.variants as Variant[] : []);
    const prices = vs.map((v) => Number(v.price)).filter((n) => !isNaN(n) && n > 0);
    const imgs = (Array.isArray(r.p.images) ? r.p.images as Img[] : []);
    const pinned = r.p.templateId ? byId.get(r.p.templateId) ?? null : null;
    const tpl = pinned ?? matchTpl(r.p.storeId, r.p.productType);
    const tplHasFacts = !!(tpl && ((tpl.baseDescription ?? "").trim() || (tpl.productDetails ?? "").trim() || (tpl.shippingInfo ?? "").trim()));
    return {
      id: r.p.id, storeId: r.p.storeId, storeName: r.storeName, sellerName: r.sellerName,
      // v567 · chủ listing (created_by) — filter Seller lọc theo người này khi có
      createdBy: r.p.createdBy ?? null,
      creatorName: r.p.createdBy ? (creatorById.get(r.p.createdBy) ?? null) : null,
      title: r.p.title, handle: r.p.handle, status: r.p.status, dirty: r.p.dirty,
      productType: r.p.productType ?? "",
      categoryName: (r.p.category as { name?: string } | null)?.name ?? "",
      collectionTitles: (Array.isArray(r.p.collections) ? r.p.collections as { title: string }[] : []).map((c) => c.title).filter(Boolean),
      variantCount: vs.length, minPrice: prices.length ? Math.min(...prices) : null, maxPrice: prices.length ? Math.max(...prices) : null,
      mainImage: imgs[0]?.src ?? null, imageCount: imgs.length,
      // v234 · tất cả URL ảnh (theo position) để lightbox trượt qua lại cả listing.
      imageUrls: [...imgs].sort((a, b) => (a.position ?? 99) - (b.position ?? 99)).map((i) => i.src).filter(Boolean),
      // v224 · video đã gắn: thumbnail để nhận biết listing nào có video (cột Video cạnh Image).
      videoCode: r.videoCode ?? null, videoThumbUrl: r.videoThumbUrl ?? null, videoPushed: !!r.p.videoPushedAt,
      onlineStoreUrl: r.p.onlineStoreUrl, totalInventory: r.p.totalInventory,
      templateId: tpl?.id ?? null, templateName: tpl?.name ?? "", templatePinned: !!pinned, templateHasFacts: tplHasFacts,
      syncedAt: r.p.syncedAt, pushedAt: r.p.pushedAt, aiAt: r.p.aiAt,
      // v441 · đã chạy Meta ads (badge ADS)
      adsAt: r.p.adsAt,
      // v177 · Policy scan: risk + tóm tắt hit (chỉ chuỗi ngắn, không chở nguyên mảng cho nhẹ bảng).
      policyRisk: r.p.policyRisk ?? null,
      policyCheckedAt: r.p.policyCheckedAt,
      // v181 · Listing Etsy gốc (null = không có / đã xoá bên Manage Etsy)
      etsyListing: eln ? { id: eln.id, title: eln.title, store: eln.storeName ?? "", seller: eln.sellerName ?? "" } : null,
      policyHitsSummary: Array.isArray(r.p.policyHits)
        ? (r.p.policyHits as { term: string; field: string }[]).slice(0, 6).map((h) => `"${h.term}" (${h.field})`).join(", ")
        : "",
      // v191 · trả CẢ mảng hit (term/field/severity/fix) — click chip risk mở khung xem đầy đủ,
      // không phải đọc tooltip cụt. Đa số dòng là []/null nên payload không đáng kể.
      policyHits: Array.isArray(r.p.policyHits) ? r.p.policyHits : [],
      // v119: feed Merchant Center. Chỉ trả ĐỘ DÀI, không trả nguyên văn — 134 dòng × 1300 ký tự
      // là ~180KB thừa mỗi lần load bảng. Nội dung đầy đủ lấy ở GET ?id= khi mở Edit.
      feedAt: r.p.feedAt, feedTitleLen: (r.p.feedTitle ?? "").length, feedDescLen: (r.p.feedDescription ?? "").length,
      // v127: cột PIPELINE — "listing này đã chạy những gì rồi". Chỉ trả 4 CON SỐ, không trả nội dung.
      // fill-sku và image-alt đều ghi ngược variants/images về DB local ngay sau khi Shopify nhận
      // (fill-sku/route.ts:156, image-alt/route.ts:138) ⇒ 4 số này là tình trạng THẬT trên Shopify,
      // không phải phỏng đoán, và không cần bấm Sync mới thấy.
      // v141: listing đã tự đặt Custom options chưa (mảng = rồi, null = còn ăn theo template).
      // Chỉ trả CỜ + SỐ field, không trả nội dung — bảng 135 dòng không cần chở theo cả bộ câu hỏi.
      persOwn: Array.isArray(r.p.personalization),
      persCount: Array.isArray(r.p.personalization)
        ? (r.p.personalization as unknown[]).length
        : (Array.isArray(tpl?.personalization) ? (tpl!.personalization as unknown[]).length : 0),
      skuTotal: vs.length, skuDone: vs.filter((v) => String(v?.sku ?? "").trim()).length,
      altTotal: imgs.length, altDone: imgs.filter((i) => String(i?.altText ?? "").trim()).length,
      optionsSummary: (Array.isArray(r.p.options) ? r.p.options as { name: string; values: string[] }[] : []).map((o) => `${o.name}: ${o.values.length}`).join(" · "),
      // v286 · badge AMZ: đã có bản ghi bên Manage Products Amazon.
      amz: amzSet.has(r.p.id),
      // v381 · số đơn đã bán của listing (khớp theo phần số của shopify_product_id).
      orders: (() => { const d = String(r.p.shopifyProductId ?? "").replace(/\D/g, ""); return d ? (orderCountByPid.get(d) ?? 0) : 0; })(),
      // v596 · số đơn ETSY (tham khảo): title listing Etsy gốc; không có link thì thử chính title Shopify
      // (listing tạo tay nhưng trùng title với listing Etsy cũ vẫn khớp được).
      etsyOrders: etsyOrderByTitle.get(normT(eln?.title ?? "")) ?? etsyOrderByTitle.get(normT(r.p.title)) ?? 0,
    };
  });
  return NextResponse.json({ ok: true, rows: list });
}

// PATCH /api/shopify-products { id, title?, bodyHtml?, tags?, status?, vendor?, productType?, options?, variants?, images? }
// Sửa LOCAL + đánh dấu dirty (chưa Push). Không đụng Shopify tới khi bấm Push.
export async function PATCH(req: NextRequest) {
  const session = await getSession();
  if (!session || (await levelOf(session, "products")) < 2) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });
  const b = await req.json().catch(() => null);
  const id = String(b?.id ?? "").trim();
  if (!id) return NextResponse.json({ ok: false, error: "id required" }, { status: 400 });

  const [r] = await db.select({ storeSeller: schema.stores.sellerId, sStoreId: schema.stores.id, createdBy: schema.shopifyProducts.createdBy, etsyPid: schema.shopifyProducts.etsyProductId, gid: schema.shopifyProducts.shopifyProductId })
    .from(schema.shopifyProducts).leftJoin(schema.stores, eq(schema.stores.id, schema.shopifyProducts.storeId))
    .where(eq(schema.shopifyProducts.id, id)).limit(1);
  if (!r) return NextResponse.json({ ok: false, error: "not found" }, { status: 404 });
  const scopeIds = await storeOwnerScopeIds(session);
  const shared = await sharedStoreIds(scopeIds);
  if (scopeIds && !((r.storeSeller && scopeIds.includes(r.storeSeller)) || (r.sStoreId && shared.includes(r.sStoreId)))) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });
  // v567 · store share: seller sửa được listing MÌNH TẠO (rule shopbase v435); listing của người
  // khác / của admin / bản sync không rõ chủ → chỉ admin sửa. Store của mình → sửa hết như cũ.
  // v631 · nới cho SELLER: listing chưa gán created_by nhưng listing Etsy gốc thuộc store mình → vẫn là của mình.
  if (session.role !== "admin" && scopeIds && r.storeSeller !== session.sub && r.createdBy !== session.sub) {
    const owner = (session.role === "seller" && !r.createdBy) ? await etsyChainOwner(r.etsyPid ?? null, r.gid ?? null) : null;
    if (owner !== session.sub) {
      return NextResponse.json({ ok: false, error: "forbidden: this listing was created by someone else — only its creator or an admin can edit it" }, { status: 403 });
    }
  }

  const patch: Record<string, unknown> = { dirty: true, updatedAt: new Date() };
  // v631 · SELLER chỉ được sửa ẢNH (custom options đi route /personalization riêng) — mọi field khác
  // (title/mô tả/giá/variants/status/SEO…) bỏ qua lặng lẽ: UI của seller cũng không hiện các ô đó.
  const sellerImagesOnly = session.role === "seller";
  if (!sellerImagesOnly) {
    if (typeof b.title === "string" && b.title.trim()) patch.title = b.title.trim();
    if ("bodyHtml" in b) patch.bodyHtml = String(b.bodyHtml ?? "");
    if ("tags" in b) patch.tags = String(b.tags ?? "");
    if ("seoTitle" in b) patch.seoTitle = String(b.seoTitle ?? "").slice(0, 200);
    if ("seoDescription" in b) patch.seoDescription = String(b.seoDescription ?? "").slice(0, 320);
    if ("vendor" in b) patch.vendor = String(b.vendor ?? "");
    if ("productType" in b) patch.productType = String(b.productType ?? "");
    if (typeof b.status === "string" && ["ACTIVE", "DRAFT", "ARCHIVED"].includes(b.status.toUpperCase())) patch.status = b.status.toUpperCase();
    if (Array.isArray(b.options)) patch.options = b.options;   // v264 · thêm option/variant tay ở nháp
    if (Array.isArray(b.variants)) patch.variants = b.variants;
  }
  if (Array.isArray(b.images)) patch.images = b.images;

  await db.update(schema.shopifyProducts).set(patch).where(eq(schema.shopifyProducts.id, id));
  return NextResponse.json({ ok: true });
}

// DELETE /api/shopify-products { ids } — chỉ xóa bản ghi LOCAL trong FUSION (KHÔNG xóa trên Shopify).
export async function DELETE(req: NextRequest) {
  const session = await getSession();
  if (!session || (await levelOf(session, "products")) < 2) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });
  // v631 · seller chỉ được sửa ảnh + custom options — không xoá listing (kể cả bản mình tạo).
  if (session.role === "seller") return NextResponse.json({ ok: false, error: "forbidden: sellers cannot delete listings — ask an admin" }, { status: 403 });
  const b = await req.json().catch(() => null);
  const ids = (Array.isArray(b?.ids) ? b.ids : []).filter((x: unknown) => /^[0-9a-f-]{36}$/i.test(String(x)));
  if (!ids.length) return NextResponse.json({ ok: false, error: "ids required" }, { status: 400 });
  const scopeIds = await storeOwnerScopeIds(session);
  const shared = await sharedStoreIds(scopeIds);
  if (scopeIds) {
    const rows = await db.select({ id: schema.shopifyProducts.id, seller: schema.stores.sellerId, sStoreId: schema.stores.id, createdBy: schema.shopifyProducts.createdBy })
      .from(schema.shopifyProducts).leftJoin(schema.stores, eq(schema.stores.id, schema.shopifyProducts.storeId))
      .where(inArray(schema.shopifyProducts.id, ids));
    if (rows.some((r) => !((r.seller && scopeIds.includes(r.seller)) || (r.sStoreId && shared.includes(r.sStoreId))))) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });
    // v567 · store share: seller chỉ xoá listing MÌNH TẠO; của người khác/admin/bản sync → chỉ admin.
    if (session.role !== "admin" && rows.some((r) => r.seller !== session.sub && r.createdBy !== session.sub)) {
      return NextResponse.json({ ok: false, error: "forbidden: you can only delete listings you created" }, { status: 403 });
    }
  }
  await db.delete(schema.shopifyProducts).where(inArray(schema.shopifyProducts.id, ids));
  return NextResponse.json({ ok: true, deleted: ids.length });
}
