-- v449 · Số liệu Meta ads theo ngày x ad (cron /api/cron/meta-insights đồng bộ nền).
CREATE TABLE IF NOT EXISTS meta_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  day text NOT NULL,
  campaign_id text NOT NULL,
  campaign_name text,
  adset_id text NOT NULL,
  adset_name text,
  ad_id text NOT NULL,
  ad_name text,
  spend numeric(12,2),
  impressions integer,
  clicks integer,
  link_clicks integer,
  atc integer,
  purchases integer,
  revenue numeric(12,2),
  updated_at timestamptz DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_meta_insight ON meta_insights (day, ad_id);
CREATE INDEX IF NOT EXISTS idx_meta_insight_day ON meta_insights (day);
CREATE INDEX IF NOT EXISTS idx_meta_insight_camp ON meta_insights (campaign_id);
