"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import {
  IconDashboard, IconOrders, IconTruck, IconArtwork, IconReport,
  IconWallet, IconStore, IconSettings, IconProducts, IconEye, IconGrid, IconBox, IconSupport, IconMarketing, IconBell, IconSparkle, IconBook,
} from "@/components/icons";
import { useLang } from "@/components/lang-provider";
import { AmazonLogo } from "@/components/amazon-logo";
import { SHOPBASE_LOGO_SRC } from "@/components/shopbase-logo";

// Logo sàn cho nav — dùng logo MÀU bản gốc (giống trang Stores), không dùng bản đen nav-*.png.
const MK_SRC: Record<string, string> = { etsy: "/marketplaces/etsy.png", shopify: "/marketplaces/shopify.png", tiktok: "/marketplaces/tiktok.png", shopbase: SHOPBASE_LOGO_SRC };
const MarketplaceLogo = ({ mk, size = 16 }: { mk: string; size?: number }) => (
  // ShopBase: logo chính thức (data-URI). Sàn khác: dùng ảnh đã có.
  // eslint-disable-next-line @next/next/no-img-element
  <img src={MK_SRC[mk] ?? MK_SRC.shopify} alt={mk} width={size} height={size} style={{ width: size, height: size, objectFit: "contain", display: "block", flexShrink: 0, borderRadius: mk === "shopbase" ? size * 0.22 : 0 }} />
);

type P = { width?: number; height?: number; style?: React.CSSProperties };
const ICONS: Record<string, (p: P) => JSX.Element> = {
  dashboard: IconDashboard, orders: IconOrders, fulfillment: IconTruck,
  designs: IconArtwork, reviews: IconEye, statsOrders: IconReport,
  statsDesigners: IconReport, finance: IconWallet, stores: IconStore,
  settings: IconSettings, admin: IconProducts, support: IconSupport,
  ai: IconSparkle,
  // v393 · Customer Emails — top-level cho role support (cạnh Orders).
  emails: (p: P) => (
    <svg width={p.width ?? 18} height={p.height ?? 18} style={p.style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" />
    </svg>
  ),
  // v208 · Video Library — nav top-level, ngay cạnh Design Studio.
  videos: (p: P) => (
    <svg width={p.width ?? 18} height={p.height ?? 18} style={p.style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="5" width="14" height="14" rx="2" /><path d="m22 8-6 4 6 4V8Z" />
    </svg>
  ),
};

export type NavLink = { href: string; label: string; icon: string; section: string; more?: boolean };

export default function AppShell({ user, links, children, canProducts = false, canSupport = false, canMarketing = false, canFinanceTiktok = false, canBookStudio = false, canGenImage = false, canGenVideo = false }: {
  user: { name: string; role: string; avatarUrl?: string | null };
  links: NavLink[];
  children: React.ReactNode;
  canProducts?: boolean;
  canSupport?: boolean;
  canMarketing?: boolean;
  canFinanceTiktok?: boolean;
  canBookStudio?: boolean;
  canGenImage?: boolean;
  canGenVideo?: boolean;
}) {
  const path = usePathname();
  const { t } = useLang();
  // v392: "/support" không được "ăn" luôn "/support-email" (startsWith) — tách riêng.
  const isActive = (href: string) =>
    href === "/" ? path === "/"
    : href === "/support" ? (path === "/support" || path.startsWith("/support/"))
    : path.startsWith(href);

  // Trang /login KHÔNG BAO GIỜ khoác app chrome (nav/avatar) — kể cả khi session còn sống
  // (middleware đã redirect người đăng nhập khỏi /login; đây là lớp chặn thứ 2 chống flash UI).
  const isLogin = path === "/login";
  const initials = user.name.split(" ").map((w) => w[0]).slice(-2).join("").toUpperCase();
  const [moreOpen, setMoreOpen] = useState(false);
  const [prodOpen, setProdOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userOpen, setUserOpen] = useState(false);
  const [mobileHub, setMobileHub] = useState(false); // nhóm Seller Hub trên mobile (thu gọn/mở)
  const [hubGroup, setHubGroup] = useState("");      // v396: nhóm sàn đang xổ trong dropdown Seller Hub

  // Đóng drawer + mọi dropdown khi chuyển trang + khoá scroll nền khi drawer mở.
  // Tự mở nhóm Seller Hub nếu đang ở 1 trang thuộc nhóm.
  useEffect(() => {
    setMobileOpen(false); setUserOpen(false); setProdOpen(false); setMoreOpen(false); setAiOpen(false); setHubGroup("");
    const hubPaths = ["/etsy-products", "/shopify-products", "/shopify-templates", "/shopbase-products", "/amazon-products", "/amazon-templates", "/tiktok-products", "/tiktok-templates", "/support", "/support-email", "/marketing", "/tiktok-finance"];
    setMobileHub(hubPaths.some((p) => path.startsWith(p)));
  }, [path]);
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);
  // Click ra ngoài dropdown (Products / More) thì đóng
  useEffect(() => {
    if (!prodOpen && !moreOpen && !aiOpen) return;
    const onDown = (e: MouseEvent) => {
      if (!(e.target as HTMLElement)?.closest?.(".topnav-more")) { setProdOpen(false); setMoreOpen(false); setAiOpen(false); }
    };
    document.addEventListener("pointerdown", onDown);
    return () => document.removeEventListener("pointerdown", onDown);
  }, [prodOpen, moreOpen, aiOpen]);

  // HÂM NÓNG sau idle: Vercel Hobby cho lambda ngủ sau vài phút không có request →
  // click đầu tiên khi quay lại bị cold start 2–5s. Khi tab visible trở lại (hoặc window focus),
  // bắn 1 GET /api/ping chạy nền để dựng function + mở lại connection Supabase TRƯỚC khi user kịp click.
  // Throttle 60s để không spam.
  useEffect(() => {
    let last = 0;
    const warm = () => {
      const now = Date.now();
      if (now - last < 60_000) return;
      last = now;
      fetch("/api/ping", { cache: "no-store", keepalive: true }).catch(() => {});
    };
    const onVisible = () => { if (document.visibilityState === "visible") warm(); };
    warm(); // lần load đầu cũng hâm luôn
    document.addEventListener("visibilitychange", onVisible);
    window.addEventListener("focus", warm);
    // TAB MỞ NGUYÊN không chuyển tab → không có sự kiện focus/visibility khi user quay lại máy.
    // Bắt cử động chuột/phím ĐẦU TIÊN sau ≥60s im lặng để hâm nóng ngay — tay chạm chuột
    // trước khi click thật 1–2s nên lambda + connection DB kịp ấm.
    let lastAct = Date.now();
    const onAct = () => {
      const now = Date.now();
      if (now - lastAct >= 60_000) warm();
      lastAct = now;
    };
    window.addEventListener("pointermove", onAct, { passive: true });
    window.addEventListener("keydown", onAct, { passive: true });
    return () => {
      document.removeEventListener("visibilitychange", onVisible); window.removeEventListener("focus", warm);
      window.removeEventListener("pointermove", onAct); window.removeEventListener("keydown", onAct);
    };
  }, []);

  if (isLogin) return <>{children}</>;

  // Dropdown "Seller Hub" (gộp Products + Templates + Support) — sau "Design Studio"; hiện khi có quyền products HOẶC support.
  const hasDesigns = links.some((l) => !l.more && l.href === "/designs");
  // Dropdown (AI Agent / Seller Hub) chèn SAU mục cuối cùng của cụm Operations, để Video Library
  // đứng liền ngay sau Design Studio thay vì bị đẩy xuống sau các dropdown.
  const hubAnchor = links.some((l) => !l.more && l.href === "/videos") ? "/videos" : "/designs";
  const hasAnchor = links.some((l) => !l.more && l.href === hubAnchor);
  const hubActive = ["/etsy-products", "/shopify-products", "/shopify-templates", "/shopbase-products", "/amazon-products", "/amazon-templates", "/tiktok-products", "/tiktok-templates", "/support", "/support-email", "/marketing", "/tiktok-finance"].some((h) => path.startsWith(h));
  // Dropdown "AI Agent" (admin-only, beta) — ngay sau Design Studio. Gen Book (Book Studio) + Gen Image.
  const aiActive = ["/books", "/ai-image", "/ai-video", "/prompts"].some((h) => path.startsWith(h));
  const isAdminUser = user.role === "admin";
  const aiAgentDropdown = (canBookStudio || canGenImage || canGenVideo || isAdminUser) ? (
    <div key="__aiagent" className="topnav-more">
      <button className={`topnav-item${aiActive ? " active" : ""}`} onClick={() => { setProdOpen(false); setMoreOpen(false); setAiOpen((v) => !v); }}>
        <span className="topnav-ic"><IconSparkle width={17} height={17} /></span>
        AI Agent <span style={{ fontSize: 10, marginLeft: 2 }}>▾</span>
      </button>
      {aiOpen && (
        <div className="topnav-more-menu" style={{ minWidth: 0, width: "max-content" }} onClick={() => setAiOpen(false)}>
          {canBookStudio && (
            <Link href="/books" prefetch className={`topnav-more-item${isActive("/books") ? " active" : ""}`}>
              <span className="topnav-ic"><IconBook width={16} height={16} /></span>
              Gen Book
            </Link>
          )}
          {(canGenImage || isAdminUser) && (
            <Link href="/ai-image" prefetch className={`topnav-more-item${isActive("/ai-image") ? " active" : ""}`}>
              <span className="topnav-ic"><IconArtwork width={16} height={16} /></span>
              Gen Image
            </Link>
          )}
          {(canGenVideo || isAdminUser) && (
            <Link href="/ai-video" prefetch className={`topnav-more-item${isActive("/ai-video") ? " active" : ""}`}>
              <span className="topnav-ic">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="5" width="14" height="14" rx="2" /><path d="m22 8-6 4 6 4V8Z" /></svg>
              </span>
              Gen Video
            </Link>
          )}
          {isAdminUser && (
            <Link href="/prompts" prefetch className={`topnav-more-item${isActive("/prompts") ? " active" : ""}`}>
              <span className="topnav-ic">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><line x1="4" y1="21" x2="4" y2="14" /><line x1="4" y1="10" x2="4" y2="3" /><line x1="12" y1="21" x2="12" y2="12" /><line x1="12" y1="8" x2="12" y2="3" /><line x1="20" y1="21" x2="20" y2="16" /><line x1="20" y1="12" x2="20" y2="3" /><line x1="1" y1="14" x2="7" y2="14" /><line x1="9" y1="8" x2="15" y2="8" /><line x1="17" y1="16" x2="23" y2="16" /></svg>
              </span>
              Manager Prompts
            </Link>
          )}
        </div>
      )}
    </div>
  ) : null;

  // v396: Seller Hub gọn — gom theo SÀN. Sàn có nhiều trang (Shopify/Amazon/TikTok) là nhóm
  // bấm để xổ dòng con; sàn 1 trang (Etsy/ShopBase) và mục chung (Product Sales, Customer Emails)
  // vẫn là link thẳng. Nhóm chứa trang đang mở sẽ tự xổ sẵn khi mở dropdown.
  type HubNode =
    | { t: "link"; href: string; label: string; icon: JSX.Element }
    | { t: "group"; key: string; label: string; icon: JSX.Element; children: { href: string; label: string }[] };
  const hubNodes: HubNode[] = [
    ...(canProducts ? [
      // Etsy/ShopBase hiện mới 1 trang nhưng vẫn để dạng nhóm — sau này thêm trang chỉ cần thêm children.
      { t: "group", key: "etsy", label: "Etsy", icon: <MarketplaceLogo mk="etsy" size={16} />, children: [
        { href: "/etsy-products", label: "Manage Products" },
      ] },
      { t: "group", key: "shopify", label: "Shopify", icon: <MarketplaceLogo mk="shopify" size={16} />, children: [
        { href: "/shopify-products", label: "Manage Products" },
        { href: "/shopify-templates", label: "Manage Templates" },
      ] },
      { t: "group", key: "shopbase", label: "ShopBase", icon: <MarketplaceLogo mk="shopbase" size={16} />, children: [
        { href: "/shopbase-products", label: "Manage Products" },
      ] },
      { t: "group", key: "amazon", label: "Amazon", icon: <AmazonLogo size={16} />, children: [
        { href: "/amazon-products", label: "Manage Products" },
        { href: "/amazon-templates", label: "Manage Templates" },
      ] },
    ] as HubNode[] : []),
    ...((canProducts || canSupport || canMarketing || canFinanceTiktok) ? [{
      t: "group", key: "tiktok", label: "TikTok", icon: <MarketplaceLogo mk="tiktok" size={16} />, children: [
        ...(canProducts ? [{ href: "/tiktok-products", label: "Manage Products" }, { href: "/tiktok-templates", label: "Manage Templates" }] : []),
        ...(canSupport ? [{ href: "/support", label: "Customer Messages" }] : []),
        ...(canMarketing ? [{ href: "/marketing", label: "Marketing" }] : []),
        ...(canFinanceTiktok ? [{ href: "/tiktok-finance", label: "Finance" }] : []),
      ],
    }] as HubNode[] : []),
    ...(canProducts ? [{
      t: "link", href: "/stats/products", label: "Product Sales",
      icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="21" x2="21" y2="21" /><rect x="5" y="11" width="3.5" height="7" /><rect x="10.25" y="7" width="3.5" height="11" /><rect x="15.5" y="4" width="3.5" height="14" /></svg>,
    }] as HubNode[] : []),
    // v393: Customer Emails trong Seller Hub CHỈ cho admin — role support có link top-level cạnh Orders.
    ...(canSupport && user.role === "admin" ? [{
      t: "link", href: "/support-email", label: "Customer Emails",
      icon: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></svg>,
    }] as HubNode[] : []),
  ].filter((n) => n.t === "link" || n.children.length > 0);
  const groupOfPath = () => {
    for (const n of hubNodes) if (n.t === "group" && n.children.some((c) => isActive(c.href))) return n.key;
    return "";
  };

  const productsDropdown = (canProducts || canSupport || canMarketing || canFinanceTiktok) ? (
    <div key="__sellerhub" className="topnav-more">
      <button className={`topnav-item${hubActive ? " active" : ""}`} onClick={() => { setAiOpen(false); setMoreOpen(false); if (!prodOpen) setHubGroup(groupOfPath()); setProdOpen((v) => !v); }}>
        <span className="topnav-ic"><IconBox width={17} height={17} /></span>
        Seller Hub <span style={{ fontSize: 10, marginLeft: 2 }}>▾</span>
      </button>
      {prodOpen && (
        <div className="topnav-more-menu" onClick={() => setProdOpen(false)}>
          {hubNodes.map((n) => n.t === "link" ? (
            <Link key={n.href} href={n.href} prefetch className={`topnav-more-item${isActive(n.href) ? " active" : ""}`}>
              <span className="topnav-ic">{n.icon}</span>
              {n.label}
            </Link>
          ) : (
            <div key={n.key}>
              <button
                type="button"
                className={`topnav-more-item${n.children.some((c) => isActive(c.href)) || hubGroup === n.key ? " active" : ""}`}
                style={{ width: "100%", background: hubGroup === n.key ? "var(--blue-soft)" : "none", border: 0, cursor: "pointer", textAlign: "left" }}
                onClick={(e) => { e.stopPropagation(); setHubGroup((g) => (g === n.key ? "" : n.key)); }}
              >
                <span className="topnav-ic">{n.icon}</span>
                {n.label}
                <span style={{ marginLeft: "auto", paddingLeft: 18, fontSize: 10, transform: hubGroup === n.key ? "rotate(90deg)" : "none", transition: "transform .15s" }}>▸</span>
              </button>
              {hubGroup === n.key && (
                <div style={{ margin: "2px 0 4px 22px", paddingLeft: 6, borderLeft: "2px solid var(--line)", display: "flex", flexDirection: "column", gap: 2 }}>
                  {n.children.map((c) => (
                    <Link key={c.href} href={c.href} prefetch className={`topnav-more-item${isActive(c.href) ? " active" : ""}`} style={{ padding: "7px 12px", fontSize: 13 }}>
                      {c.label}
                    </Link>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  ) : null;

  return (
    <div className="app">
      <header className="topnav">
        <div className="topnav-inner">
          {/* Hamburger — chỉ hiện trên mobile */}
          <button type="button" className="topnav-burger" aria-label="Menu" onClick={() => setMobileOpen((v) => !v)}>
            {mobileOpen
              ? <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>
              : <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round"><path d="M4 7h16M4 12h16M4 17h16" /></svg>}
          </button>
          <Link href="/" className="topnav-brand">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/Logo-full.png" alt="Fusion" />
          </Link>
          <nav className="topnav-menu">
            {links.filter((l) => !l.more).flatMap((l) => {
              const Icon = ICONS[l.icon] ?? IconDashboard;
              const el = (
                <Link key={l.href} href={l.href} prefetch className={`topnav-item${isActive(l.href) ? " active" : ""}`}>
                  <span className="topnav-ic"><Icon width={17} height={17} /></span>
                  {t(l.label)}
                </Link>
              );
              // AI Agent + Seller Hub dropdown nằm ngay sau cụm Design Studio / Video Library
              return l.href === hubAnchor ? [el, aiAgentDropdown, productsDropdown].filter(Boolean) as JSX.Element[] : [el];
            })}
            {/* Fallback: không thấy Design Studio lẫn Video Library thì vẫn hiện AI Agent / Products */}
            {!hasAnchor && aiAgentDropdown}
            {!hasAnchor && productsDropdown}
            {links.some((l) => l.more) && (
              <div className="topnav-more">
                <button className={`topnav-item${links.some((l) => l.more && isActive(l.href)) ? " active" : ""}`} onClick={() => { setAiOpen(false); setProdOpen(false); setMoreOpen((v) => !v); }}>
                  <span className="topnav-ic"><IconGrid width={17} height={17} /></span>
                  {t("nav.more")} <span style={{ fontSize: 10, marginLeft: 2 }}>▾</span>
                </button>
                {moreOpen && (
                  <div className="topnav-more-menu" onClick={() => setMoreOpen(false)}>
                    {links.filter((l) => l.more).map((l) => {
                      const Icon = ICONS[l.icon] ?? IconDashboard;
                      return (
                        <Link key={l.href} href={l.href} prefetch className={`topnav-more-item${isActive(l.href) ? " active" : ""}`}>
                          <span className="topnav-ic"><Icon width={16} height={16} /></span>
                          {t(l.label)}
                        </Link>
                      );
                    })}
                  </div>
                )}
              </div>
            )}
          </nav>
          <NotificationBell />
          <div className="topnav-user" style={{ position: "relative" }}>
            <button type="button" className="topnav-avatar-btn" onClick={() => setUserOpen((v) => !v)} aria-label="Account menu">
              <div className="user-avatar">{user.avatarUrl ? <img src={user.avatarUrl} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: "inherit", display: "block" }} /> : initials}</div>
              <div className="tb-user-txt">
                <span className="tb-user-name">{user.name}</span>
                <span className="tb-role">{user.role === "content" ? "creator" : user.role}</span>
              </div>
              <svg className="tb-caret" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"><path d="M6 9l6 6 6-6" /></svg>
            </button>
            {userOpen && (
              <>
                <div style={{ position: "fixed", inset: 0, zIndex: 94 }} onClick={() => setUserOpen(false)} />
                <div className="topnav-more-menu" style={{ minWidth: 200 }} onClick={() => setUserOpen(false)}>
                  <div style={{ padding: "8px 12px 6px", borderBottom: "1px solid var(--line)", marginBottom: 4 }}>
                    <div style={{ fontWeight: 800, fontSize: 13 }}>{user.name}</div>
                    <div style={{ fontSize: 11, color: "var(--muted)", textTransform: "uppercase", fontWeight: 700 }}>{user.role === "content" ? "creator" : user.role}</div>
                  </div>
                  <Link href="/account" prefetch className="topnav-more-item">
                    <span className="topnav-ic"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" /></svg></span>
                    Account settings
                  </Link>
                  <button type="button" className="topnav-more-item" style={{ width: "100%", background: "none", border: "none", cursor: "pointer", font: "inherit", textAlign: "left", color: "var(--red)" }}
                    onClick={async () => { await fetch("/api/auth/logout", { method: "POST" }); location.href = "/login"; }}>
                    <span className="topnav-ic" style={{ color: "var(--red)" }}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" /></svg></span>
                    Log out
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Drawer menu mobile: danh sách phẳng, gọn như desktop */}
      {mobileOpen && (
        <div className="mobile-nav-overlay" onClick={() => setMobileOpen(false)}>
          <nav className="mobile-nav" onClick={(e) => e.stopPropagation()}>
            {links.flatMap((l) => {
              const Icon = ICONS[l.icon] ?? IconDashboard;
              const el = (
                <Link key={l.href} href={l.href} prefetch className={`mobile-nav-item${isActive(l.href) ? " active" : ""}`}>
                  <span className="topnav-ic"><Icon width={18} height={18} /></span>
                  {t(l.label)}
                </Link>
              );
              // Sau "Design Studio": chèn nhóm Seller Hub thu gọn (bấm để mở) — gom Products/Templates/Customer Messages/Marketing/Finance.
              if (l.href === hubAnchor && (canProducts || canSupport || canMarketing || canFinanceTiktok)) {
                const hubItems = [
                  ...(canProducts ? [
                    { href: "/shopbase-products", icon: <MarketplaceLogo mk="shopbase" size={18} />, label: "Manage Products ShopBase" },
                    { href: "/amazon-products", icon: <AmazonLogo size={18} />, label: "Manage Products Amazon" },
                    { href: "/amazon-templates", icon: <AmazonLogo size={18} />, label: "Manage Templates Amazon" },
                    { href: "/tiktok-products", icon: <MarketplaceLogo mk="tiktok" size={18} />, label: "Manage Products Tiktok" },
                    { href: "/tiktok-templates", icon: <MarketplaceLogo mk="tiktok" size={18} />, label: "Manage Templates Tiktok" },
                  ] : []),
                  ...(canSupport && user.role === "admin" ? [
                    { href: "/support-email", icon: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></svg>, label: "Customer Emails" },
                  ] : []),
                  ...(canSupport ? [
                    { href: "/support", icon: <IconSupport width={18} height={18} />, label: "Customer Messages Tiktok" },
                  ] : []),
                  ...(canMarketing ? [{ href: "/marketing", icon: <IconMarketing width={18} height={18} />, label: "Marketing Tiktok" }] : []),
                  ...(canFinanceTiktok ? [{ href: "/tiktok-finance", icon: <IconWallet width={18} height={18} />, label: "Finance Tiktok" }] : []),
                ];
                const hubActive = hubItems.some((h) => isActive(h.href));
                return [el,
                  <div key="__hub">
                    <button type="button" onClick={() => setMobileHub((v) => !v)}
                      className={`mobile-nav-item${hubActive ? " active" : ""}`}
                      style={{ width: "100%", background: "none", border: 0, fontFamily: "inherit", cursor: "pointer", textAlign: "left" }}>
                      <span className="topnav-ic"><IconBox width={18} height={18} /></span>
                      Seller Hub
                      <span style={{ marginLeft: "auto", fontSize: 12, opacity: 0.7 }}>{mobileHub ? "▾" : "▸"}</span>
                    </button>
                    {mobileHub && hubItems.map((h) => (
                      <Link key={h.href} href={h.href} prefetch className={`mobile-nav-item${isActive(h.href) ? " active" : ""}`} style={{ paddingLeft: 34 }}>
                        <span className="topnav-ic">{h.icon}</span>
                        {h.label}
                      </Link>
                    ))}
                  </div>,
                ];
              }
              return [el];
            })}
            {!hasDesigns && canProducts && (
              <Link href="/etsy-products" prefetch className={`mobile-nav-item${isActive("/etsy-products") ? " active" : ""}`}>
                <span className="topnav-ic"><MarketplaceLogo mk="etsy" size={18} /></span>
                Manage Products Etsy
              </Link>
            )}
            {!hasDesigns && canProducts && (
              <Link href="/shopify-products" prefetch className={`mobile-nav-item${isActive("/shopify-products") ? " active" : ""}`}>
                <span className="topnav-ic"><MarketplaceLogo mk="shopify" size={18} /></span>
                Manage Products Shopify
              </Link>
            )}
            {!hasDesigns && canProducts && (
              <Link href="/shopify-templates" prefetch className={`mobile-nav-item${isActive("/shopify-templates") ? " active" : ""}`}>
                <span className="topnav-ic"><MarketplaceLogo mk="shopify" size={18} /></span>
                Manage Templates Shopify
              </Link>
            )}
            {!hasDesigns && canProducts && (
              <Link href="/tiktok-products" prefetch className={`mobile-nav-item${isActive("/tiktok-products") ? " active" : ""}`}>
                <span className="topnav-ic"><MarketplaceLogo mk="tiktok" size={18} /></span>
                Manage Products Tiktok
              </Link>
            )}
            {!hasDesigns && canSupport && user.role === "admin" && (
              <Link href="/support-email" prefetch className={`mobile-nav-item${isActive("/support-email") ? " active" : ""}`}>
                <span className="topnav-ic">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></svg>
                </span>
                Customer Emails
              </Link>
            )}
            {!hasDesigns && canSupport && (
              <Link href="/support" prefetch className={`mobile-nav-item${isActive("/support") ? " active" : ""}`}>
                <span className="topnav-ic"><IconSupport width={18} height={18} /></span>
                Customer Messages Tiktok
              </Link>
            )}
            {!hasDesigns && canMarketing && (
              <Link href="/marketing" prefetch className={`mobile-nav-item${isActive("/marketing") ? " active" : ""}`}>
                <span className="topnav-ic"><IconMarketing width={18} height={18} /></span>
                Marketing Tiktok
              </Link>
            )}
          </nav>
        </div>
      )}

      <main className="app-content">{children}</main>
      <BackToTop />
    </div>
  );
}

// Nút kéo lên đầu trang — hiện khi cuộn xuống >400px (Design Studio / Orders dài lướt mỏi tay)
function BackToTop() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const onScroll = () => setShow(window.scrollY > 400);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  if (!show) return null;
  return (
    <button type="button" aria-label="Back to top" title="Back to top"
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      style={{
        position: "fixed", right: 22, bottom: 24, zIndex: 90,
        width: 44, height: 44, borderRadius: "50%", border: "none", cursor: "pointer",
        background: "var(--blue)", color: "#fff", boxShadow: "0 4px 14px rgba(0,0,0,.22)",
        display: "grid", placeItems: "center",
      }}>
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round">
        <path d="M6 14l6-6 6 6" />
      </svg>
    </button>
  );
}

// ===== Chuông thông báo — hiện tại chỉ báo khi có bản EXTENSION mới (admin publish) =====
function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [ver, setVer] = useState<{ version: string; notes?: string } | null>(null);
  const [seen, setSeen] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    try { setSeen(localStorage.getItem("fusion_seen_ext_ver")); } catch { /* ignore */ }
    fetch("/api/extension/version", { cache: "no-store" })
      .then((r) => r.json())
      .then((j) => { if (alive && j?.version) setVer({ version: String(j.version), notes: j.notes }); })
      .catch(() => {});
    return () => { alive = false; };
  }, []);

  // Có bản mới nếu version tải về khác với version user đã xem lần cuối.
  const hasNew = !!(ver && ver.version && ver.version !== seen);
  const markSeen = () => { if (ver?.version) { try { localStorage.setItem("fusion_seen_ext_ver", ver.version); } catch { /* ignore */ } setSeen(ver.version); } };

  return (
    <div style={{ position: "relative", marginRight: 6 }}>
      <button type="button" aria-label="Notifications" onClick={() => { setOpen((v) => !v); if (!open) markSeen(); }}
        style={{ position: "relative", width: 38, height: 38, borderRadius: 10, border: "1px solid var(--line)", background: "var(--card)", cursor: "pointer", display: "grid", placeItems: "center", color: "var(--muted)" }}>
        <IconBell width={18} height={18} />
        {hasNew && <span style={{ position: "absolute", top: 7, right: 8, width: 8, height: 8, borderRadius: "50%", background: "#E5484D", border: "2px solid var(--card)" }} />}
      </button>
      {open && (
        <>
          <div style={{ position: "fixed", inset: 0, zIndex: 94 }} onClick={() => setOpen(false)} />
          <div className="topnav-more-menu" style={{ minWidth: 288, right: 0, zIndex: 95 }}>
            <div style={{ padding: "9px 13px 7px", borderBottom: "1px solid var(--line)", fontWeight: 800, fontSize: 13 }}>Notifications</div>
            {ver ? (
              <a href="/extension/" target="_blank" rel="noreferrer" className="topnav-more-item" style={{ alignItems: "flex-start", gap: 9, whiteSpace: "normal", padding: "10px 13px" }}>
                <span className="topnav-ic" style={{ marginTop: 1 }}><IconBox width={17} height={17} /></span>
                <span>
                  <span style={{ fontWeight: 700, fontSize: 12.5 }}>Fusion Etsy Extension v{ver.version}</span>
                  <span style={{ display: "block", fontSize: 11.5, color: "var(--muted)", marginTop: 2 }}>
                    {hasNew ? "New version available — click to download & update ↗" : (ver.notes && ver.notes !== "bundled" ? ver.notes : "You're on the latest version.")}
                  </span>
                </span>
              </a>
            ) : (
              <div style={{ padding: "14px 13px", fontSize: 12.5, color: "var(--muted)" }}>No new notifications.</div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
