-- v394 · Support Email FOLDERS (Inbox/Sent/Archive/Spam/Trash/Drafts) — chạy trên Supabase SQL editor.
-- Chạy SAU MIGRATION_v393_support_email_multi.sql.
ALTER TABLE support_email_messages ADD COLUMN IF NOT EXISTS folder text NOT NULL DEFAULT 'inbox';
CREATE INDEX IF NOT EXISTS idx_sup_email_msgs_folder ON support_email_messages (folder);
