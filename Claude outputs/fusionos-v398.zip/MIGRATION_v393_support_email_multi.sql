-- v393 · Support Email MULTI-MAILBOX — chạy trên Supabase SQL editor.
-- Bao gồm luôn phần v392 (idempotent): chưa chạy v392 thì chỉ cần chạy file này;
-- đã chạy v392 rồi thì chạy tiếp file này cũng không sao (IF NOT EXISTS toàn bộ).

-- Hộp thư (account) — admin quản lý trong FUSION, mật khẩu mã hoá AES-256-GCM trước khi lưu.
CREATE TABLE IF NOT EXISTS support_email_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL,
  email text NOT NULL,
  from_name text,
  imap_host text NOT NULL DEFAULT 'mail.privateemail.com',
  imap_port integer NOT NULL DEFAULT 993,
  smtp_host text NOT NULL DEFAULT 'mail.privateemail.com',
  smtp_port integer NOT NULL DEFAULT 465,
  pass_enc text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  last_sync_at timestamptz,
  last_sync_error text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_sup_email_accounts_email ON support_email_accounts (email);

CREATE TABLE IF NOT EXISTS support_email_threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id uuid REFERENCES support_email_accounts(id),
  customer_email text NOT NULL,
  customer_name text,
  subject text NOT NULL DEFAULT '',
  status text NOT NULL DEFAULT 'open',
  last_direction text NOT NULL DEFAULT 'in',
  last_message_at timestamptz NOT NULL DEFAULT now(),
  last_snippet text NOT NULL DEFAULT '',
  unread boolean NOT NULL DEFAULT true,
  msg_count integer NOT NULL DEFAULT 0,
  assigned_to uuid REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
-- Nếu đã chạy v392 trước đó: bổ sung cột account_id cho bảng cũ.
ALTER TABLE support_email_threads ADD COLUMN IF NOT EXISTS account_id uuid REFERENCES support_email_accounts(id);
CREATE INDEX IF NOT EXISTS idx_sup_email_threads_last ON support_email_threads (last_message_at);
CREATE INDEX IF NOT EXISTS idx_sup_email_threads_customer ON support_email_threads (customer_email);
CREATE INDEX IF NOT EXISTS idx_sup_email_threads_account ON support_email_threads (account_id);

CREATE TABLE IF NOT EXISTS support_email_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES support_email_threads(id),
  direction text NOT NULL,
  message_id text,
  in_reply_to text,
  refs text,
  from_email text NOT NULL,
  from_name text,
  to_email text,
  subject text,
  body_text text,
  body_html text,
  attachments jsonb NOT NULL DEFAULT '[]',
  sent_by_user_id uuid REFERENCES users(id),
  message_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sup_email_msgs_thread ON support_email_messages (thread_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_sup_email_msgs_mid ON support_email_messages (message_id);
