-- v406 · ShopBase templates: Description chuẩn + Estimated delivery (business days).
-- Chạy trên Supabase SQL editor. Idempotent.
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS description text;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS ship_proc_min integer;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS ship_proc_max integer;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS ship_us_min integer;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS ship_us_max integer;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS ship_intl_min integer;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS ship_intl_max integer;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS ship_cutoff_hour integer;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS ship_countries jsonb NOT NULL DEFAULT '{}';
