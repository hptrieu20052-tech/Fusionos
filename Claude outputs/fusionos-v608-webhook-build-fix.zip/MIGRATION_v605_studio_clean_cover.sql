-- v605 · BÌA SẠCH (không watermark) cho đơn Studio — khi gen lưu THÊM bản sạch; khách vẫn chỉ
-- thấy bản watermark, còn card đơn trong FUSION + tab Leads đính bản sạch cho seller/designer.
ALTER TABLE studio_previews ADD COLUMN IF NOT EXISTS clean_key text NOT NULL DEFAULT '';
ALTER TABLE studio_previews ADD COLUMN IF NOT EXISTS clean_back_key text NOT NULL DEFAULT '';
