import { NextRequest, NextResponse } from "next/server";
import { db, schema } from "@/lib/db";
import { and, eq, ne } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { shopbaseHost, shopbaseConfigured, getShopBaseCred } from "@/lib/shopbase";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * v482 · PROBE API COLLECTION SHOPBASE (admin-only, CHỈ GET — không ghi gì).
 *
 * Mục đích: xác định private app có mở endpoint collection nào không, để biết có thể
 * SYNC collection trực tiếp thay cho cơ chế tag (v417) hay không. Lần dò v417 mới thử
 * custom_collections (404) và collections (401) — lần này quét đủ các ứng viên kiểu Shopify.
 *
 * Cách dùng: đăng nhập ADMIN rồi mở
 *   /api/shopbase-collections/probe            → store ShopBase mới nhất
 *   /api/shopbase-collections/probe?store=<id> → store chỉ định
 * Kết quả: status + 220 ký tự đầu body của từng endpoint. 200 = endpoint MỞ.
 */
export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session || session.role !== "admin") return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });

  const q = String(req.nextUrl.searchParams.get("store") ?? "").trim();
  const got = await getShopBaseCred(/^[0-9a-f-]{36}$/i.test(q) ? q : undefined);
  if (!got || !shopbaseConfigured(got.cred)) return NextResponse.json({ ok: false, error: "ShopBase store not configured" }, { status: 400 });

  // Sample product id (đã có trên ShopBase) để thử endpoint gắn theo product.
  const [sp] = await db.select({ pid: schema.shopbaseProducts.shopbaseProductId }).from(schema.shopbaseProducts)
    .where(and(eq(schema.shopbaseProducts.storeId, got.storeId), ne(schema.shopbaseProducts.shopbaseProductId, ""))).limit(1);

  const host = shopbaseHost(got.cred);
  const auth = Buffer.from(`${String(got.cred.apiKey ?? "").trim()}:${String(got.cred.password ?? "").trim()}`).toString("base64");

  const paths = [
    "collections.json?limit=1",
    "collections/count.json",
    "custom_collections.json?limit=1",
    "custom_collections/count.json",
    "smart_collections.json?limit=1",
    "smart_collections/count.json",
    "collects.json?limit=1",
    "collection_listings.json?limit=1",
    ...(sp?.pid ? [`products/${sp.pid}/collections.json`, `collects.json?product_id=${sp.pid}&limit=5`] : []),
  ];

  const results: { path: string; status: number | string; body: string }[] = [];
  for (const p of paths) {
    try {
      const res = await fetch(`https://${host}/admin/${p}`, {
        headers: { Authorization: `Basic ${auth}`, Accept: "application/json" },
        signal: AbortSignal.timeout(15000),
      });
      results.push({ path: p, status: res.status, body: (await res.text()).slice(0, 220) });
    } catch (e) {
      results.push({ path: p, status: "ERR", body: String((e as Error)?.message ?? e).slice(0, 160) });
    }
  }
  return NextResponse.json({ ok: true, host, sampleProductId: sp?.pid ?? null, results });
}
