-- v488 · Studio: wizard cho khách chọn size/paper — template lưu danh sách variants.
-- Chạy trong Supabase SQL Editor.
ALTER TABLE studio_templates ADD COLUMN IF NOT EXISTS variants jsonb NOT NULL DEFAULT '[]'::jsonb;
