-- v490 · Studio: trang chi tiết sách trong wizard (description / age range / pages).
-- Chạy CÙNG với MIGRATION_v488 nếu chưa chạy. Supabase SQL Editor.
ALTER TABLE studio_templates ADD COLUMN IF NOT EXISTS variants jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE studio_templates ADD COLUMN IF NOT EXISTS description text NOT NULL DEFAULT '';
ALTER TABLE studio_templates ADD COLUMN IF NOT EXISTS age_range text NOT NULL DEFAULT '';
ALTER TABLE studio_templates ADD COLUMN IF NOT EXISTS pages text NOT NULL DEFAULT '';
