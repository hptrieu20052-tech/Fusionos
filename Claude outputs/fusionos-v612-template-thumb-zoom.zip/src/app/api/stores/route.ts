import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { db, schema } from "@/lib/db";
import { desc, eq, ne, and, or, inArray, sql } from "drizzle-orm";
import { getSession } from "@/lib/auth";
import { levelOf } from "@/lib/rbac";
import { scopeOwnerIds, sharedStoreIds } from "@/lib/scope";
import { DEFAULT_FEE_PCT } from "@/lib/fee";

export const dynamic = "force-dynamic";

// GET /api/stores?sellerId=&marketplace=
export async function GET(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });
  if ((await levelOf(session, "stores")) < 1) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });

  const sp = req.nextUrl.searchParams;
  const scopeIds = await scopeOwnerIds(session, "stores");
  const parts = [];
  // v598 · store xoá mềm (status='deleted') KHÔNG hiện ở đâu nữa — nhưng dòng vẫn còn trong DB
  // nên listing/đơn/design của nó giữ nguyên liên kết.
  parts.push(ne(schema.stores.status, "deleted" as never));
  // Phạm vi own/team: store thuộc seller trong phạm vi HOẶC store được SHARE (v458, Shopify/ShopBase).
  const shared = await sharedStoreIds(scopeIds);
  if (scopeIds) parts.push(shared.length
    ? or(inArray(schema.stores.sellerId, scopeIds), inArray(schema.stores.id, shared))!
    : inArray(schema.stores.sellerId, scopeIds));
  else if (sp.get("sellerId")) parts.push(eq(schema.stores.sellerId, sp.get("sellerId")!));
  if (sp.get("marketplace")) parts.push(eq(schema.stores.marketplace, sp.get("marketplace") as never));
  const where = parts.length ? and(...parts) : undefined;

  const rows = await db
    .select({ s: schema.stores, sellerName: schema.users.fullName })
    .from(schema.stores)
    .leftJoin(schema.users, eq(schema.stores.sellerId, schema.users.id))
    .where(where)
    .orderBy(desc(schema.stores.createdAt));

  // Đơn 30d + 7d để đánh giá "live" (có đơn gần đây)
  const counts = await db.execute(sql`
    SELECT store_id,
      count(*) FILTER (WHERE ordered_at > NOW()-interval '30 days')::int c30,
      count(*) FILTER (WHERE ordered_at > NOW()-interval '7 days')::int c7,
      coalesce(sum(total) FILTER (WHERE ordered_at > NOW()-interval '30 days'),0) rev30,
      max(ordered_at) last_order
    FROM orders WHERE store_id IS NOT NULL GROUP BY store_id`);
  const cmap = new Map((counts.rows as { store_id: string; c30: number; c7: number; rev30: string; last_order: string }[]).map((r) => [r.store_id, r]));

  // v458 · thành viên được share của từng store (render chip trong modal edit)
  const memRows = await db.select().from(schema.storeMembers).catch(() => [] as { storeId: string; userId: string }[]);
  const memMap = new Map<string, string[]>();
  for (const m of memRows) memMap.set(m.storeId, [...(memMap.get(m.storeId) ?? []), m.userId]);

  const sellers = await db.select({ id: schema.users.id, name: schema.users.fullName })
    .from(schema.users)
    .where(scopeIds ? and(eq(schema.users.role, "seller"), inArray(schema.users.id, scopeIds)) : eq(schema.users.role, "seller"));

  return NextResponse.json({
    ok: true,
    sellers,
    scoped: !!scopeIds,
    stores: rows.map((r) => {
      const c = cmap.get(r.s.id);
      const lastOrder = c?.last_order ? new Date(c.last_order) : null;
      const daysSince = lastOrder ? Math.floor((Date.now() - lastOrder.getTime()) / 86400000) : null;
      // live nếu có đơn trong 7 ngày; die nếu store active nhưng >14 ngày không đơn
      const live = (c?.c7 ?? 0) > 0;
      const cred = (r.s.apiCredentials ?? {}) as Record<string, string>;
      const SHOPIFY_KEYS = ["shopDomain", "clientId", "clientSecret", "adminToken", "webhookSecret"];
      const shownKeys = Object.keys(cred).filter((k) => !k.startsWith("etsy_") && !k.startsWith("tiktok_") && !SHOPIFY_KEYS.includes(k) && k !== "spapi" && k !== "shopbase" && k !== "woocommerce");
      return {
        ...r.s,
        memberIds: memMap.get(r.s.id) ?? [],
        apiCredentials: undefined,
        hasCredentials: shownKeys.length > 0,
        credentialKeys: shownKeys,
        etsy: {
          hasKeystring: !!cred.etsy_keystring,
          keystring: cred.etsy_keystring || "",
          connected: !!cred.etsy_refresh_token && !!cred.etsy_shop_id,
          shopId: cred.etsy_shop_id || "",
        },
        // TikTok: đã có refresh_token + shop_id = đã kết nối (dùng app riêng HOẶC app theyourlist)
        tiktok: {
          hasApp: !!cred.tiktok_app_key || !!cred.tiktok_auth_link,
          appKey: cred.tiktok_app_key || "",
          authLink: cred.tiktok_auth_link || "",
          connected: !!cred.tiktok_access_token && !!cred.tiktok_shop_id,
          shopId: cred.tiktok_shop_id || "",
          shopName: cred.tiktok_shop_name || "",
        },
        // Shopify: có shopDomain + (clientId&clientSecret HOẶC adminToken) = đã cấu hình app
        shopify: {
          shopDomain: cred.shopDomain || "",
          hasApp: !!cred.shopDomain && !!(cred.adminToken || (cred.clientId && cred.clientSecret)),
          clientId: cred.clientId || "",
        },
        // Amazon SP-API (LWA) — cấu hình lưu ở cred.spapi. Chỉ trả field không bí mật + cờ đã-đặt.
        amazon: (() => {
          const sp = ((cred as Record<string, unknown>).spapi ?? {}) as Record<string, string>;
          return {
            region: sp.region || "na",
            marketplaceId: sp.marketplaceId || "ATVPDKIKX0DER",
            sellerId: sp.sellerId || "",
            lwaClientId: sp.lwaClientId || "",
            hasSecret: !!sp.lwaClientSecret,
            hasRefresh: !!sp.refreshToken,
            configured: !!(sp.lwaClientId && sp.lwaClientSecret && sp.refreshToken && sp.sellerId),
            lastSyncAt: sp.lastSyncAt || null,
          };
        })(),
        // ShopBase (private app · Basic auth) — cấu hình lưu ở cred.shopbase. Chỉ trả field không bí mật.
        shopbase: (() => {
          const sb = ((cred as Record<string, unknown>).shopbase ?? {}) as Record<string, string>;
          return {
            subdomain: sb.subdomain || "",
            hasApp: !!(sb.subdomain && sb.apiKey && sb.password),
            lastSyncAt: sb.lastSyncAt || null,
          };
        })(),
        // WooCommerce (REST API key) — cấu hình lưu ở cred.woocommerce. Chỉ trả field không bí mật.
        woocommerce: (() => {
          const wc = ((cred as Record<string, unknown>).woocommerce ?? {}) as Record<string, string>;
          return {
            storeUrl: wc.storeUrl || "",
            hasKeys: !!(wc.storeUrl && wc.consumerKey && wc.consumerSecret),
            lastSyncAt: wc.lastSyncAt || null,
          };
        })(),
        sellerName: r.sellerName,
        // Số liệu shop public do extension đọc hộ (sales / rating / reviews / tuổi shop / còn sống)
        shop: (() => {
          const h = (r.s.health ?? {}) as Record<string, unknown>;
          if (!h.shopCheckedAt) return null;
          return {
            live: h.shopLive === true,
            checkFailed: h.shopCheckFailed === true, // Etsy chặn / lỗi mạng — KHÔNG phải suspend
            sales: h.shopSales ?? null,
            rating: h.shopRating ?? null,
            reviews: h.shopReviews ?? null,
            listings: h.shopListings ?? null,
            age: h.shopAge ?? null,
            status: h.shopStatus ?? null,
            checkedAt: h.shopCheckedAt,
          };
        })(),
        orders30d: c?.c30 ?? 0,
        orders7d: c?.c7 ?? 0,
        revenue30d: Number(c?.rev30 ?? 0),
        lastOrderDays: daysSince,
        live,
      };
    }),
  });
}

// POST tạo store
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) return NextResponse.json({ ok: false }, { status: 401 });
  if ((await levelOf(session, "stores")) < 2) return NextResponse.json({ ok: false, error: "forbidden" }, { status: 403 });

  const b = await req.json().catch(() => null);
  if (!b?.name || !schema.stores.marketplace.enumValues.includes(b.marketplace) || !schema.stores.connectMethod.enumValues.includes(b.connectMethod)) {
    return NextResponse.json({ ok: false, error: "Missing name / marketplace / connection method" }, { status: 400 });
  }
  // Chặn trùng tên store (không phân biệt hoa/thường) — tránh nhầm lẫn khi khớp đơn về sau
  const name = String(b.name).trim();
  // v598 · store đã xoá mềm không giữ chỗ tên — tạo store mới trùng tên store đã xoá được.
  const [dupName] = await db.select({ id: schema.stores.id })
    .from(schema.stores).where(and(sql`lower(${schema.stores.name}) = lower(${name})`, ne(schema.stores.status, "deleted" as never))).limit(1);
  if (dupName) return NextResponse.json({ ok: false, error: `Tên store "${name}" đã tồn tại — hãy dùng tên khác` }, { status: 409 });

  // Seller tạo store → luôn là store của chính mình (bỏ qua sellerId gửi lên)
  const sellerId = session.role === "seller" ? session.sub : (b.sellerId || null);
  const ingestToken = randomUUID().replace(/-/g, "") + randomUUID().replace(/-/g, "");
  const [s] = await db.insert(schema.stores).values({
    name, marketplace: b.marketplace, connectMethod: b.connectMethod,
    sellerId, status: "active", note: b.note, ingestToken,
    storeUrl: (typeof b.storeUrl === "string" && b.storeUrl.trim()) ? b.storeUrl.trim() : null,
    currency: (typeof b.currency === "string" && b.currency.trim()) ? b.currency.trim().toUpperCase() : "USD",
    fxRate: (b.fxRate != null && Number(b.fxRate) > 0) ? String(Number(b.fxRate)) : "1",
    // % phí sàn ƯỚC TÍNH (Etsy & TikTok mặc định 6.5) — sàn không trả phí theo đơn qua API.
    feeRate: (b.feeRate != null && Number(b.feeRate) >= 0 && Number(b.feeRate) < 100) ? String(Number(b.feeRate)) : String(DEFAULT_FEE_PCT),
  }).returning();
  return NextResponse.json({ ok: true, store: s });
}
