-- v410 · ShopBase templates: nội dung tab Shipping + Return & Warranty (widget đổ vào theme).
-- Chạy trên Supabase SQL editor. Idempotent.
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS shipping_info text;
ALTER TABLE shopbase_templates ADD COLUMN IF NOT EXISTS return_warranty text;
