-- v417 · Collection ShopBase chạy bằng TAG (private app không có API collection).
-- Chạy trên Supabase SQL editor. Idempotent.
CREATE TABLE IF NOT EXISTS shopbase_collection_tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  store_id uuid NOT NULL,
  title text NOT NULL,
  tag text NOT NULL,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_sb_collection_tag ON shopbase_collection_tags(store_id, tag);
