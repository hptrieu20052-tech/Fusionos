import { toISO2, uploadImageByUrl, createProduct, createOrderFromProducts, getPrintAreas } from "@/lib/printify";
import { createCompassupOrder, type CompassupCred, type CompassupItem } from "@/lib/compassup";
import { createMerchizeOrder, createMerchizeTiktokOrder, pushMerchizeOrder } from "@/lib/merchize";
import { createPrintwayOrder, listPrintwayOrders, normalizePwOrder, calcPrintwayPrice, type PwOrderItem } from "@/lib/printway-api";
import { createFlashshipOrder, flashshipKind, type FsProduct } from "@/lib/flashship";
import { createOnosOrder, type OnosItem } from "@/lib/onos";
import { createWembroideryOrder, type WemItem, type WemDesign } from "@/lib/wembroidery";
import { createLenfulOrder, type LenfulDesign, type LenfulItem } from "@/lib/lenful";
import { createVinawayOrder, type VinawayItem, type VinawaySurface } from "@/lib/vinaway";
import { createHogotoOrder } from "@/lib/hogoto";
import { getSheetHeaders, appendSheetRow, normHeader } from "@/lib/gsheet";
import { EMB_FILE_RX, isEmbKind } from "@/lib/design-kinds";
import { createHash } from "crypto";
/**
 * KHUNG ADAPTER ĐẨY ĐƠN THEO TỪNG NHÀ FULFILL
 * ------------------------------------------------------------------
 * Mỗi nhà (Printify, Merchize, Printway, Wembroidery, Flashship,
 * Onospod, Compassup, Gearment...) có một adapter riêng với hàm push().
 *
 * Hiện tại tất cả đang ở chế độ SIMULATE (chưa có doc API) — hành vi
 * giống hệt trước: sinh mã đơn giả, ghi sổ đầy đủ.
 *
 * KHI CÓ DOC API TỪNG BÊN: chỉ cần điền phần build request + gọi fetch
 * + đọc id đơn từ response vào đúng hàm push() của bên đó. Không phải
 * đụng tới route push chính.
 */

export type PushLine = {
  fulfillerSku: string; qty: number;
  internalSku?: string | null; productId?: string | null;
  /** Nhãn variant từ mapping (vd "Black / L") — ONOS cần Color+Size, Wembroidery cần size+color */
  variant?: string | null;
  /** Tên sản phẩm bên nhà fulfill (fulfiller_product) — ONOS cần attribute "product" */
  fulfillerProduct?: string | null;
  /** ID sản phẩm bên nhà fulfill (Compassup product_id) */
  fulfillerProductId?: string | null;
  price?: number; currency?: string;
  image?: string | null;
  designFront?: string | null; designBack?: string | null; designSleeve?: string | null; designHood?: string | null;
  designFrontW?: number; designFrontH?: number; designBackW?: number; designBackH?: number;
  /** TẤT CẢ mặt design của card (design_front, book_cover, page_01.., month_01.., grid_01..) — Printify map theo tên vùng in thật */
  designSides?: { kind: string; url: string; w?: number; h?: number }[];
  pfBlueprintId?: number | null; pfProviderId?: number | null; pfVariantId?: number | null;
  /** Dữ liệu riêng của nhà in (Compassup: {link, sup_site, seller_id, weight, sku_id, custom, attachments}) */
  extra?: Record<string, unknown> | null;
  /** Personalization/note của item (đơn cá nhân hoá) — dùng cho Google Sheet, note nhà in */
  personalization?: string | null;
};
export type PushCtx = {
  fulfiller: { id: string; name: string; apiEndpoint: string | null; credentials: unknown };
  order: {
    externalId: string; orderLabel?: string | null;
    buyerFirst: string | null; buyerLast: string | null;
    addr1: string | null; addr2: string | null; city: string | null;
    state: string | null; zip: string | null; country: string | null;
    phone?: string | null; email?: string | null;
    /** Sàn của đơn: etsy | tiktok | amazon… — Merchize cần tag "tiktok" cho đơn TikTok Shop. */
    platform?: string | null;
    /** CHỈ đơn Ship-by-TikTok: link nhãn TikTok (R2) + tracking → gửi supplier. Đơn khác luôn undefined. */
    labelUrl?: string | null; shippingTracking?: string | null;
    /** TIKTOK | SELLER (đơn TikTok) — map sang PLATFORM/SELLER cho Google Sheet */
    shippingType?: string | null;
  };
  lines: PushLine[];
};
export type PushResult = { externalFfId: string; simulated: boolean; raw?: unknown; reason?: string; baseCost?: number; shipCost?: number; tax?: number };
export type FulfillerAdapter = {
  slug: string;
  label: string;
  /** Đẩy đơn sang nhà fulfill. Trả về id đơn bên nhà fulfill. */
  push: (ctx: PushCtx) => Promise<PushResult>;
};

/** Số đơn gửi nhà in = TênStore-IDĐơn (orderLabel) nếu có, else ID đơn. Dùng cho MỌI nhà in. */
export const orderExtNumber = (o: { orderLabel?: string | null; externalId: string }) =>
  (o.orderLabel && o.orderLabel.trim()) ? o.orderLabel.trim() : o.externalId;

/** Sinh mã simulate — dùng chung khi chưa có credentials / chưa ráp API thật. */
const simulate = (slug: string): PushResult => ({
  externalFfId: `SIM-${slug.toUpperCase()}-${Date.now()}`,
  simulated: true,
});

/**
 * Helper để tạo adapter. Khi có doc, thay phần thân `impl` bằng logic gọi API thật:
 *   const res = await fetch(ctx.fulfiller.apiEndpoint + "/orders", {...});
 *   const data = await res.json();
 *   return { externalFfId: data.id, simulated: false, raw: data };
 */
function makeAdapter(slug: string, label: string): FulfillerAdapter {
  return {
    slug,
    label,
    async push(ctx) {
      const hasCreds = !!(ctx.fulfiller.credentials && ctx.fulfiller.apiEndpoint);
      // TODO(doc): khi có tài liệu API của ${label}, build request thật ở đây.
      // Hiện chưa ráp → simulate để đơn vẫn ghi sổ được, không chặn luồng.
      if (!hasCreds) return simulate(slug);
      // Có credentials nhưng chưa cài API thật cho bên này → vẫn simulate,
      // đánh dấu để biết là "chờ ráp".
      return simulate(slug);
    },
  };
}

/** Danh sách nhà fulfill hỗ trợ (slug ⇄ nhãn hiển thị). */
export const FULFILLER_ADAPTERS: Record<string, FulfillerAdapter> = {
  printify: printifyAdapter(),
  merchize: merchizeAdapter(),
  printway: printwayAdapter(),
  wembroidery: wembroideryAdapter(),
  flashship: flashshipAdapter(),
  onospod: onosAdapter(),
  onos: onosAdapter(),
  compassup: compassupAdapter(),
  gearment: makeAdapter("gearment", "Gearment"),
  lenful: lenfulAdapter(),
  vinaway: vinawayAdapter(),
  hogotopod: hogotoAdapter(),
  hogoto: hogotoAdapter(),
};

// v143 · Hogoto chỉ nhận ĐÚNG 6 giá trị enum này cho shippingMethod. Gửi chuỗi khác là HTTP 400
// "Cannot deserialize value of type Order$ShippingMethod from String ..." và đơn KHÔNG vào xưởng.
// Trước đây mình mặc định "FAST_US_SHIPPING" — không có trong enum ⇒ mọi đơn US đều fail.
const HOGOTO_SHIP = ["NON_SHIPPING", "HOGOTOFAST", "HOGOTO_EPACKET", "SHIPPING_OUTSIDE_US", "SHIPPING_TIKTOK_UK", "TIKTOK"];
// Tên cũ đã lỡ lưu trong Settings → Fulfillers / extraJson của SKU → quy về enum đúng, khỏi sửa tay từng dòng.
const HOGOTO_SHIP_ALIAS: Record<string, string> = {
  FAST_US_SHIPPING: "HOGOTOFAST", FAST_US: "HOGOTOFAST", US_FAST: "HOGOTOFAST", FAST: "HOGOTOFAST",
  STANDARD: "HOGOTOFAST", HOGOTO_FAST: "HOGOTOFAST",
  EPACKET: "HOGOTO_EPACKET", HOGOTOEPACKET: "HOGOTO_EPACKET",
  OUTSIDE_US: "SHIPPING_OUTSIDE_US", INTERNATIONAL: "SHIPPING_OUTSIDE_US", INTL: "SHIPPING_OUTSIDE_US",
  TIKTOK_UK: "SHIPPING_TIKTOK_UK", SBTT: "TIKTOK", SHIP_BY_TIKTOK: "TIKTOK",
  NONE: "NON_SHIPPING", NO_SHIPPING: "NON_SHIPPING",
};
/** Chuẩn hoá 1 chuỗi bất kỳ về enum Hogoto; không khớp thì trả null để dùng mặc định theo nước. */
function hogotoShip(v: unknown): string | null {
  const s = String(v ?? "").trim().toUpperCase().replace(/[\s-]+/g, "_");
  if (!s) return null;
  if (HOGOTO_SHIP.includes(s)) return s;
  return HOGOTO_SHIP_ALIAS[s] ?? null;
}

// v146 · productType của Hogoto CŨNG là enum, chỉ nhận EMBROIDERY | PRINT_2D | PRINT_3D.
// Bug cũ: fallback `l.fulfillerProduct` là TÊN sản phẩm ("Embroidedy Pillow Cover") ⇒ Hogoto trả
// VALIDATION_ERROR "Invalid product type ... for product at index 0" và đơn không vào xưởng.
const HOGOTO_PTYPE = ["EMBROIDERY", "PRINT_2D", "PRINT_3D"];
const HOGOTO_PTYPE_ALIAS: Record<string, string> = {
  EMB: "EMBROIDERY", EMBROIDER: "EMBROIDERY", EMBROIDERED: "EMBROIDERY", EMBROIDERY_3D: "EMBROIDERY", THEU: "EMBROIDERY",
  PRINT: "PRINT_2D", PRINT2D: "PRINT_2D", "2D": "PRINT_2D", DTG: "PRINT_2D", DTF: "PRINT_2D", UV: "PRINT_2D",
  SUBLIMATION: "PRINT_2D", FLAT_PRINT: "PRINT_2D",
  PRINT3D: "PRINT_3D", "3D": "PRINT_3D", AOP: "PRINT_3D", ALL_OVER_PRINT: "PRINT_3D", ALLOVER: "PRINT_3D",
};
/**
 * Quy mọi thứ về đúng enum productType. Nhận cả tên sản phẩm tự do và cả chính tả sai
 * ("Embroidedy" → chứa "EMB" → EMBROIDERY). Không đoán được thì trả null ⇒ KHÔNG gửi field này,
 * để Hogoto tự lấy loại mặc định của product code, còn hơn gửi bừa rồi bị chặn.
 */
function hogotoPType(v: unknown): string | null {
  const s = String(v ?? "").trim().toUpperCase().replace(/[\s-]+/g, "_");
  if (!s) return null;
  if (HOGOTO_PTYPE.includes(s)) return s;
  if (HOGOTO_PTYPE_ALIAS[s]) return HOGOTO_PTYPE_ALIAS[s];
  if (/EMB|THEU|TH[ÊE]U/.test(s)) return "EMBROIDERY";
  if (/3D|ALL_?OVER|AOP/.test(s)) return "PRINT_3D";
  if (/PRINT|DTG|DTF|UV|SUBLIM/.test(s)) return "PRINT_2D";
  return null;
}

// v147 · referenceCode của Hogoto CHỈ nhận chữ và số ("Reference code can only contain letters and
// numbers, no special characters allowed"). Order label của mình là "HEARTHOOPJAHNTSHOP-4134058147"
// (có dấu "-") ⇒ bị chặn. CHỈ lọc ở call site Hogoto, KHÔNG sửa orderExtNumber() vì ~10 adapter khác
// (Lenful, FlashShip, Merchize, Onos, WeMakePOD…) đã gửi mã có dấu "-" cho nhà cung cấp của họ rồi,
// đổi chung sẽ hỏng đối chiếu đơn + ghi ngược tracking.
function hogotoRef(v: string): string {
  const s = v
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")   // bỏ dấu tiếng Việt
    .replace(/đ/g, "d").replace(/Đ/g, "D")
    .replace(/[^A-Za-z0-9]/g, "");     // bỏ mọi ký tự đặc biệt còn lại
  return s.slice(0, 60);
}

/**
 * Adapter HOGOTO POD THẬT — POST /v1/partner/order/store (X-API-Key + X-Tenant).
 * credentials (Settings → Fulfillers): apiKey = API Key; (tuỳ chọn) tenant, shippingMethod mặc định.
 * MAPPING mỗi SKU:
 *   fulfillerSku  = Product Code Hogoto (vd "P201")
 *   variant       = Size (vd "12 x 16 inch")  — hoặc đặt trong extraJson.size
 *   extraJson     = { productType, colorCode, positionCode, size?, shippingMethod? }
 *       productType  vd "EMBROIDERY" | "PRINT_3D" (theo loại SP Hogoto)
 *       colorCode    vd "AS_DESIGN" hoặc mã màu gingham
 *       positionCode vd "CENTER" (thêu) | "ALL_OVER_PRINT" (in 3D)
 * Design: mặt design đầu tiên của card → designUrl; ảnh item → mockupUrl.
 * Đơn Ship-by-TikTok: tự kèm shippingLabel (label + tracking) + shippingMethod TIKTOK.
 */
function hogotoAdapter(): FulfillerAdapter {
  return {
    slug: "hogotopod",
    label: "Hogoto POD",
    async push(ctx) {
      const cred = (ctx.fulfiller.credentials ?? {}) as Record<string, string>;
      const apiKey = cred.apiKey || "";
      if (!apiKey || !ctx.fulfiller.apiEndpoint) {
        return { ...simulate("hogotopod"), reason: "Hogoto POD cần API endpoint + API Key (Settings → Fulfillers) → order NOT sent to the printer" };
      }
      const tenant = cred.tenant || "fulfillment";
      const o = ctx.order;
      const shipType = (o.shippingType || "").toUpperCase();
      const isTiktok = shipType.includes("TIKTOK") || !!o.labelUrl;

      // v143: mặc định theo NƯỚC NHẬN, không hard-code chuỗi ngoài enum nữa.
      //   TikTok  → TIKTOK (đơn UK dùng SHIPPING_TIKTOK_UK)
      //   Mỹ      → HOGOTOFAST
      //   ngoài Mỹ→ SHIPPING_OUTSIDE_US
      const hgIso2 = toISO2(o.country) || "US";
      let shippingMethod = hogotoShip(cred.shippingMethod)
        || (isTiktok ? (hgIso2 === "GB" ? "SHIPPING_TIKTOK_UK" : "TIKTOK")
                     : (hgIso2 === "US" ? "HOGOTOFAST" : "SHIPPING_OUTSIDE_US"));

      const products = ctx.lines.map((l) => {
        const ex = (l.extra ?? {}) as Record<string, unknown>;
        const productCode = String(l.fulfillerSku || "").trim();
        if (!productCode) throw new Error(`Hogoto: item "${l.internalSku ?? ""}" chưa map Product Code (vd P201) vào ô Fulfiller SKU.`);
        const size = String(ex.size || l.variant || "").trim();
        const colorCode = String(ex.colorCode || "AS_DESIGN").trim();
        const positionCode = String(ex.positionCode || "CENTER").trim();
        const exShip = hogotoShip(ex.shippingMethod); // sai enum ⇒ bỏ qua, giữ mặc định theo nước
        if (exShip) shippingMethod = exShip;
        // ĐƠN THÊU CẦN 2 FILE / 1 VỊ TRÍ: ảnh design (D) + file máy thêu (DST).
        // Bug cũ: chỉ lấy designSides[0] và luôn gửi designEmbUrl = null → nếu file đầu tiên là .dst
        // thì nó bị nhét vào ô ẢNH, còn ô file thêu để trống; nếu file đầu là ảnh thì Hogoto không
        // bao giờ nhận được .dst → đơn thêu treo ở "1/2 file", xưởng không chạy được.
        // Sửa: tách sides theo ĐUÔI FILE, ảnh vào designUrl, file thêu vào designEmbUrl.
        // v152 · Nhận diện file máy thêu phải xét CẢ `kind` (emb_front/emb_center/…) chứ không chỉ
        // đuôi file: storage key trên R2 thường KHÔNG giữ đuôi .dst ⇒ EMB_FILE_RX không khớp ⇒
        // file DST bị coi là ảnh, nhét vào designUrl, còn designEmbUrl để trống (card design có 2
        // file nhưng Hogoto chỉ nhận 1). Card #2884 dính đúng lỗi này.
        const sides = (l.designSides ?? []).filter((s) => !!s.url);
        const isEmb = (s: { kind: string; url: string }) => isEmbKind(s.kind) || EMB_FILE_RX.test(s.url);
        const imgUrl = sides.find((s) => !isEmb(s))?.url || l.designFront || null;
        const embUrl = sides.find((s) => isEmb(s))?.url || null;
        const designUrl = imgUrl || embUrl;   // chỉ có file thêu thì vẫn phải gửi để đơn không rỗng
        // v146 · thứ tự tin cậy: extraJson của SKU → tên sản phẩm fulfiller (đoán từ khoá) →
        // có file .dst/.emb thì chắc chắn là đơn thêu. Vẫn null thì bỏ hẳn field.
        const productType = hogotoPType(ex.productType) || hogotoPType(l.fulfillerProduct) || (embUrl ? "EMBROIDERY" : null);
        const designAttachments = designUrl ? [{
          positionCode, designUrl, designEmbUrl: embUrl, mockupUrl: l.image ?? null,
          note: l.personalization || null, glitterColors: null, embroidery3DColors: null, fabricPatterns: null, outline: null,
        }] : [];
        return {
          colorCode,
          designAttachments,
          positionCode: null as string | null,
          productCode,
          ...(productType ? { productType } : {}),
          quantity: l.qty,
          size,
        };
      });

      // v148 · tính TRƯỚC để in được ra thông báo lỗi (khối try/catch cuối hàm).
      const refCode = hogotoRef(orderExtNumber(o)) || hogotoRef(o.externalId) || `FO${Date.now()}`;

      const body: Record<string, unknown> = {
        address: {
          addressText2: o.addr2 || "",
          city: o.city || "",
          country: toISO2(o.country) || "US",
          details: o.addr1 || "",
          state: usStateAbbr(o.state || "") || (o.state || ""),
          zip: o.zip || "",
        },
        customerNote: ctx.lines.map((l) => (l.personalization || "").trim()).filter(Boolean).join(" | ") || null,
        // v151 · MẶC ĐỊNH FALSE. autoDeposit=true khiến Hogoto ĐẶT CỌC/TRỪ TIỀN NGAY khi nhận đơn:
        // đơn rời trạng thái "Tạo mới" ⇒ KHÔNG sửa được file thiết kế / dịch vụ bổ sung nữa,
        // và mất bước duyệt trước khi trả tiền. Muốn tự cọc thì đặt credential
        // autoDeposit = "1" | "true" | "yes" ở Settings → Fulfillers.
        autoDeposit: /^(1|true|yes)$/i.test(String(cred.autoDeposit || "")),
        products,
        recipient: {
          email: o.email || "",
          firstName: o.buyerFirst || "",
          lastName: o.buyerLast || "",
          note: null,
          phone: o.phone || "",
        },
        // v147 · chỉ chữ + số. FUSION OS vẫn hiển thị order label có dấu "-" như cũ.
        referenceCode: refCode,
        shippingMethod,
      };
      // Ship-by-TikTok: đưa nhãn + tracking cho Hogoto (đúng luồng đơn TikTok mình giữ label).
      if (isTiktok && (o.labelUrl || o.shippingTracking)) {
        body.shippingLabel = {
          contentType: null, labelUrl: o.labelUrl || null, providerCode: null,
          trackingNumber: o.shippingTracking || null, trackingNumberByTiktok: o.shippingTracking || null,
          type: null, needScanLabel: true,
        };
      }

      // v148 · CHẨN ĐOÁN: đính kèm đúng chuỗi đã gửi + dấu build vào thông báo lỗi.
      // Nếu toast KHÔNG có "[v148 ...]" ⇒ Vercel vẫn đang chạy bản cũ, không phải lỗi logic.
      // v189 · TỰ VÁ MÀU: sách/photo book (P177...) không nhận "AS_DESIGN" — Hogoto trả
      // "Color code 'X' is not available for product code 'Y' ... Available colors: WHITE".
      // Đổi colorCode của đúng product đó sang màu đầu tiên sàn cho phép rồi gửi lại (tối đa 3 vòng,
      // mỗi vòng vá 1 product code). Muốn khỏi vá: đặt extraJson.colorCode = "WHITE" trong SKU mapping.
      let res;
      let colorFixes = 0;
      const colorFixed: string[] = [];
      for (;;) {
        try {
          res = await createHogotoOrder({ endpoint: ctx.fulfiller.apiEndpoint, apiKey, tenant }, body);
          break;
        } catch (e) {
          const m = e instanceof Error ? e.message : String(e);
          const cm = /Color code '([^']+)' is not available for product code '([^']+)'.*?Available colors?:\s*([A-Za-z0-9_]+(?:\s*,\s*[A-Za-z0-9_]+)*)/i.exec(m);
          const firstColor = cm ? cm[3].split(/\s*,\s*/).filter(Boolean)[0] : null;
          if (cm && firstColor && colorFixes < 3) {
            let patched = false;
            for (const p of products) {
              if (String(p.productCode) === cm[2] && String(p.colorCode) === cm[1]) { p.colorCode = firstColor; patched = true; }
            }
            if (patched) { colorFixes++; colorFixed.push(`${cm[2]}:${cm[1]}→${firstColor}`); continue; }
          }
          const codes = products.map((p) => String(p.productCode)).join(",");
          throw new Error(`${m} · [v148 ref="${refCode}" ship="${shippingMethod}" products="${codes}"]`);
        }
      }
      // v156 · CHẨN ĐOÁN FILE DST — VÒNG 2. Kết quả v155: sent=1/1 echo=YES att{trống}.
      // Nghĩa là: mình CÓ gửi designEmbUrl, Hogoto CÓ nhả lại đúng URL đó trong response,
      // nhưng response KHÔNG có object nào mang key `designUrl` ⇒ cấu trúc đính kèm bên họ dùng
      // tên field khác hẳn tên mình đoán. v155 chỉ soi đúng key `designUrl` nên mù phần còn lại.
      // v156 đi tìm ĐƯỜNG DẪN thật sự chứa URL .dst và liệt kê các key ANH EM cạnh nó — đó chính
      // là tên field thật của Hogoto. Vẫn CHỈ ĐỌC response, không đổi payload. Gỡ sau khi vá xong.
      const sentEmb = products.filter((p) => (p.designAttachments ?? []).some((a) => !!a.designEmbUrl)).length;
      const embUrls = new Set(
        products.flatMap((p) => (p.designAttachments ?? []).map((a) => a.designEmbUrl).filter(Boolean) as string[]),
      );
      // v157 · IN GIÁ TRỊ, KHÔNG IN TÊN KEY NỮA. v156 chỉ cho biết object file của Hogoto có các key
      // {contentType,name,url,size,sizeName}; tôi đã SUY DIỄN từ đó là họ tải được file — sai lầm.
      // Có vỏ object không có nghĩa là có ruột: nếu Hogoto tải file .dst từ img.fusiondn.com thất bại
      // thì size/name/contentType đều null và ô DST vẫn trống (đúng hiện tượng "2/3 file").
      // size > 0  ⇒ họ tải được, lỗi nằm ở giao diện Hogoto, code mình không phải sửa.
      // size null ⇒ họ KHÔNG tải được, phải xử lý ở phía mình (quyền truy cập / content-type của R2).
      let hitObj: Record<string, unknown> | null = null;
      const walk = (v: unknown, depth: number): void => {
        if (depth > 8 || !v || typeof v !== "object" || hitObj) return;
        if (Array.isArray(v)) { for (const x of v.slice(0, 20)) walk(x, depth + 1); return; }
        const obj = v as Record<string, unknown>;
        for (const val of Object.values(obj)) {
          if (typeof val === "string" && embUrls.has(val)) { hitObj = obj; return; }
          walk(val, depth + 1);
        }
      };
      walk(res.raw, 0);
      const show = (k: string): string => {
        const v = hitObj ? (hitObj as Record<string, unknown>)[k] : undefined;
        return v === undefined ? "—" : v === null ? "null" : String(v).slice(0, 40);
      };
      const dstDiag = hitObj
        ? `v157 dst: size=${show("size")} sizeName=${show("sizeName")} name=${show("name")} type=${show("contentType")}`
        : `v157 dst: sent=${sentEmb}/${products.length} · response KHÔNG chứa url .dst`;
      // v189 · báo lại nếu đã tự đổi màu — nên ghi hẳn colorCode đó vào SKU mapping cho lần sau.
      const colorNote = colorFixed.length ? ` · auto-fixed color ${colorFixed.join(", ")} — set this colorCode in the SKU mapping` : "";
      return { externalFfId: res.orderCode, simulated: false, raw: res.raw, baseCost: res.baseCost, shipCost: res.shipCost, reason: dstDiag + colorNote };
    },
  };
}

/**
 * Adapter VINAWAY THẬT — api.vinaway.io/api (doc PDF 2026-07).
 * credentials (ô sẵn có ở Settings):
 *   Identifier = email đăng nhập Vinaway
 *   API Key    = password
 *   (tuỳ chọn trong credentials JSON: type 1|2|3, productionLineId 1 Standard|2 Express, surfaceFront/surfaceBack id vùng in)
 * lines[].fulfillerSku = "product_id:product_sku_id" (vd "1:101") — kéo id từ GET /products + /product-skus;
 *   hoặc chỉ product_sku_id nếu mapping có fulfillerProductId riêng.
 */
function vinawayAdapter(): FulfillerAdapter {
  return {
    slug: "vinaway",
    label: "Vinaway",
    async push(ctx) {
      const cred = (ctx.fulfiller.credentials ?? {}) as Record<string, string>;
      const email = cred.email || cred.identifier || cred.userName || "";
      const password = cred.password || cred.apiKey || "";
      if (!email || !password) {
        return { ...simulate("vinaway"), reason: "Vinaway cần Identifier (email) + API Key (password) trong Settings → order NOT sent to the printer" };
      }
      const o = ctx.order;
      const surfaceFront = Number(cred.surfaceFront) || 1;
      const surfaceBack = Number(cred.surfaceBack) || 2;

      const items: VinawayItem[] = ctx.lines.map((l) => {
        // SKU: "product_id:product_sku_id" hoặc sku_id đơn + fulfillerProductId.
        let productId = 0, skuId = 0;
        const m = String(l.fulfillerSku || "").match(/^(\d+)\s*[:/|-]\s*(\d+)$/);
        if (m) { productId = Number(m[1]); skuId = Number(m[2]); }
        else { skuId = Number(l.fulfillerSku) || 0; productId = Number(l.fulfillerProductId) || 0; }
        if (!productId || !skuId) {
          throw new Error(`Vinaway SKU mapping phải là "product_id:product_sku_id" (vd "1:101") — item "${l.internalSku ?? l.fulfillerSku}" chưa đúng. Kéo id từ GET /products và /product-skus của Vinaway.`);
        }
        const surfaces: VinawaySurface[] = [];
        if (l.designFront) surfaces.push({ product_surface_id: surfaceFront, design_png: l.designFront });
        if (l.designBack) surfaces.push({ product_surface_id: surfaceBack, design_png: l.designBack });
        return {
          product_id: productId,
          product_sku_id: skuId,
          quantity: l.qty,
          ...(l.image ? { mockup1: l.image } : {}),
          ...(surfaces.length ? { productSurfaces: surfaces } : {}),
        };
      });

      const note = ctx.lines.map((l) => (l.personalization || "").trim()).filter(Boolean).join(" | ");
      let res;
      try {
        res = await createVinawayOrder(
          { endpoint: ctx.fulfiller.apiEndpoint, email, password },
          {
            type: Number(cred.type) || 1,                       // 1 Production
            external_order_id: orderExtNumber(o),
            production_line_id: Number(cred.productionLineId) || 1, // 1 Standard · 2 Express
            note_seller: note || undefined,
            customer_name: `${(o.buyerFirst || "").trim()} ${(o.buyerLast || "").trim()}`.trim() || "Customer",
            address1: o.addr1 || "",
            address2: o.addr2 || "",
            city: o.city || "",
            zip: o.zip || "",
            country: toISO2(o.country || "") || o.country || "US",
            state: o.state || "",
            email: o.email || undefined,
            tel: o.phone || undefined,
            items,
          },
        );
      } catch (e) {
        // v189 · "Invalid SKU code" mà không nói SKU nào = mò kim đáy bể. In rõ id đã gửi + cách sửa.
        const m = e instanceof Error ? e.message : String(e);
        const sent = items.map((i) => `${i.product_id}:${i.product_sku_id}`).join(", ");
        const hint = /invalid sku|422/i.test(m)
          ? " — Vinaway không nhận product_id:product_sku_id này. Mở Settings → Fulfillers → Import SKUs from Vinaway để lấy id mới nhất rồi sửa lại SKU mapping."
          : "";
        throw new Error(`${m} · [v189 sent="${sent}"]${hint}`);
      }
      return { externalFfId: res.id, simulated: false, raw: res.raw };
    },
  };
}

/**
 * Adapter LENFUL THẬT — V6 API (s-lencam.lenful.com).
 * credentials (điền ở Settings, map vào ô sẵn có):
 *   Identifier  = user_name (email đăng nhập Lenful)
 *   API Key     = password
 *   Shop ID     = store_id (path của /api/order/:store_id/create)
 * lines[].fulfillerSku = product_sku Lenful (từ SKU mapping).
 * Vị trí in map theo kind design side: front→1, back→2, sleeve trái/phải→5/6, neck→7, full→0.
 */
const LENFUL_POS: Record<string, number> = {
  design_front: 1, front: 1, design_back: 2, back: 2,
  sleeve_left: 5, left_sleeve: 5, sleeve_right: 6, right_sleeve: 6,
  neck: 7, design_neck: 7, full: 0, design_full: 0,
};
function lenfulAdapter(): FulfillerAdapter {
  return {
    slug: "lenful",
    label: "Lenful",
    async push(ctx) {
      const cred = (ctx.fulfiller.credentials ?? {}) as Record<string, string>;
      const userName = cred.userName || cred.user_name || cred.identifier || "";
      const password = cred.password || cred.apiKey || "";
      const storeId = cred.storeId || cred.store_id || cred.shopId || "";
      if (!userName || !password || !storeId) {
        return { ...simulate("lenful"), reason: "Lenful cần Identifier (user_name) + API Key (password) + Shop ID (store_id) trong Settings → order NOT sent to the printer" };
      }
      const o = ctx.order;
      // shippings BẮT BUỘC (mảng MÃ SỐ theo thứ tự ưu tiên): 0 Standard · 1 Ground · 2 Express · 3 3-Days
      // · 4 Special · 5 US Island · 6 WW Standard · 7 Shipping By Platform · 8 Shipping By Seller.
      // Override qua Settings cred.shipping ("0" hoặc "0,1,2"); mặc định: có nhãn TikTok → [7], còn lại [0,1,2].
      const shipCfg = String(cred.shipping ?? "").split(/[,\s]+/).map((x) => parseInt(x, 10)).filter((n) => Number.isFinite(n) && n >= 0 && n <= 8);
      const shippings = shipCfg.length ? shipCfg : (o.labelUrl ? [7] : [0, 1, 2]);
      const items: LenfulItem[] = ctx.lines.map((l) => {
        // Gom design theo VỊ TRÍ IN — ưu tiên danh sách đầy đủ designSides, fallback front/back/sleeve lẻ.
        const designs: LenfulDesign[] = [];
        const seen = new Set<number>();
        for (const sd of l.designSides ?? []) {
          const pos = LENFUL_POS[(sd.kind || "").toLowerCase()];
          if (pos !== undefined && sd.url && !seen.has(pos)) { seen.add(pos); designs.push({ position: pos, link: sd.url }); }
        }
        if (!designs.length) {
          if (l.designFront) designs.push({ position: 1, link: l.designFront });
          if (l.designBack) designs.push({ position: 2, link: l.designBack });
          if (l.designSleeve) { designs.push({ position: 5, link: l.designSleeve }); designs.push({ position: 6, link: l.designSleeve }); }
        }
        // DESIGN_SKU PHẢI GẮN VỚI ẢNH, KHÔNG PHẢI VỚI SẢN PHẨM.
        //
        // Lỗi cũ: design_sku = internalSku/fulfillerSku (SKU sản phẩm) → mọi đơn của cùng 1 sản phẩm
        // dùng chung 1 bản ghi design bên Lenful. Đơn sau gửi ảnh khác → Lenful hiểu là UPDATE design
        // đó, và chặn nếu có đơn cũ đang in:
        //   "Update design [xxx] fail … Have some orders using this design in process with status
        //    not in [Pending,Updating] … You cannot update it"
        // Với hàng cá nhân hoá (mỗi đơn 1 ảnh riêng) thì lỗi này chắc chắn xảy ra.
        //
        // Sửa: gắn thêm hash của CHÍNH danh sách link ảnh vào sku.
        //   • ảnh khác → sku khác → Lenful TẠO MỚI, không update cái đang in → hết 400.
        //   • ảnh y hệt (đẩy lại đơn lỗi) → hash y hệt → sku y hệt → Lenful dùng lại, không tạo rác.
        const designKey = designs.map((d) => `${d.position}:${d.link}`).sort().join("|");
        const baseSku = (l.internalSku || l.fulfillerSku).slice(0, 80);
        const designSku = designs.length
          ? `${baseSku}-${createHash("sha1").update(designKey).digest("hex").slice(0, 10)}`
          : baseSku;
        return {
          design_sku: designSku.slice(0, 100),
          product_sku: l.fulfillerSku,
          quantity: l.qty,
          ...(l.image ? { mockups: [l.image] } : {}),
          ...(designs.length ? { designs } : {}),
          shippings,
        };
      });
      const note = ctx.lines.map((l) => (l.personalization || "").trim()).filter(Boolean).join(" | ");
      const res = await createLenfulOrder(
        { endpoint: ctx.fulfiller.apiEndpoint, userName, password, storeId },
        {
          order_number: orderExtNumber(o),
          first_name: (o.buyerFirst || "").trim() || "Customer",
          last_name: (o.buyerLast || "").trim() || undefined,
          email: o.email || undefined,
          phone: o.phone || undefined,
          country_code: toISO2(o.country || "") || o.country || "US",
          province: o.state || "",
          city: o.city || "",
          zip: o.zip || "",
          address_1: o.addr1 || "",
          address_2: o.addr2 || undefined,
          note: note || undefined,
          platform_label: o.labelUrl || undefined,
          items,
        },
      );
      return { externalFfId: res.id, simulated: false, raw: res.raw };
    },
  };
}


/**
 * Adapter FlashShip THẬT — POST /orders/shirt-add (seller-api-v2).
 * credentials = { apiKey: <API token 1 năm từ web FlashShip> }; tuỳ chọn { printType: 1|2, shipment: 1|2|3|4|6 }.
 * lines[].fulfillerSku = variant_id FlashShip (số — kéo từ nút Update SKU).
 * FLS-406 (hết balance) → đơn VẪN TẠO, payment PENDING → ghi reason nhắc trả tiền trên FlashShip admin.
 */
function flashshipAdapter(): FulfillerAdapter {
  return {
    slug: "flashship",
    label: "Flashship",
    async push(ctx) {
      const cred = (ctx.fulfiller.credentials ?? {}) as Record<string, string>;
      const accessToken = cred.apiKey || cred.accessToken || cred.apiToken || "";
      if (!accessToken) return { ...simulate("flashship"), reason: "FlashShip API token missing (Settings → API Key) → order NOT sent to the printer" };

      const o = ctx.order;
      const printType = (Number(cred.printType) === 2 ? 2 : 1) as 1 | 2;
      const shipment = [1, 2, 3, 4, 6].includes(Number(cred.shipment)) ? Number(cred.shipment) : 1;

      // Map ĐỦ MỌI MẶT IN từ designSides của card (trước đây chỉ gửi front/back → đơn có TAY ÁO/neck bị thiếu design).
      const FS_FIELD: Record<string, keyof FsProduct> = {
        design_front: "printer_design_front_url", front: "printer_design_front_url",
        design_back: "printer_design_back_url", back: "printer_design_back_url",
        sleeve_left: "printer_design_left_url", left_sleeve: "printer_design_left_url",
        sleeve_right: "printer_design_right_url", right_sleeve: "printer_design_right_url",
        neck: "printer_design_neck_url", design_neck: "printer_design_neck_url",
        neck_inner: "printer_design_neck_inner_url",
        pocket: "printer_design_pocket_url",
        hood: "printer_design_hood_url", design_hood: "printer_design_hood_url",
      };
      const products: FsProduct[] = ctx.lines.map((l) => {
        const p: FsProduct = { variant_id: Number(l.fulfillerSku) || 0, quantity: l.qty, printType };
        for (const sd of l.designSides ?? []) {
          const field = FS_FIELD[(sd.kind || "").toLowerCase()];
          if (field && sd.url && !p[field]) (p as unknown as Record<string, unknown>)[field] = sd.url;
        }
        // Fallback kiểu cũ (card chưa có designSides)
        if (l.designFront && !p.printer_design_front_url) p.printer_design_front_url = l.designFront;
        if (l.designBack && !p.printer_design_back_url) p.printer_design_back_url = l.designBack;
        if (l.designHood && !p.printer_design_hood_url) p.printer_design_hood_url = l.designHood;
        if (l.designSleeve && !p.printer_design_left_url && !p.printer_design_right_url) { p.printer_design_left_url = l.designSleeve; p.printer_design_right_url = l.designSleeve; }
        if (l.image) p.mockup_front_url = l.image;
        return p;
      });
      const bad = products.find((p) => !p.variant_id);
      if (bad) throw new Error("FlashShip needs a NUMERIC variant_id in SKU mapping (pull via Update SKU on the Flashship tab)");

      // FlashShip có endpoint RIÊNG cho từng loại hàng: /orders/shirt-add vs /orders/ornament-add.
      // Đẩy variant ORNAMENT vào shirt-add → FLS_400 "API add SHIRT can't use for variant ORNAMENT".
      const kinds = new Set(ctx.lines.map((l) => flashshipKind(l.fulfillerProduct, (l.extra as Record<string, unknown> | null)?.fsKind)));
      if (kinds.size > 1) {
        throw new Error("FlashShip handles SHIRT and ORNAMENT through separate order endpoints, and this order mixes both. Push the SHIRT items first, then push the ORNAMENT items as a second fulfillment record (tick only those items).");
      }
      const kind = kinds.values().next().value ?? "shirt";

      const res = await createFlashshipOrder({ accessToken, endpoint: ctx.fulfiller.apiEndpoint }, {
        order_id: orderExtNumber(o),
        buyer_first_name: (o.buyerFirst || "").trim() || "Customer",
        buyer_last_name: (o.buyerLast || "").trim() || undefined,
        buyer_email: o.email || undefined,
        buyer_phone: o.phone || undefined,
        buyer_address1: o.addr1 || "",
        buyer_address2: o.addr2 || undefined,
        buyer_city: o.city || "",
        buyer_province_code: usStateAbbr(o.state || ""),
        buyer_zip: o.zip || "",
        buyer_country_code: toISO2(o.country || "United States"),
        shipment,
        link_label: o.labelUrl || undefined, // CHỈ đơn Ship-by-TikTok có; đơn khác undefined → không đổi hành vi
        products,
      }, kind);
      return {
        externalFfId: res.orderCode, simulated: false, raw: res.raw,
        reason: res.paymentPending ? "FLS-406: insufficient balance → payment PENDING, repay on FlashShip web admin" : undefined,
      };
    },
  };
}

// FlashShip yêu cầu mã bang US viết tắt (IN, CA...). Nhận cả tên đầy đủ lẫn mã sẵn.
const US_STATES: Record<string, string> = {
  "alabama": "AL", "alaska": "AK", "arizona": "AZ", "arkansas": "AR", "california": "CA", "colorado": "CO",
  "connecticut": "CT", "delaware": "DE", "florida": "FL", "georgia": "GA", "hawaii": "HI", "idaho": "ID",
  "illinois": "IL", "indiana": "IN", "iowa": "IA", "kansas": "KS", "kentucky": "KY", "louisiana": "LA",
  "maine": "ME", "maryland": "MD", "massachusetts": "MA", "michigan": "MI", "minnesota": "MN", "mississippi": "MS",
  "missouri": "MO", "montana": "MT", "nebraska": "NE", "nevada": "NV", "new hampshire": "NH", "new jersey": "NJ",
  "new mexico": "NM", "new york": "NY", "north carolina": "NC", "north dakota": "ND", "ohio": "OH", "oklahoma": "OK",
  "oregon": "OR", "pennsylvania": "PA", "rhode island": "RI", "south carolina": "SC", "south dakota": "SD",
  "tennessee": "TN", "texas": "TX", "utah": "UT", "vermont": "VT", "virginia": "VA", "washington": "WA",
  "west virginia": "WV", "wisconsin": "WI", "wyoming": "WY", "district of columbia": "DC", "puerto rico": "PR",
};
export function usStateAbbr(state: string): string {
  const s = state.trim();
  if (/^[A-Za-z]{2}$/.test(s)) return s.toUpperCase();
  return US_STATES[s.toLowerCase()] ?? s;
}

// Printway BẮT BUỘC email hợp lệ (dù doc ghi optional). Etsy không cho email người mua
// → thiếu thì dùng hộp thư chung của FUSION (chỉ để nhà in liên hệ khi cần).
function pushEmail(raw: string | null | undefined): string {
  const v = (raw ?? "").trim();
  if (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)) return v;
  return "orders@fusiondn.com";
}

// Printway BẮT BUỘC phone 8–15 chữ số (dù doc ghi optional). Etsy không cho SĐT người mua
// → sanitize về chỉ-chữ-số; thiếu/không hợp lệ thì dùng placeholder 10 số (thực tế POD phổ biến).
function pushPhone(raw: string | null | undefined): string {
  const digits = (raw ?? "").replace(/\D/g, "");
  if (digits.length >= 8 && digits.length <= 15) return digits;
  return "123456789"; // SĐT mặc định cho Printway khi đơn không có phone (theo yêu cầu)
}

/**
 * Adapter Printway THẬT — POST /order/create-new-order (Open API v3).
 * credentials = { apiKey: <pw access token> } (dán Access Token vào ô API Key ở Settings).
 * lines[].fulfillerSku = item_sku bên Printway (vd "PW-2LMORM-3.54X3.54 INCHES-ONE SIDE").
 * Thiếu token → simulate (không chặn luồng).
 */
function printwayAdapter(): FulfillerAdapter {
  return {
    slug: "printway",
    label: "Printway",
    async push(ctx) {
      const cred = (ctx.fulfiller.credentials ?? {}) as Record<string, string>;
      const accessToken = cred.apiKey || cred.accessToken || cred.apiToken || "";
      if (!accessToken) return { ...simulate("printway"), reason: "Printway chưa có Access Token (Settings → API Key) → đơn KHÔNG lên nhà in" };

      const o = ctx.order;
      const first = (o.buyerFirst || "").trim() || "Customer";
      const last = (o.buyerLast || "").trim() || first;
      const state = (o.state || "").trim();

      const items: PwOrderItem[] = ctx.lines.map((l) => {
        const it: PwOrderItem = { item_sku: l.fulfillerSku, quantity: l.qty };
        if (l.image) it.mockup_url = l.image;
        if (l.designFront) it.artwork_front = l.designFront;
        if (l.designBack) it.artwork_back = l.designBack;
        if (l.designHood) it.artwork_hood = l.designHood;
        if (l.designSleeve) { it.artwork_right_upper_sleeves = l.designSleeve; it.artwork_left_upper_sleeves = l.designSleeve; }
        return it;
      });

      // CHỐNG TRÙNG: lần đẩy trước có thể đã tạo đơn bên Printway nhưng FUSION không nhận được
      // response. LƯU Ý: /transaction/order-list chỉ chứa đơn ĐÃ THANH TOÁN nên không dùng
      // pre-check được → bắt thẳng lỗi "has been existed" của create và coi là thành công.
      let res: Awaited<ReturnType<typeof createPrintwayOrder>>;
      try {
        res = await createPrintwayOrder({ accessToken, endpoint: ctx.fulfiller.apiEndpoint }, {
        order_id: orderExtNumber(o),
        // KHÔNG gửi tiktok_order_type: Printway coi field này = đơn TikTok (chỉ ship US),
        // đơn Etsy quốc tế sẽ bị chặn "Tiktok orders are currently available only for the US"
        firstName: first,
        lastName: last,
        shipping_email: pushEmail(o.email),
        shipping_phone: pushPhone(o.phone),
        shipping_address1: o.addr1 || "",
        shipping_address2: o.addr2 || undefined,
        shipping_city: o.city || "",
        shipping_province: state,
        shipping_province_code: state,
        shipping_zip: o.zip || "",
        shipping_country: o.country || "United States",
        shipping_country_code: toISO2(o.country || "United States"),
        order_items: items,
      });
      } catch (e) {
        const msg = String((e as Error)?.message ?? e);
        if (/has been existed|already exist/i.test(msg)) {
          // Đơn đã có bên Printway (từ lần đẩy timeout trước) → link vào đơn cũ, KHÔNG double.
          // externalFfId = order_id mình gửi; webhook/poll dual-match theo order_name nên vẫn sync đủ.
          res = { orderId: orderExtNumber(o), raw: { reused: true, message: msg } };
        } else throw e;
      }

      // Giá THẬT từ calculate-price (mapping Printway không có giá) — fail thì giữ giá mapping
      let realBase: number | undefined, realShip: number | undefined;
      try {
        const price = await calcPrintwayPrice({ accessToken, endpoint: ctx.fulfiller.apiEndpoint }, {
          countryCode: toISO2(o.country || "United States"),
          provinceCode: usStateAbbr(state),
          items: items.map((i) => ({ item_sku: i.item_sku, variant_id: i.variant_id, quantity: i.quantity })),
        });
        if (price.total > 0) { realBase = price.base || price.total - price.ship; realShip = price.ship; }
      } catch { /* không chặn đẩy đơn */ }

      // KHÔNG auto-pay: đơn tạo xong nằm ở trạng thái unpaid trên Printway —
      // người dùng kiểm tra rồi tự thanh toán bên đó, webhook/poll sẽ kéo trạng thái về.
      const reused = !!(res.raw as Record<string, unknown>)?.reused;
      return {
        externalFfId: res.orderId, simulated: false, raw: res.raw,
        baseCost: realBase, shipCost: realShip,
        reason: reused ? "Order already existed on Printway (from a previous failed push) — linked to it, no duplicate created" : undefined,
      };
    },
  };
}

/**
 * Adapter Printify THẬT — gọi API tạo đơn.
 * credentials = { apiKey: <Personal Access Token>, shopId: <shop_id> }
 * lines[].fulfillerSku = SKU của variant sản phẩm bên Printify.
 * Chưa cấu hình token/shopId → simulate (không chặn luồng).
 */
// Chạy fn theo lô, tối đa `limit` cái đồng thời (tránh Printify bóp khi upload nhiều mặt cùng lúc).
async function mapLimit<T, R>(items: T[], limit: number, fn: (x: T, i: number) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let idx = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) || 1 }, async () => {
    while (idx < items.length) { const i = idx++; out[i] = await fn(items[i], i); }
  });
  await Promise.all(workers);
  return out;
}

function printifyAdapter(): FulfillerAdapter {
  return {
    slug: "printify",
    label: "Printify",
    async push(ctx) {
      const c = (ctx.fulfiller.credentials ?? {}) as { apiKey?: string; apiToken?: string; shopId?: string | number };
      const token = c.apiKey || c.apiToken;
      const shopId = c.shopId;
      if (!token || !shopId) return simulate("printify"); // chưa cấu hình → simulate

      const o = ctx.order;
      const address = {
        first_name: o.buyerFirst || "Customer", last_name: o.buyerLast || ".",
        email: o.email || undefined, phone: o.phone || undefined,
        country: toISO2(o.country), region: o.state || "",
        address1: o.addr1 || "", address2: o.addr2 || undefined,
        city: o.city || "", zip: o.zip || "",
      };

      // Mỗi line phải có recipe (blueprint/provider/variant). Upload design → tạo product → gom line_item.
      const missing = ctx.lines.filter((l) => !l.pfBlueprintId || !l.pfProviderId || !l.pfVariantId);
      if (missing.length) {
        throw new Error(`Blueprint/Provider/Variant not configured for SKU: ${missing.map((l) => l.fulfillerSku).join(", ")}. Open SKU mapping → Printify tab to set them.`);
      }
      const extNumber = orderExtNumber(o);
      // Lấy kích thước vùng in theo (blueprint, provider) — cache theo cặp để không gọi trùng
      const paCache = new Map<string, Awaited<ReturnType<typeof getPrintAreas>>>();
      const printAreasOf = async (bp: number, pv: number) => {
        const key = `${bp}:${pv}`;
        if (!paCache.has(key)) paCache.set(key, await getPrintAreas(token, bp, pv));
        return paCache.get(key)!;
      };
      // Scale để ảnh KHỚP CHIỀU CAO vùng in (căn trên–dưới). Không có số liệu → 1 (khớp bề ngang như cũ).
      const fitHeightScale = (pa: { width: number; height: number } | undefined, imgW?: number, imgH?: number) => {
        if (!pa || !imgW || !imgH) return 1;
        const s = (pa.height * imgW) / (pa.width * imgH);
        return Math.max(0.1, Math.min(s, 1));
      };
      // Với 1 vùng in (position) của blueprint, tìm mặt design phù hợp trong card.
      // Blueprint đặt tên vùng in rất khác nhau: front / front_side / default / back /
      // cover / page 1 / page_01 / inside_1 ... → match theo SỐ trước, rồi tới TỪ KHOÁ.
      const pad2 = (n: number) => String(n).padStart(2, "0");
      // Blueprint LỊCH hay đặt tên vùng in theo THÁNG CHỮ (january…december / jan…dec) → quy về số tháng.
      const MONTH_NAMES = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
      const kindsForPosition = (pos: string): string[] => {
        const p = pos.toLowerCase();
        const out: string[] = [];
        const digit = Number(p.match(/(\d+)/)?.[1] ?? 0);
        const mi = MONTH_NAMES.findIndex((m) => p.includes(m) || new RegExp(`\\b${m.slice(0, 3)}\\b`).test(p));
        const n = digit >= 1 && digit <= 24 ? digit : mi >= 0 ? mi + 1 : 0;
        if (n >= 1 && n <= 24) {
          if (p.includes("grid")) out.push(`grid_${pad2(n)}`, `month_${pad2(n)}`);
          else if (mi >= 0 || p.includes("month") || p.includes("cal")) out.push(`month_${pad2(n)}`, `grid_${pad2(n)}`, `page_${pad2(n)}`);
          else out.push(`page_${pad2(n)}`, `month_${pad2(n)}`, `grid_${pad2(n)}`);
        }
        if (p.includes("sleeve") && p.includes("left")) out.push("sleeve_left");
        if (p.includes("sleeve") && p.includes("right")) out.push("sleeve_right");
        if (p.includes("back")) out.push("design_back", "back_cover");
        if (p.includes("cover")) out.push("book_cover", "cover_front", "design_front");
        if (p.includes("front") || p.includes("default") || p.includes("all")) out.push("design_front", "cover_front", "book_cover");
        return out;
      };
      // Parallel: mỗi line map mặt design → vùng in → upload đúng ảnh cần → tạo product.
      const lineItems = await Promise.all(ctx.lines.map(async (l) => {
        const pa = await printAreasOf(l.pfBlueprintId!, l.pfProviderId!);
        // Variant không có trong response (hiếm) → mượn positions của variant bất kỳ cùng blueprint
        const ph = pa.get(l.pfVariantId!) ?? pa.values().next().value ?? {};
        const realPos = Object.keys(ph);
        // API không trả placeholder → giữ tên legacy front/back
        const positions = realPos.length ? realPos : ["front", "back"];

        // Gom mọi mặt design của card (fallback về designFront/designBack kiểu cũ)
        type Side = { kind: string; url: string; w?: number; h?: number };
        const byKind = new Map<string, Side>();
        for (const s of l.designSides ?? []) if (s.url) byKind.set(s.kind, s);
        if (l.designFront && !byKind.has("design_front")) byKind.set("design_front", { kind: "design_front", url: l.designFront, w: l.designFrontW, h: l.designFrontH });
        if (l.designBack && !byKind.has("design_back")) byKind.set("design_back", { kind: "design_back", url: l.designBack, w: l.designBackW, h: l.designBackH });

        // Map vùng in → mặt design (mỗi mặt chỉ dùng 1 lần)
        const plan: { position: string; side: Side }[] = [];
        const used = new Set<string>();
        for (const pos of positions) {
          const k = kindsForPosition(pos).find((x) => byKind.has(x) && !used.has(x));
          if (k) { plan.push({ position: pos, side: byKind.get(k)! }); used.add(k); }
        }
        // Không match được vùng nào (vd Photo Book: card chỉ có book_cover/page_xx nhưng blueprint
        // đặt tên khác) → vẫn phải có ≥1 ảnh, nếu không Printify trả 400 "placeholders is required".
        if (!plan.length) {
          const sides = Array.from(byKind.values());
          const primary = byKind.get("design_front") ?? byKind.get("book_cover") ?? byKind.get("cover_front")
            ?? sides.slice().sort((a, b) => a.kind.localeCompare(b.kind))[0];
          if (!primary) throw new Error(`SKU ${l.fulfillerSku}: the design card has no print files — Printify requires at least 1 image. Assign/complete the design first.`);
          // Card NHIỀU mặt (lịch/photo book) mà không map được vùng nào → DỪNG, không đẩy sản phẩm chỉ có 1 ảnh.
          if (sides.length > 1) {
            throw new Error(`SKU ${l.fulfillerSku}: blueprint print sides [${positions.slice(0, 8).join(", ")}${positions.length > 8 ? "…" : ""}] could not be matched to design sides [${sides.map((x) => x.kind).slice(0, 8).join(", ")}${sides.length > 8 ? "…" : ""}]. NOT pushed to avoid a product with missing pages — send these side names to the admin to add a mapping rule.`);
          }
          plan.push({ position: positions[0], side: primary });
        }
        // CHỐNG ĐẨY THIẾU TRANG (lỗi lịch chỉ có cover): còn vùng in TRỐNG và còn mặt design CHƯA DÙNG
        // → tên vùng của blueprint không khớp rule map → DỪNG báo rõ, tuyệt đối không tạo product thiếu trang.
        const unmatchedPos = positions.filter((pos) => !plan.some((x) => x.position === pos));
        const unusedKinds = Array.from(byKind.keys()).filter((k) => !used.has(k));
        if (unmatchedPos.length && unusedKinds.length) {
          throw new Error(`SKU ${l.fulfillerSku}: ${unmatchedPos.length} print side(s) have no image [${unmatchedPos.slice(0, 10).join(", ")}${unmatchedPos.length > 10 ? "…" : ""}] while the design still has unused sides [${unusedKinds.slice(0, 10).join(", ")}${unusedKinds.length > 10 ? "…" : ""}]. NOT pushed to avoid a product with missing pages — send this info to the admin to add a mapping rule.`);
        }
        // v566 · SP NHIỀU TRANG (Wall/Desktop Calendar, Photo Book): BẮT BUỘC đủ ảnh cho MỌI vùng in
        // mới cho đẩy. Lỗ hổng cũ: designer up THIẾU HẲN mặt (vd Photo Book 25 vùng, card chỉ có cover
        // + vài trang) → các mặt có sẵn đều map được, không còn "mặt chưa dùng" nên 3 lớp chặn trên đều
        // lọt → Printify không check lại, in trang trắng hàng loạt. Nhận diện SP nhiều trang: tên
        // product type có calendar / photo book, HOẶC blueprint có vùng in đánh số / tên tháng.
        // ÁO (front/back/sleeve) chủ động BỎ QUA — in 1 mặt hay 2 mặt là tuỳ mẫu, không cố định được.
        const isMultiPage = realPos.length > 0 && (
          /calendar|photo\s*book/i.test(String(l.fulfillerProduct ?? "")) ||
          positions.some((p) => /\d/.test(p) || MONTH_NAMES.some((m) => p.toLowerCase().includes(m)))
        );
        if (isMultiPage && unmatchedPos.length) {
          const have = Array.from(byKind.keys()).sort();
          throw new Error(
            `BLOCKED — ${l.fulfillerSku}: this product requires a design file for EVERY print side before pushing to Printify ` +
            `(${plan.length}/${positions.length} sides ready). Missing ${unmatchedPos.length} side(s): ` +
            `[${unmatchedPos.slice(0, 12).join(", ")}${unmatchedPos.length > 12 ? "…" : ""}]. ` +
            (have.length
              ? `The design card only has: [${have.slice(0, 12).join(", ")}${have.length > 12 ? "…" : ""}]. `
              : `The design card has NO print files at all. `) +
            `Send the order back to the designer to upload the missing sides, then push again.`
          );
        }

        const uploaded = await mapLimit(plan, 5, (x) => uploadImageByUrl(token, `${l.fulfillerSku}-${x.side.kind}`, x.side.url));
        const placeholders = plan.map((x, i) => ({
          position: x.position,
          images: [{ id: uploaded[i], x: 0.5, y: 0.5, scale: fitHeightScale(ph[x.position], x.side.w, x.side.h), angle: 0 }],
        }));

        const prod = await createProduct(token, shopId, {
          title: `${extNumber} · ${l.fulfillerSku}`,
          blueprintId: l.pfBlueprintId!, providerId: l.pfProviderId!, variantId: l.pfVariantId!,
          price: l.price ? Math.round(l.price * 100) : 2000,
          placeholders,
        });
        return { product_id: prod.productId, variant_id: prod.variantId, quantity: l.qty };
      }));
      const res = await createOrderFromProducts(token, shopId, extNumber, lineItems, address);
      // Không fetch chi phí ở đây (chậm) — base/ship/tax + tracking sẽ về tự động qua webhook Printify.
      return { externalFfId: res.orderId, simulated: false, raw: res.raw };
    },
  };
}

/**
 * Adapter Merchize THẬT — POST /order/external/orders/catalog (x-api-key).
 * credentials = { apiKey, identifier }, base URL = fulfiller.apiEndpoint.
 * lines mang theo merchize_sku (fulfillerSku), product_id, giá, và URL design (front/back...).
 */
function merchizeAdapter(): FulfillerAdapter {
  return {
    slug: "merchize",
    label: "Merchize",
    async push(ctx) {
      const c = (ctx.fulfiller.credentials ?? {}) as { apiKey?: string; apiToken?: string; identifier?: string };
      const apiKey = c.apiKey || c.apiToken;
      const baseUrl = ctx.fulfiller.apiEndpoint;
      const identifier = c.identifier;
      if (!apiKey || !baseUrl || !identifier) {
        const missing = [!baseUrl && "Base URL", !apiKey && "API Key", !identifier && "Identifier"].filter(Boolean).join(", ");
        return { ...simulate("merchize"), reason: `Chưa cấu hình đủ Merchize (thiếu: ${missing}) → đơn KHÔNG lên nhà in` };
      }

      const o = ctx.order;
      const extNumber = (o.orderLabel && o.orderLabel.trim()) ? o.orderLabel.trim() : o.externalId; // TênStore-IDĐơn
      // Đơn TikTok Shop → Merchize BẮT BUỘC tag "tiktok" (áp cho cả đơn ship-by-tiktok lẫn đơn Merchize tự ship).
      const isTiktokShop = String(o.platform ?? "").toLowerCase() === "tiktok" || o.shippingType === "TIKTOK";
      const merchizeTags = isTiktokShop ? ["tiktok"] : undefined;
      const url = (u?: string | null) => (typeof u === "string" && /^https?:\/\//i.test(u.trim())) ? u.trim() : undefined;
      const items = ctx.lines.map((l) => ({
        product_id: l.productId || undefined,
        sku: l.internalSku || undefined,
        merchize_sku: l.fulfillerSku,
        quantity: l.qty,
        price: l.price,
        currency: l.currency || "USD",
        image: url(l.image),
        design_front: url(l.designFront),
        design_back: url(l.designBack),
        design_sleeve: url(l.designSleeve),
        design_hood: url(l.designHood),
      }));

      // ===== Đơn SHIP-BY-TIKTOK: dùng endpoint tiktok-shipping (label + tracking của TikTok, KHÔNG cần địa chỉ khách) =====
      if (o.shippingType === "TIKTOK" && o.labelUrl) {
        const cr = c as Record<string, unknown>;
        // Warehouse Merchize NHÚNG trong merchize_sku: [PRODUCT][REGION][số], vd MPTT`VN`000000AA04 → VN, MPTT`US`... → US.
        // Ưu tiên đọc từ SKU (đúng theo từng sản phẩm); không đọc được mới fallback về warehouse cấu hình ở fulfiller.
        const skuRegion = (sku: string) => (sku.match(/^[A-Z]+?(VN|US|UK|GB|EU|CN|AU|CA|MX)(?=\d)/)?.[1]) ?? "";
        const cfgWarehouse = String(cr.warehouse ?? cr.merchizeWarehouse ?? "").trim();
        const warehouse = skuRegion(String(items[0]?.merchize_sku ?? "")) || cfgWarehouse;
        // Merchize TikTok Shipping CHỈ nhận: USPS, FedEx, Evri, Royal Mail. Chuẩn hoá về tên gốc (vd "USPS Ground Advantage" → "USPS").
        const rawCarrier = (String(cr.carrier ?? cr.shippingProvider ?? "").trim()).toLowerCase();
        const carrier = rawCarrier.includes("fedex") ? "FedEx"
          : rawCarrier.includes("evri") ? "Evri"
          : rawCarrier.includes("royal") ? "Royal Mail"
          : "USPS"; // mặc định + mọi biến thể USPS (Ground Advantage, First Class…)
        if (!warehouse) return { ...simulate("merchize"), reason: `Không xác định được warehouse Merchize cho SKU ${items[0]?.merchize_sku ?? "?"} (SKU không nhúng mã kho VN/US…). Điền Warehouse ở Settings → Fulfillers → Merchize → đơn KHÔNG lên nhà in.` };
        if (!o.shippingTracking) return { ...simulate("merchize"), reason: "Đơn TikTok chưa có tracking number — lấy label TikTok trước rồi đẩy lại." };
        const rtt = await createMerchizeTiktokOrder(baseUrl, apiKey, {
          order_id: extNumber, identifier,
          shipping_info: { shipping_provider: carrier, shipping_label: o.labelUrl, merchize_warehouse: warehouse, tracking_number: o.shippingTracking },
          tags: ["tiktok"], // đơn ship-by-tiktok luôn là đơn TikTok Shop
          items,
        });
        return { externalFfId: rtt.orderCode, simulated: false, raw: rtt.raw, reason: "Đẩy qua TikTok-Shipping catalog (Merchize in & dán nhãn TikTok, không cần địa chỉ khách)." };
      }

      const res = await createMerchizeOrder(baseUrl, apiKey, {
        order_id: extNumber,
        identifier,
        shipping_info: {
          full_name: [o.buyerFirst, o.buyerLast].filter(Boolean).join(" ") || "Customer",
          address_1: o.addr1 || "",
          address_2: o.addr2 || "",
          city: o.city || "",
          state: o.state || "",
          postcode: o.zip || "",
          country: toISO2(o.country),
          email: o.email || undefined,
          phone: o.phone || undefined,
        },
        ...(merchizeTags ? { tags: merchizeTags } : {}),
        items,
      });
      // KHÔNG AUTO-PAY (mặc định): bước push = CONFIRM đi sản xuất → Merchize trừ balance ngay.
      // Đơn giờ chỉ TẠO Ở DRAFT — người phụ trách kiểm tra rồi tự confirm trên web Merchize.
      // Muốn khôi phục auto-confirm như cũ: thêm credentials { "autoConfirm": "true" }.
      const autoConfirm = String((c as Record<string, unknown>).autoConfirm ?? "") === "true" || String((c as Record<string, unknown>).autoConfirm ?? "") === "1";
      if (res.orderCode && autoConfirm) {
        try { await pushMerchizeOrder(baseUrl, apiKey, { code: res.orderCode, external_number: extNumber, identifier }); }
        catch (e) { throw new Error(`Đã tạo đơn ${res.orderCode} nhưng push (confirm) lỗi: ${String((e as Error)?.message ?? e)}`); }
      }
      return {
        externalFfId: res.orderCode, simulated: false, raw: res.raw,
        reason: autoConfirm ? undefined : "Created as DRAFT on Merchize — review & confirm (pay) it on Merchize web. Set credentials autoConfirm=true to restore auto-confirm.",
      };
    },
  };
}

// ---- Tách Color / Size từ nhãn variant của mapping (vd "Black / L", "L / Black", "As Design / XL") ----
const SIZE_RX = /^(xs|s|m|l|xl|2xl|3xl|4xl|5xl|xxl|xxxl|xxxxl|xxxxxl|one size|os|\d+(\.\d+)?\s*(x\s*\d+(\.\d+)?)?\s*(inch|inches|in|cm|oz)?)$/i;
export function splitColorSize(variant: string | null | undefined): { color: string; size: string } {
  const parts = (variant ?? "").split("/").map((s) => s.trim()).filter(Boolean);
  if (!parts.length) return { color: "", size: "" };
  if (parts.length === 1) return SIZE_RX.test(parts[0]) ? { color: "", size: parts[0] } : { color: parts[0], size: "" };
  // 2+ phần: phần khớp regex size là size, còn lại là color (mặc định [color, size])
  const sizeIdx = parts.findIndex((p) => SIZE_RX.test(p));
  if (sizeIdx >= 0) {
    const size = parts[sizeIdx];
    const color = parts.filter((_, i) => i !== sizeIdx).join(" / ");
    return { color, size };
  }
  return { color: parts[0], size: parts[parts.length - 1] };
}

/**
 * Adapter ONOS (OnosPOD) THẬT — POST /order/create (Bearer token).
 * credentials = { apiKey: <token HOẶC "email:password"> }; tuỳ chọn { identifier, shippingMethod, testMode }.
 * lines[].fulfillerSku = SKU variant ONOS; fulfillerProductId = product_id; variant = "Color / Size".
 * (order_id + identifier) là khoá duy nhất phía ONOS → identifier cố định để dedupe hoạt động.
 */
function onosAdapter(): FulfillerAdapter {
  return {
    slug: "onospod",
    label: "Onospod",
    async push(ctx) {
      const cred = (ctx.fulfiller.credentials ?? {}) as Record<string, string>;
      const apiKey = cred.apiKey || cred.accessToken || cred.apiToken || "";
      if (!apiKey) return { ...simulate("onospod"), reason: "ONOS token missing (Settings → API Key: paste token or email:password) → order NOT sent to the printer" };

      const o = ctx.order;
      const url = (u?: string | null) => (typeof u === "string" && /^https?:\/\//i.test(u.trim())) ? u.trim() : undefined;
      const items: OnosItem[] = ctx.lines.map((l) => {
        const { color, size } = splitColorSize(l.variant);
        const it: OnosItem = {
          sku: l.fulfillerSku,
          quantity: l.qty,
          name: l.fulfillerProduct || l.fulfillerSku,
          product_id: l.productId || undefined,
          price: l.price,
          currency: l.currency || "USD",
          image: url(l.image),
          // attributes tối thiểu cần product + Color + Size (docs ONOS)
          attributes: [
            { name: "product", option: l.fulfillerProduct || l.fulfillerSku },
            { name: "Color", option: color || "As Design" },
            { name: "Size", option: size || "One Size" },
          ],
        };
        if (url(l.designFront)) it.design_front = url(l.designFront);
        if (url(l.designBack)) it.design_back = url(l.designBack);
        if (url(l.designHood)) it.design_hood = url(l.designHood);
        return it;
      });

      // Đơn Ship-by-TikTok (có label) → SBTT + tracking.link_print = link nhãn TikTok. Đơn khác giữ nguyên như cũ.
      const isTtLabel = !!o.labelUrl;
      const method = isTtLabel ? "SBTT" as const : (["ONOSEXPRESS", "SBTT", "COD"].includes(cred.shippingMethod) ? cred.shippingMethod as "ONOSEXPRESS" | "SBTT" | "COD" : "ONOSEXPRESS");
      const res = await createOnosOrder({ apiKey, endpoint: ctx.fulfiller.apiEndpoint }, {
        order_id: orderExtNumber(o),
        identifier: cred.identifier || "FUSION",
        reference_id: o.externalId,
        items,
        ...(isTtLabel ? { inc_active_service: true, tracking: { tracking_number: o.shippingTracking || "", carrier: "USPS", link_print: o.labelUrl || undefined } } : {}),
        shipping_info: {
          full_name: [o.buyerFirst, o.buyerLast].filter(Boolean).join(" ") || "Customer",
          address_1: o.addr1 || "",
          address_2: o.addr2 || undefined,
          city: o.city || "",
          state: o.state || "",
          postcode: o.zip || "",
          country: toISO2(o.country || "United States"),
          email: o.email || undefined,
          phone: o.phone || undefined,
        },
        shipping_method: method,
      }, cred.testMode === "true" || cred.testMode === "1");
      return {
        externalFfId: res.onosId, simulated: false, raw: res.raw,
        reason: res.dedup ? "Order already existed on ONOS (from a previous failed push) — linked to it, no duplicate created" : undefined,
      };
    },
  };
}

/**
 * Adapter Wembroidery THẬT — POST /orders (token query param).
 * credentials = { apiKey: <store token> }; tuỳ chọn { shippingMethod ("standard"), ioss }.
 * lines[].fulfillerProductId = catalogId; variant = "Color / Size" (color snake_case theo catalog).
 * Design: imageUrl = ảnh design; nếu URL là file thêu (.emb/.dst/.pes...) thì gửi embUrl.
 */
function wembroideryAdapter(): FulfillerAdapter {
  return {
    slug: "wembroidery",
    label: "Wembroidery",
    async push(ctx) {
      const cred = (ctx.fulfiller.credentials ?? {}) as Record<string, string>;
      const apiKey = cred.apiKey || cred.accessToken || cred.apiToken || "";
      if (!apiKey) return { ...simulate("wembroidery"), reason: "Wembroidery token missing (Settings → API Key: paste store token) → order NOT sent to the printer" };

      const o = ctx.order;
      const url = (u?: string | null) => (typeof u === "string" && /^https?:\/\//i.test(u.trim())) ? u.trim() : undefined;
      const EMB_RX = /\.(emb|dst|pes|exp|jef|vp3|xxx)(\?|#|$)/i;
      const design = (location: string, u?: string | null, mockup?: string | null): WemDesign | null => {
        const link = url(u);
        if (!link) return null;
        const d: WemDesign = { location };
        if (EMB_RX.test(link)) d.embUrl = link; else d.imageUrl = link;
        if (url(mockup)) d.mockup = url(mockup);
        return d;
      };
      // Chuẩn hoá color về snake_case theo catalog Wembroidery (black, sport_grey...)
      const snake = (s: string) => s.trim().toLowerCase().replace(/\s+/g, "_");

      const badLine = ctx.lines.find((l) => !Number(l.productId));
      if (badLine) throw new Error(`Wembroidery needs a numeric catalogId in SKU mapping for "${badLine.fulfillerSku}" (pull via Update SKU on the Wembroidery tab)`);

      // Locations THẬT theo catalog ("front" không tồn tại ở nhiều catalog — T-shirt dùng center_chest...)
      const { resolveWemLocations } = await import("@/lib/wembroidery");
      const wemCred = { apiKey, endpoint: ctx.fulfiller.apiEndpoint };
      const items: WemItem[] = await Promise.all(ctx.lines.map(async (l) => {
        const { color, size } = splitColorSize(l.variant);
        const loc = await resolveWemLocations(wemCred, String(l.productId));
        const designs = [
          design(loc.front, l.designFront, l.image),
          design(loc.back, l.designBack),
        ].filter(Boolean) as WemDesign[];
        if (!designs.length && url(l.image)) designs.push({ location: loc.front, imageUrl: url(l.image)! });
        return {
          catalogId: Number(l.productId),
          designs,
          quantity: l.qty,
          size: size.toLowerCase() || "m",
          color: snake(color) || "black",
        };
      }));

      const res = await createWembroideryOrder({ apiKey, endpoint: ctx.fulfiller.apiEndpoint }, {
        address: {
          firstName: (o.buyerFirst || "").trim() || "Customer",
          lastName: (o.buyerLast || "").trim() || ".",
          address1: o.addr1 || "",
          address2: o.addr2 || undefined,
          city: o.city || "",
          state: usStateAbbr(o.state || ""),
          zip: o.zip || "",
          country: toISO2(o.country || "United States"),
          email: o.email || undefined,
          phone: o.phone || undefined,
        },
        sellerOrderId: orderExtNumber(o),
        shippingMethod: cred.shippingMethod || "standard",
        ioss: cred.ioss || undefined,
        items,
      });
      return {
        externalFfId: res.wemId, simulated: false, raw: res.raw,
        baseCost: res.baseCost, shipCost: res.shipCost,
        reason: res.dedup ? "Order already existed on Wembroidery (from a previous failed push) — linked to it, no duplicate created" : undefined,
      };
    },
  };
}

/** Google Sheet: sinh giá trị cho 1 cột (theo tên header) từ order + line. Cột không map (supplier điền) → "". */
function gsheetFieldValue(header: string, o: PushCtx["order"], l: PushLine): string {
  const key = normHeader(header);
  const side = (k: string) => l.designSides?.find((s) => s.kind === k)?.url ?? "";
  const fullName = [o.buyerFirst, o.buyerLast].filter(Boolean).join(" ");
  const addr12 = [o.addr1, o.addr2].filter(Boolean).join(" "); // cột gộp "Address 1&2" của Zootop
  const cs = splitColorSize(l.variant); // tách Color / Size từ nhãn variant (vd "Black / L")
  const dFront = side("design_front") || l.designFront || "";
  const dBack = side("design_back") || l.designBack || "";
  const shipType = o.shippingType === "SELLER" ? "SELLER" : "PLATFORM"; // TIKTOK/khác → PLATFORM
  const map: Record<string, string> = {
    date: new Date().toISOString().slice(0, 10),
    order_id: o.externalId, orderid: o.externalId, order: o.externalId, order_number: o.externalId,
    shipping_type: shipType, shippingtype: shipType,
    buyer_first_name: o.buyerFirst ?? "", first_name: o.buyerFirst ?? "", firstname: o.buyerFirst ?? "",
    buyer_last_name: o.buyerLast ?? "", last_name: o.buyerLast ?? "", lastname: o.buyerLast ?? "",
    customer_s_name: fullName, customers_name: fullName, customer_name: fullName, name: fullName, buyer_name: fullName, recipient: fullName,
    buyer_phone_number: o.phone ?? "", phone: o.phone ?? "", phone_number: o.phone ?? "",
    buyer_email: o.email ?? "", email: o.email ?? "",
    buyer_country: o.country ?? "", country: o.country ?? "", country_code: o.country ?? "",
    buyer_state: o.state ?? "", state: o.state ?? "", state_province: o.state ?? "", state_code: o.state ?? "",
    buyer_city: o.city ?? "", city: o.city ?? "",
    buyer_address_1: o.addr1 ?? "", address_line_1: o.addr1 ?? "", address_1: o.addr1 ?? "", address1: o.addr1 ?? "", address: o.addr1 ?? "",
    buyer_address_2: o.addr2 ?? "", address_line_2: o.addr2 ?? "", address_2: o.addr2 ?? "", address2: o.addr2 ?? "",
    address_1_2: addr12, address_1_and_2: addr12, address_1_2_shipping: addr12, // Zootop cột gộp
    buyer_postcode: o.zip ?? "", zip: o.zip ?? "", postcode: o.zip ?? "", zip_code: o.zip ?? "", postal_code: o.zip ?? "", postcode_code: o.zip ?? "",
    quantity: String(l.qty), qty: String(l.qty),
    sku: l.fulfillerSku, sku_basic: l.fulfillerSku, // Zootop "SKU BASIC"
    size: cs.size, color: cs.color, // Zootop Size/Color (tách từ variant). Type không có sẵn → để trống
    design_front: dFront, design_back: dBack,
    design_link_front: dFront, design_link_back: dBack, // Zootop "design link front/back"
    design_sleeve_left: side("sleeve_left"), design_sleeve_right: side("sleeve_right"),
    note: l.personalization ?? "", product_note: l.personalization ?? "", personalization: l.personalization ?? "",
    customer_note: l.personalization ?? "", custome_name: l.personalization ?? "", // Zootop "Customer Note" / "CUSTOME NAME"
    link_label: o.labelUrl ?? "", // đơn TikTok-shipping → link nhãn TikTok; đơn khác trống
  };
  // STATUS / tracking_number / tracking_status / *_cost / shipping_fee / mockup_* / store_code / variant_id / card_code → "" (supplier điền / chưa có)
  return map[key] ?? "";
}

/** Adapter Google Sheet: push = append 1 dòng/item (map theo tên header). Đơn nhiều item → nhiều dòng, chung order_id. */
function gsheetAdapter(): FulfillerAdapter {
  return {
    slug: "gsheet",
    label: "Google Sheet",
    async push(ctx) {
      const c = (ctx.fulfiller.credentials ?? {}) as { sheetId?: string; tab?: string };
      if (!c.sheetId || !c.tab) throw new Error("Fulfiller Google Sheet chưa cấu hình Sheet ID / Tab.");
      const headers = await getSheetHeaders(c.sheetId, c.tab);
      if (!headers.length) throw new Error(`Tab "${c.tab}" không có dòng header (hàng 1). Kiểm tra tên tab + đã share Sheet cho service account chưa.`);
      for (const l of ctx.lines) {
        const row = headers.map((h) => gsheetFieldValue(h, ctx.order, l));
        await appendSheetRow(c.sheetId, c.tab, row);
      }
      return { externalFfId: `GSHEET-${ctx.order.externalId}`, simulated: false };
    },
  };
}

/** Chuẩn hoá tên nhà fulfill → slug (bỏ dấu, khoảng trắng, ký tự đặc biệt). */
export function slugifyFulfiller(name: string): string {
  return name.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]/g, "");
}

/** Lấy adapter theo credentials.kind (Google Sheet) rồi tới tên nhà fulfill; không khớp → generic simulate. */
export function getAdapter(name: string, credentials?: unknown): FulfillerAdapter {
  const cred = (credentials ?? {}) as { kind?: string };
  if (cred.kind === "gsheet") return gsheetAdapter();
  const slug = slugifyFulfiller(name);
  return FULFILLER_ADAPTERS[slug] ?? makeAdapter(slug || "generic", name);
}


/**
 * Adapter COMPASSUP THẬT — POST /openapi/1/orders.
 *
 * Nhà SOURCING/DROPSHIP trung gian: sản phẩm từ sup TQ (b2b_cn), Compassup gộp mọi item
 * thành 1 đơn = 1 tracking. KHÔNG phải POD → không design (trừ item custom).
 *
 * credentials = {
 *   bearerToken, tenant, restKey, username,   // auth + ký sign
 *   accountId,                                 // account_id (shop bên Compassup)
 *   warehouseId,                               // warehouse_id (cố định)
 *   goodType?: "normal", transport?: "fast",   // services (mặc định normal/fast)
 *   shippingType?: "seller",                   // seller | platform
 *   shippingFrom?: "CN",
 * }
 * lines[].fulfillerSku      = sku_id Compassup
 * lines[].fulfillerProductId = product_id
 * lines[].extra             = { link, sup_site, seller_id, weight, image_link, declaration_title, custom?, attachments? }
 */
function compassupAdapter(): FulfillerAdapter {
  return {
    slug: "compassup", label: "Compassup",
    async push(ctx) {
      const cr = (ctx.fulfiller.credentials ?? {}) as Record<string, string>;
      const token = cr.bearerToken || cr.apiKey || cr.accessToken;
      if (!token || !cr.tenant || !cr.restKey || !ctx.fulfiller.apiEndpoint) return simulate("compassup");

      const cred: CompassupCred = {
        bearerToken: token, tenant: cr.tenant, restKey: cr.restKey,
        endpoint: ctx.fulfiller.apiEndpoint, username: cr.username || cr.tenant,
      };
      const o = ctx.order;
      const num = orderExtNumber(o);

      const items: CompassupItem[] = ctx.lines.map((l) => {
        const ex = (l.extra ?? {}) as Record<string, unknown>;
        const weightEach = Number(ex.weight ?? 0) || 0.1; // fallback 0.1kg nếu SP không có weight
        // Có design gán vào (designSides) = coi như custom → đính link file design cho nhà in.
        const isCustom = ex.custom === true || (Array.isArray(ex.attachments) && (ex.attachments as unknown[]).length > 0) || (l.designSides?.length ?? 0) > 0;
        const it: CompassupItem = {
          product_id: String(l.fulfillerProductId ?? ex.product_id ?? ""),
          sku_id: l.fulfillerSku,
          product_name: String(ex.product_name ?? l.fulfillerProduct ?? l.internalSku ?? ""),
          declaration_title: String(ex.declaration_title ?? ex.product_name ?? l.fulfillerProduct ?? ""),
          quantity: l.qty,
          weight: Math.round(weightEach * l.qty * 1000) / 1000,
          attribute: String(ex.attribute ?? l.variant ?? ""),
          image_link: String(ex.image_link ?? l.image ?? ""),
          link: String(ex.link ?? ""),
          sup_site: String(ex.sup_site ?? "b2b_cn"),
          seller_id: String(ex.seller_id ?? ""),
          state: String(ex.state ?? "confirmed"),
          warehouse_id: String(ex.warehouse_id ?? cr.warehouseId ?? ""),
        };
        // Đơn CUSTOM: gắn type + attachments (link file design bên mình)
        if (isCustom) {
          it.type = "custom";
          const att = (Array.isArray(ex.attachments) ? ex.attachments : []) as { src: string; type?: string }[];
          it.attachments = att.map((a) => ({ src: String(a.src), type: a.type || "link" }));
          // Nếu chưa cấp attachments nhưng có designSides → dùng chúng
          if (!it.attachments.length && l.designSides?.length) {
            // Bỏ file máy thêu (.dst/.emb) — nhà này nhận ảnh in, gửi file máy vào là đơn hỏng.
            it.attachments = l.designSides.filter((d) => !isEmbKind(d.kind) && !EMB_FILE_RX.test(d.url)).map((d) => ({ src: d.url, type: "link" })); // v152 · xét cả kind, storage key không giữ đuôi .dst
          }
        }
        return it;
      });

      const totalWeight = Math.round(items.reduce((a, i) => a + i.weight, 0) * 1000) / 1000;

      const res = await createCompassupOrder(cred, {
        platform: (cr.platform || detectPlatform(o.orderLabel) || "etsy"),
        account_id: cr.accountId || cr.account_id || "",
        shipping_country: toISO2(o.country) || "US",
        shipping_from: cr.shippingFrom || "CN",
        shipping_name: [o.buyerFirst, o.buyerLast].filter(Boolean).join(" ") || "Customer",
        shipping_phone: o.phone || "0000000000",
        shipping_address: [o.addr1, o.addr2].filter(Boolean).join(", "),
        shipping_city: o.city || "",
        shipping_state: o.state || "",
        shipping_zipcode: o.zip || "",
        own_code: num,
        items,
        shipping_type: cr.shippingType || "seller",
        weight_before: totalWeight || 0.1,
        services: { good_type: cr.goodType || "normal", transport: cr.transport || "fast" },
        certificate_type: "", certificate_code: "",
      });
      return { externalFfId: res.orderId, simulated: false, raw: res.raw };
    },
  };
}

/** Đoán platform từ orderLabel (STORE-<id>): số đơn TikTok toàn số dài, Etsy có tiền tố cửa hàng. */
function detectPlatform(label?: string | null): string | null {
  if (!label) return null;
  return /tiktok/i.test(label) ? "tiktok" : /etsy/i.test(label) ? "etsy" : null;
}

/**
 * THROTTLE POLL NHÀ IN — mặc định 2 phút (trước là 10 phút → tracking về quá chậm).
 * Chỉnh bằng env FF_POLL_THROTTLE_MS. Đặt 0 = không throttle (chỉ nên dùng khi debug:
 * mỗi nhà in đều có rate limit, vd Printway 50 req/3s).
 */
export const FF_POLL_THROTTLE_MS = Number(process.env.FF_POLL_THROTTLE_MS ?? 2 * 60_000);
