-- v567 · CHỦ LISTING SHOPIFY — "của ai người đó thấy" như shopbase/woo.
-- 1) Thêm cột created_by (users.id). NULL = bản sync / không rõ người tạo → mọi seller thấy, chỉ admin sửa.
ALTER TABLE shopify_products ADD COLUMN IF NOT EXISTS created_by uuid;

-- 2) BACKFILL cho listing đã stage từ Etsy: chủ = SELLER CỦA SHOP ETSY NGUỒN.
-- Flow mới (v172): shopify_products.etsy_product_id → etsy_products → stores.seller_id
UPDATE shopify_products sp
SET created_by = s.seller_id
FROM etsy_products ep
JOIN stores s ON s.id = ep.store_id
WHERE sp.etsy_product_id = ep.id
  AND sp.created_by IS NULL
  AND s.seller_id IS NOT NULL;

-- Flow cũ: etsy_products.shopify_product_id (GID) trỏ ngược vào listing Shopify
UPDATE shopify_products sp
SET created_by = s.seller_id
FROM etsy_products ep
JOIN stores s ON s.id = ep.store_id
WHERE sp.created_by IS NULL
  AND sp.shopify_product_id <> ''
  AND ep.shopify_product_id = sp.shopify_product_id
  AND s.seller_id IS NOT NULL;

-- Kiểm tra sau khi chạy: số listing theo chủ (NULL = chưa rõ chủ, mọi seller vẫn thấy)
-- SELECT u.full_name, count(*) FROM shopify_products sp
-- LEFT JOIN users u ON u.id = sp.created_by GROUP BY 1 ORDER BY 2 DESC;
