-- v570 · RULE ENGINE Meta ads — verdict per ad + log + config + budget history.
CREATE TABLE IF NOT EXISTS meta_rule_state (
  ad_id           text PRIMARY KEY,
  verdict         text NOT NULL,
  phase           text,
  reason          text,
  metrics         jsonb,
  since           timestamptz NOT NULL DEFAULT now(),
  auto_paused     boolean NOT NULL DEFAULT false,
  auto_paused_at  timestamptz,
  pause_reason    text,
  resume_at       timestamptz,
  rule_version    text,
  updated_at      timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS meta_rule_log (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ad_id         text NOT NULL,
  ad_name       text,
  verdict       text,
  action        text NOT NULL,
  metrics       jsonb,
  rule_version  text,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_meta_rule_log_ad ON meta_rule_log(ad_id, created_at);

CREATE TABLE IF NOT EXISTS meta_rule_config (
  id                  int PRIMARY KEY DEFAULT 1,
  config              jsonb,
  engine_last_run_at  timestamptz,
  updated_at          timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS meta_budget_log (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  adset_id   text NOT NULL,
  budget     numeric(12,2) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_meta_budget_log_adset ON meta_budget_log(adset_id, created_at);
