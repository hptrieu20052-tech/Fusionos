-- v572 · Seller của campaign Meta — filter theo seller + khối "Spend by seller" ở Ads Center.
-- NULL = UI tự đoán từ tên campaign (token đầu không phải từ khoá CAMP/TEST/MAIN...).
ALTER TABLE meta_campaigns ADD COLUMN IF NOT EXISTS seller text;
