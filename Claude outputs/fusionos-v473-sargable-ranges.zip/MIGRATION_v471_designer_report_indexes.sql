-- MIGRATION v471 · Index tăng tốc Designer/Creator Report (Dashboard)
-- Lý do: report của ADMIN (không lọc scope) query theo NGÀY mà không lọc seller/designer,
-- nhưng bảng orders chỉ có index composite dẫn đầu bằng seller (idx_orders_seller_at_date),
-- nên lọc theo ordered_at đơn thuần phải full-scan → chậm/timeout → UI kẹt "Loading".
-- Các index dưới đây an toàn (IF NOT EXISTS), chỉ đọc thêm, không đổi dữ liệu.

-- (1) QUAN TRỌNG NHẤT: lọc đơn theo NGÀY phát sinh, không kèm seller (query sale của Designer Report).
CREATE INDEX IF NOT EXISTS idx_orders_ordered_at ON orders (ordered_at);

-- (2) Creator Report (by=content): gom/ lọc theo creator_id theo ngày tạo design.
CREATE INDEX IF NOT EXISTS idx_designs_creator_created ON designs (creator_id, created_at);

-- (3) Điểm review theo kỳ: lọc design_reviews theo created_at (đang chỉ có index theo design_id).
CREATE INDEX IF NOT EXISTS idx_reviews_created ON design_reviews (created_at);

-- (4) Số video trong kỳ cho Creator Report: lọc product_videos theo created_at.
CREATE INDEX IF NOT EXISTS idx_pvideos_created ON product_videos (created_at);

-- Gợi ý sau khi tạo index: chạy ANALYZE để planner cập nhật thống kê.
ANALYZE orders;
ANALYZE designs;
ANALYZE design_reviews;
ANALYZE product_videos;
