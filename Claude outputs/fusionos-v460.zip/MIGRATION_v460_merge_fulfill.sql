-- v460 · Gộp đơn cùng khách khi đẩy fulfillment (Shopify split orders)
-- Chạy trong Supabase SQL Editor. Idempotent — chạy lại không sao.

ALTER TABLE fulfillment_orders
  ADD COLUMN IF NOT EXISTS merged_order_ids jsonb;

-- Index cho truy vấn "đơn này có nằm trong lần đẩy gộp nào không" (jsonb @> '[...]')
CREATE INDEX IF NOT EXISTS idx_ff_merged_order_ids
  ON fulfillment_orders USING gin (merged_order_ids jsonb_path_ops);
