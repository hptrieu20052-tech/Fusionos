// Etsy trả variant/personalization đã escape HTML ("3&quot;" thay vì '3"').
// Decode ngay tại nguồn để mọi thứ phía sau (DB, UI, file gửi nhà in) đều sạch.
const ENT = { quot: '"', apos: "'", amp: "&", lt: "<", gt: ">", nbsp: " ",
  ldquo: "\u201C", rdquo: "\u201D", lsquo: "\u2018", rsquo: "\u2019",
  hellip: "\u2026", mdash: "\u2014", ndash: "\u2013", middot: "\u00B7", deg: "\u00B0", times: "\u00D7" };
function dec(v) {
  if (!v) return v;
  return String(v).replace(/&(#x?[0-9a-f]+|[a-z][a-z0-9]*);/gi, function (m, g) {
    if (g[0] === "#") {
      var code = g[1].toLowerCase() === "x" ? parseInt(g.slice(2), 16) : parseInt(g.slice(1), 10);
      return isFinite(code) && code > 0 && code < 0x110000 ? String.fromCodePoint(code) : m;
    }
    return ENT[g.toLowerCase()] || m;
  });
}


/*
 * background.js — bộ não Fusion Etsy Puller (tái thiết v1.1.0).
 * Nhận JSON Etsy thô từ content.js ("etsy-data") → bóc receipt → buffer (dedupe theo receipt id)
 * → "sync" đẩy lên FUSION (POST {orders} + Bearer store token) → "status" tra trạng thái/tracking
 * cho overlay. Kèm check bản mới từ server FUSION (badge NEW).
 */

const UPDATE_BASE = "https://os.fusiondn.com";

// ===== Buffer đơn đã bắt (RAM + backup storage.local vì service worker hay ngủ) =====
let BUF = new Map(); // externalId -> InOrder
const DROPPED = new Set(); // receipt id đã BỎ vì huỷ/hoàn tiền → node địa chỉ KHÔNG được hồi sinh
const FILES_BUF = new Map(); // orderId -> [{name,url}] ảnh khách đọc từ DOM (gắn vào đơn khi harvest)
let bufLoaded = false;
async function loadBuf() {
  if (bufLoaded) return;
  bufLoaded = true;
  try {
    const { fp_buf } = await chrome.storage.local.get("fp_buf");
    if (Array.isArray(fp_buf)) for (const o of fp_buf) if (o && o.externalId) BUF.set(o.externalId, o);
  } catch (_) {}
}
function saveBuf() {
  try { chrome.storage.local.set({ fp_buf: Array.from(BUF.values()).slice(0, 500) }); } catch (_) {}
}
function broadcastCount() {
  updateBadge();
  chrome.tabs.query({ url: "https://www.etsy.com/*" }, (tabs) => {
    for (const t of tabs) { try { chrome.tabs.sendMessage(t.id, { type: "count-changed" }); } catch (_) {} }
  });
}

// ===== Tiền: {amount,divisor} | "US$1,234.56" | number =====
function money(v) {
  if (v == null) return 0;
  if (typeof v === "number") return isNaN(v) ? 0 : v;
  if (typeof v === "string") { const n = Number(v.replace(/[^0-9.\-]/g, "")); return isNaN(n) ? 0 : n; }
  if (typeof v === "object") {
    if (v.amount != null && v.divisor) return Number(v.amount) / Number(v.divisor);
    if (typeof v.formatted_value === "string") return money(v.formatted_value); // "$47.08"
    if (v.currency_code != null && typeof v.value === "number") return v.value / 100; // Mission Control: cents
    if (v.amount != null) return money(v.amount);
    if (v.value != null) return money(v.value);
    if (v.formatted != null) return money(v.formatted);
  }
  return 0;
}
const S = (v) => (typeof v === "string" && v.trim() ? v.trim() : (typeof v === "number" ? String(v) : ""));
const pick = (o, ...keys) => { for (const k of keys) { const v = S(o && o[k]); if (v) return v; } return ""; };

// ===== Nhận diện + bóc receipt (khớp InOrder của /api/ingest/etsy) =====
function looksLikeReceipt(o) {
  if (!o || typeof o !== "object" || Array.isArray(o)) return false;
  const id = o.receipt_id ?? o.receiptId ?? o.order_id ?? o.orderId;
  if (id == null || !/^\d{6,15}$/.test(String(id))) return false;
  return !!(o.transactions || o.line_items || o.first_line || o.address_first_line || o.name || o.buyer ||
    o.grandtotal || o.grand_total || o.formatted_grandtotal || o.total_price ||
    o.shipping_address || o.to_address || o.payment);
}
// Ảnh KHÁCH upload trên Etsy = ảnh CDN có "ipf_fullxfull" trong link (ipf = image personalization file).
// Đây là tín hiệu chắc chắn (ảnh listing là "il_", không nhầm). Lấy kèm tên file gốc nếu có cùng object.
function extractBuyerFiles(t) {
  const out = [], seen = new Set();
  const httpUrl = (u) => typeof u === "string" && /^https?:\/\//i.test(u);
  const toFull = (u) => u.replace(/ipf_\d+x\d+/i, "ipf_fullxfull"); // thumbnail → ảnh gốc
  const isBuyerImg = (u) => httpUrl(u) && /i\.etsystatic\.com\/ipf\//i.test(u);
  const isFileName = (n) => typeof n === "string" && /\.[a-z0-9]{2,5}$/i.test(n.trim());
  const URL_KEYS = ["url", "file_url", "download_url", "src", "href", "image_url", "original_url", "full_url", "url_fullxfull"];
  const NAME_KEYS = ["filename", "file_name", "name", "title", "display_name"];
  const add = (name, url) => {
    const full = toFull(String(url || "")); // luôn lưu bản fullxfull để TẢI được ảnh gốc
    if (!httpUrl(full) || seen.has(full)) return;
    seen.add(full);
    out.push({ name: String(name || (full.split("?")[0].split("/").pop()) || "photo").slice(0, 150), url: full });
  };
  (function walk(node, depth) {
    if (!node || depth > 8) return;
    if (Array.isArray(node)) { for (const x of node) walk(x, depth + 1); return; }
    if (typeof node === "object") {
      // URL ảnh khách trong object → lấy kèm tên file gốc (IMG_xxx.jpg) nếu cùng object.
      let url = "";
      for (const k of URL_KEYS) if (isBuyerImg(node[k])) { url = node[k]; break; }
      if (url) {
        let name = "";
        for (const k of NAME_KEYS) if (isFileName(node[k])) { name = node[k]; break; }
        for (const k of NAME_KEYS) if (!name && typeof node[k] === "string" && node[k].trim()) { name = node[k]; break; }
        add(name, url);
      }
      // Dự phòng: object có {filename, url http} rõ ràng (kể cả không phải ipf).
      if (!url) {
        let u2 = ""; for (const k of URL_KEYS) if (httpUrl(node[k])) { u2 = node[k]; break; }
        let n2 = ""; for (const k of NAME_KEYS) if (isFileName(node[k])) { n2 = node[k]; break; }
        if (u2 && n2) add(n2, u2);
      }
      for (const k in node) walk(node[k], depth + 1);
    } else if (isBuyerImg(node)) {
      add("", node); // chuỗi URL ipf_fullxfull trần
    }
  })(t, 0);
  return out.slice(0, 30);
}
function extractItems(o) {
  const txs = Array.isArray(o.transactions) ? o.transactions : (Array.isArray(o.line_items) ? o.line_items : []);
  const items = [];
  for (const t of txs) {
    if (!t || typeof t !== "object") continue;
    const L = (t.listing && typeof t.listing === "object") ? t.listing : {};
    const PR = (t.product && typeof t.product === "object") ? t.product : {};
    const priceInt = (t.price_int != null && !isNaN(Number(t.price_int))) ? Number(t.price_int) / 100 : 0;
    const usd = (typeof t.usd_price === "number") ? t.usd_price / 100 : 0; // Mission Control: cents
    const it = {
      title: pick(PR, "title", "name")
        || pick(t, "title", "listing_title", "product_title", "product_name", "name")
        || pick(L, "title", "name") || "Etsy item",
      qty: Number(t.quantity ?? t.qty ?? 1) || 1,
      price: money(t.price ?? t.unit_price ?? t.subtotal ?? t.total) || usd || priceInt,
      sku: pick(t, "sku", "product_sku") || pick(PR, "product_identifier", "sku") || undefined,
      listingId: S(t.listing_id ?? t.listingId ?? L.listing_id ?? L.id) || undefined,
    };
    // Etsy có 2 kiểu thuộc tính, TRẢ LẪN LỘN trong cùng mảng `variations`:
    //  - Variation thật:  "Types: Iron On", "Sizes: 4x4"   (khách chọn từ danh sách)
    //  - Custom option:   "Please enter the name here: ..."  (khách TỰ NHẬP — tính năng mới của Etsy)
    // Seller tự đặt tên field nên KHÔNG thể lọc bằng /personal/. Trước đây lọc vậy → custom option
    // rơi vào variant, cột personalization rỗng → hệ thống tưởng đơn thường → gợi ý design → IN SAI TÊN.
    //
    // Giờ: GIỮ MỌI FIELD trong variant (hiện đủ, tách dòng như Etsy), đồng thời nhận diện rộng hơn
    // để vẫn set personalization làm CỜ chặn gợi ý design.
    var PROMPT_RE = /enter|type\s+your|your\s+name|personaliz|monogram|initial|message|note|custom\s*text|dedication|inscription|font|spelling/i;
    const vars = Array.isArray(t.variations) ? t.variations : [];
    const vparts = [], pparts = [];
    for (const v of vars) {
      const n = pick(v, "property", "formatted_name", "property_name", "name");
      const val = pick(v, "value", "formatted_value");
      if (!n && !val) continue;
      // Mọi field đều vào variant → không mất thông tin nào
      vparts.push(n && val ? `${dec(n)}: ${dec(val)}` : dec(val || n));
      // Field dạng câu nhắc nhập → cũng ghi vào personalization (cờ chặn suggest)
      if (n && (PROMPT_RE.test(n) || n.trim().endsWith("?"))) pparts.push(dec(val || n));
    }
    // Personalization GỐC của Etsy (field riêng, KHÔNG nằm trong variations) — vd "Personalization: Leilani".
    // Nếu chưa có trong variations thì thêm vào variant để hiện đủ.
    const nativePz = dec(S(t.personalization ?? t.buyer_personalization));
    if (nativePz && !vparts.some((p) => p.indexOf(nativePz) !== -1)) vparts.push("Personalization: " + nativePz);
    // Cap rộng tay để KHÔNG cắt cụt dedication/message dài.
    if (vparts.length) it.variant = vparts.join(" · ").slice(0, 3000);
    const pz = pparts.join(" · ") || nativePz;
    if (pz) it.personalization = pz.slice(0, 3000);
    const img = t.image || t.img || PR.image || {};
    let iurl = pick(PR, "image_url_75x75", "image_url") || pick(img, "url_170x135", "url_75x75", "url", "src") || S(t.image_url);
    if (iurl) it.imageUrl = iurl.replace(/il_\d+x\d+\./, "il_570xN.").replace(/([?&])(w|h)=\d+/g, "");
    // Ảnh khách upload (loại trùng với ảnh chính của item)
    const bf = extractBuyerFiles(t).filter((f) => !it.imageUrl || f.url !== it.imageUrl);
    if (bf.length) it.files = bf;
    items.push(it);
  }
  return items;
}
function firstObj(o) {
  for (var i = 1; i < arguments.length; i++) {
    var v = o && o[arguments[i]];
    if (v && typeof v === "object" && !Array.isArray(v)) return v;
  }
  return null;
}
function extractReceipt(o) {
  const id = String(o.receipt_id ?? o.receiptId ?? o.order_id ?? o.orderId);
  // Địa chỉ/buyer/total có thể nằm ở gốc HOẶC lồng trong object con
  const A = firstObj(o, "shipping_address", "to_address", "shipment_address", "address", "shipping_details") || {};
  const B = firstObj(o, "buyer", "buyer_user", "customer") || {};
  const P = firstObj(o, "payment", "totals", "pricing") || {};
  // BUG CŨ: đọc field địa chỉ từ ROOT (o) TRƯỚC → o.state="active" (trạng thái đơn) lọt vào ô State,
  // và field rác lọt vào Address 2 ("Apt 101"/"41"/"4"…). Receipt gốc có nhiều field trùng tên địa chỉ.
  // SỬA (an toàn 2 chiều): ưu tiên object địa chỉ A; field nào A THIẾU thì FALLBACK root để KHÔNG
  // bao giờ thiếu địa chỉ (thiếu → carrier trả hàng). RIÊNG state & address2 hay dính rác trên root →
  // khi ĐÃ CÓ A thì không lấy bừa từ root (state chỉ nhận key đã disambiguate; address2 không fallback).
  const hasA = A && Object.keys(A).length > 0;
  const gA = (...keys) => pick(A, ...keys);
  const gO = (...keys) => pick(o, ...keys);
  const both = (...keys) => gA(...keys) || gO(...keys); // A trước, thiếu thì root — đủ địa chỉ
  const fullName = pick(o, "name", "buyer_name", "recipient_name", "to_name")
    || pick(A, "name", "to_name", "recipient_name", "full_name")
    || pick(B, "name", "display_name", "full_name", "login_name");
  const sp = fullName.split(/\s+/);
  const order = {
    externalId: id,
    buyerFirst: sp.slice(0, -1).join(" ") || sp[0] || undefined,
    buyerLast: sp.length > 1 ? sp[sp.length - 1] : undefined,
    addr1: both("first_line", "address_first_line", "line1", "street1", "address_line_1", "address1") || undefined,
    // address2: CHỈ lấy key second-line CHUẨN của Etsy (bỏ line2/street2/address2 vì hay trúng field lạ = "1"/"4"…).
    // Lấy từ A; chỉ fallback root khi KHÔNG có object địa chỉ.
    addr2: (gA("second_line", "address_second_line", "address_line_2")
            || (hasA ? "" : gO("second_line", "address_second_line", "address_line_2"))) || undefined,
    city: both("city", "address_city") || undefined,
    // state: lấy từ A; nếu đã có A, fallback root CHỈ dùng key đã disambiguate (tránh o.state="active")
    state: (gA("state", "address_state", "region", "province")
            || (hasA ? gO("address_state", "region", "province") : gO("state", "address_state", "region", "province"))) || undefined,
    zip: both("zip", "address_zip", "postal_code", "zip_code") || undefined,
    country: both("country_name", "address_country_name", "country", "country_iso") || undefined,
    total: (function () {
      const cb = (P && P.cost_breakdown) || (o.payment && o.payment.cost_breakdown) || {};
      // Doanh thu đúng = "Order total" trên Etsy (subtotal + ship + tax, sau refund)
      // = cost_breakdown.adjusted_total_cost — ƯU TIÊN TUYỆT ĐỐI, field gốc chỉ là fallback.
      return money(cb.adjusted_total_cost ?? cb.total_cost ?? cb.buyer_cost
        ?? o.grandtotal ?? o.grand_total ?? o.formatted_grandtotal ?? o.total_price ?? o.total
        ?? P.grand_total ?? P.grandtotal ?? P.total ?? P.total_price) || undefined;
    })(),
    note: (pick(o, "message_from_buyer", "buyer_message", "note_from_buyer", "note", "gift_message")
      || pick(firstObj(o, "fulfillment", "shipment") || {}, "note_from_buyer", "buyer_note", "gift_message")) || undefined,
    platformStatus: detectStatus(o),
    items: extractItems(o),
  };
  if (!order.items.length) order.items = [{ title: "Etsy order " + id, qty: 1 }];
  // DEBUG địa chỉ: nếu addr2 vẫn ra rác, mở Console trang Orders xem dòng này để biết đúng field nguồn.
  try {
    if (order.addr2) console.log("[FusionPuller][addr2-debug]", order.externalId, "addr2=", order.addr2,
      "| A.second_line=", A && A.second_line, "| A.keys=", A ? Object.keys(A).join(",") : null,
      "| o.second_line=", o.second_line, "o.line2=", o.line2, "o.street2=", o.street2);
  } catch (_) {}
  // Dự phòng: nếu ảnh khách nằm ở cấp RECEIPT (không lồng trong transaction) → gắn vào item đầu.
  if (!order.items.some((it) => it.files && it.files.length)) {
    const rf = extractBuyerFiles(o);
    if (rf.length && order.items[0]) order.items[0].files = rf;
  }
  return order;
}
function nodeId(o) {
  const id = o && (o.receipt_id ?? o.receiptId ?? o.order_id ?? o.orderId);
  return (id != null && /^\d{6,15}$/.test(String(id))) ? String(id) : "";
}
function hasAddr(o) {
  return !!(o && (o.first_line || o.address_first_line || o.line1 || o.street1));
}
// Giữ bản DÀI hơn giữa 2 lần bắt — CHỈ dùng cho field cấp đơn (note…), KHÔNG dùng cho item nữa.
function richer(a, b) { return (S(b).length > S(a).length) ? b : (a || b); }
// ==== GỘP ITEM GIỮA 2 LẦN BẮT CỦA CÙNG 1 ĐƠN (list API cụt vs detail API đầy đủ) ====
// KHÔNG ghép mù theo vị trí + "dài hơn thì đè" nữa: Etsy có thể trả item theo THỨ TỰ KHÁC NHAU
// giữa 2 trang → ghép vị trí tráo tên 2 item cùng listing, "dài hơn" đè mất tên thật
// (đơn 4121474496: ATLAS bị biến thành ACHILLES). Luật mới, cùng chuẩn với server v86:
//  1) Khớp theo listingId + personalization TRÙNG trước, rồi mới rơi về vị trí.
//  2) Field chỉ được "nâng cấp an toàn": điền chỗ trống hoặc NỐI DÀI bản cắt cụt
//     ("ACHIL…" → "ACHILLES") — không bao giờ đổi thành giá trị khác hẳn.
function stem(v) { return String(v || "").trim().replace(/(\.\.\.|…)$/, "").toLowerCase(); }
function safeRicher(a, b) {
  const A = S(a), B = S(b);
  if (!A) return B || undefined;
  if (B && B.length > A.length && stem(A) !== "" && stem(B).indexOf(stem(A)) === 0) return B;
  return A;
}
function mergeItems(prevItems, newItems) {
  const pi = prevItems || [], ni = newItems || [];
  const lower = (v) => String(v || "").trim().toLowerCase();
  const usedP = new Set();
  const matchPrev = (b, bi) => {
    const free = pi.map((a, i) => ({ a, i })).filter((x) => !usedP.has(x.i));
    if (!free.length) return null;
    const sameL = b.listingId ? free.filter((x) => x.a.listingId && String(x.a.listingId) === String(b.listingId)) : [];
    let pool = sameL.length ? sameL : free;
    const pz = lower(b.personalization);
    if (pz) {
      const byPz = pool.filter((x) => lower(x.a.personalization) === pz);
      if (byPz.length === 1) return byPz[0];
      if (byPz.length > 1) pool = byPz;
    }
    return pool.find((x) => x.i === bi) || pool[0];
  };
  const out = [];
  for (let bi = 0; bi < ni.length; bi++) {
    const b = ni[bi] || {};
    const hit = matchPrev(b, bi);
    const a = hit ? hit.a : {};
    if (hit) usedP.add(hit.i);
    out.push({
      title: safeRicher(a.title, b.title) || b.title || a.title,
      qty: b.qty || a.qty,
      price: b.price || a.price,
      sku: b.sku || a.sku,
      listingId: b.listingId || a.listingId,
      variant: safeRicher(a.variant, b.variant),
      personalization: safeRicher(a.personalization, b.personalization),
      imageUrl: a.imageUrl || b.imageUrl,
      files: ((b.files || []).length >= (a.files || []).length ? b.files : a.files) || undefined,
    });
  }
  // Item chỉ có ở bản cũ (lần bắt mới thiếu) → GIỮ LẠI, không vứt item của khách
  for (let i = 0; i < pi.length; i++) if (!usedP.has(i)) out.push(pi[i]);
  return out;
}
function mergeInto(prev, o) {
  const out = Object.assign({}, prev);
  for (const k of ["buyerFirst","buyerLast","addr1","addr2","city","state","zip","country","platformStatus"]) if (!out[k] && o[k]) out[k] = o[k];
  out.note = richer(out.note, o.note); // note khách: lấy bản đầy đủ hơn (detail API có, list API thường thiếu)
  if ((!out.total || out.total === 0) && o.total) out.total = o.total;
  // Ghép item kể cả khi SỐ LƯỢNG item bằng nhau (trước đây chỉ thay khi nhiều hơn → giữ bản cụt).
  if ((o.items || []).length) out.items = mergeItems(out.items, o.items);
  return out;
}
// Nhận diện đơn ĐÃ SHIP/HUỶ trên Etsy — server sẽ chặn không tạo đơn mới (chống kéo nhầm tab Shipped)
function detectStatus(o) {
  // KHÔNG dùng field "state" — đó là BANG địa chỉ (LA/NY…), không phải trạng thái đơn.
  // Bug cũ: node địa chỉ mồ côi có state="LA" → platformStatus="LA" → bộ chặn theo trạng thái vô dụng.
  const st = pick(o, "order_status", "status", "order_state", "fulfillment_status", "shipping_status", "receipt_status");
  if (st && /ship|transit|deliver|complete|cancel|refund/i.test(st)) return st;
  if (o.was_shipped === true || o.is_shipped === true || o.shipped === true) return "shipped";
  const sh = o.shipments || o.shipment || o.fulfillments;
  if (Array.isArray(sh) && sh.length > 0) return "shipped";
  const tn = pick(o, "tracking_number", "tracking_code") || (sh && !Array.isArray(sh) && typeof sh === "object" ? pick(sh, "tracking_number", "tracking_code") : "");
  if (tn) return "shipped";
  return st || undefined;
}

// Nhận diện đơn ĐÃ HUỶ / HOÀN TIỀN TOÀN BỘ trên Etsy — KHÔNG kéo vào FUSION.
// (KHÔNG bắt refund MỘT PHẦN — đơn hoàn tiền một phần vẫn fulfill bình thường.)
function isCanceled(o) {
  if (!o || typeof o !== "object") return false;
  // KHÔNG dùng "state" (bang địa chỉ) trong nhận diện trạng thái.
  const st = pick(o, "order_status", "status", "order_state", "fulfillment_status", "shipping_status", "receipt_status", "payment_status");
  // 1) Huỷ rõ ràng
  if (st && /cancel/i.test(st)) return true;
  if (o.is_canceled === true || o.is_cancelled === true || o.canceled === true || o.cancelled === true) return true;
  const ca = o.cancelled_at ?? o.canceled_at ?? o.cancellation_date ?? o.date_cancelled ?? o.date_canceled;
  if (ca != null && ca !== 0 && ca !== "" && ca !== false) return true;
  // 2) HOÀN TIỀN TOÀN BỘ = huỷ (Etsy hiện "Fully refunded"): cờ, chữ, hoặc tiền hoàn ≥ tổng.
  if (st && /fully.?refund|full.?refund|refunded/i.test(st)) return true;
  if (o.is_refunded === true || o.fully_refunded === true || o.is_fully_refunded === true) return true;
  const refunded = money(o.refunded_amount ?? o.total_refunded ?? o.refund_total ?? o.amount_refunded ?? (o.refund && (o.refund.amount ?? o.refund.total)) ?? 0);
  const grand = money(o.grandtotal ?? o.grand_total ?? o.total ?? o.total_price ?? o.formatted_grandtotal ?? 0);
  if (refunded > 0 && grand > 0 && refunded >= grand - 0.01) return true;
  return false;
}

function harvest(data) {
  let added = 0;
  (function walk(node, depth, ctxId) {
    if (!node || depth > 10) return;
    if (Array.isArray(node)) { for (const x of node) walk(x, depth + 1, ctxId); return; }
    if (typeof node !== "object") return;
    const myId = nodeId(node) || ctxId;
    if (looksLikeReceipt(node)) {
      // BỎ QUA đơn đã HUỶ/HOÀN TIỀN — không kéo vào FUSION. Gỡ khỏi buffer + GHI NHỚ để node
      // địa chỉ mồ côi (cùng receipt) không "hồi sinh" đơn này (bug cũ: đơn huỷ vẫn lọt qua node địa chỉ).
      if (isCanceled(node)) {
        const cid = nodeId(node);
        if (cid) { DROPPED.add(cid); if (BUF.has(cid)) { BUF.delete(cid); added++; } }
        for (const k in node) walk(node[k], depth + 1, myId);
        return;
      }
      saveDebugPaths(node);
      const o = extractReceipt(node);
      // Ưu tiên ảnh khách đọc từ DOM (chắc chắn có URL đầy đủ) nếu JSON không có/ít hơn.
      const domFiles = FILES_BUF.get(o.externalId);
      if (domFiles && domFiles.length && o.items && o.items[0] && (o.items[0].files || []).length < domFiles.length) o.items[0].files = domFiles;
      const prev = BUF.get(o.externalId);
      if (!prev) { BUF.set(o.externalId, o); added++; }
      else { const m = mergeInto(prev, o); if (JSON.stringify(m) !== JSON.stringify(prev)) { BUF.set(o.externalId, m); added++; } }
    } else if (hasAddr(node) && myId) {
      if (DROPPED.has(myId)) { for (const k in node) walk(node[k], depth + 1, myId); return; } // đơn đã huỷ → KHÔNG hồi sinh
      // Node địa chỉ mồ côi (payload chi tiết đơn) → gắn vào đơn theo id kế thừa từ node cha
      saveDebugPaths(node);
      const a = extractReceipt(Object.assign({ receipt_id: myId }, node));
      a.items = [];
      const prev = BUF.get(myId);
      const m = prev ? mergeInto(prev, a) : a;
      if (!prev || JSON.stringify(m) !== JSON.stringify(prev)) { BUF.set(myId, m); added++; }
    }
    for (const k in node) walk(node[k], depth + 1, myId);
  })(data, 0, "");
  return added;
}

// ===== Debug: flatten key-paths của 1 receipt node thô (để chỉnh map khi Etsy đổi cấu trúc) =====
let debugSaved = 0; // 0=chưa, 1=đã lưu node thường, 2=đã lưu node có địa chỉ (ưu tiên)
function saveDebugPaths(node) {
  const withAddr = !!(node.first_line || node.address_first_line || node.line1 || node.street1 || node.shipping_address || node.to_address);
  if (debugSaved >= 2 || (debugSaved === 1 && !withAddr)) return;
  debugSaved = withAddr ? 2 : 1;
  try {
    const lines = [], seen = new Set();
    (function walk(n, path, d) {
      if (d > 6 || n == null || lines.length > 150) return;
      if (Array.isArray(n)) { if (n.length) walk(n[0], path + "[]", d + 1); return; }
      if (typeof n === "object") { for (const k in n) walk(n[k], path ? path + "." + k : k, d + 1); return; }
      if (seen.has(path)) return; seen.add(path);
      const KW = /(^|[._[])(order_id|receipt_id|id)($|[._[])|name|address|first_line|second_line|line1|line2|city|state|province|region|zip|postal|country|title|product|listing|price|amount|divisor|total|subtotal|quantity|qty|image|img|photo|thumb|url|personal|variation|variant|sku|buyer|recipient|ship|formatted|payment|grand|message|note|gift|status|state|shipment|shipped|tracking/i;
      if (!KW.test(path)) return;
      const val = (typeof n === "number" || typeof n === "boolean") ? n : "str";
      lines.push(path + " = " + val);
    })(node, "", 0);
    chrome.storage.local.set({ fp_lastpaths: "# ETSY RECEIPT FIELD MAP (send to dev)\n" + lines.join("\n") });
  } catch (_) {}
}

// ===== Badge: ưu tiên NEW (update) > số đơn buffer =====
async function updateBadge() {
  const { updateAvailable } = await chrome.storage.local.get("updateAvailable");
  if (updateAvailable) {
    chrome.action.setBadgeText({ text: "NEW" });
    chrome.action.setBadgeBackgroundColor({ color: "#D93025" });
    return;
  }
  const n = BUF.size;
  chrome.action.setBadgeText({ text: n > 0 ? String(n) : "" });
  chrome.action.setBadgeBackgroundColor({ color: "#0D4C9B" });
}

// ===== Message hub =====
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    await loadBuf();
    if (msg && msg.type === "shop-health") {
      sendResponse(await sendShopHealth(msg.data));
      return;
    }
    if (msg && msg.type === "etsy-data") {
      const n = harvest(msg.data);
      if (n > 0) { saveBuf(); broadcastCount(); }
      sendResponse({ ok: true, added: n, count: BUF.size });
      return;
    }
    // Ảnh khách upload đọc từ DOM (content.js) → gắn vào đơn đang có trong BUF theo order_id.
    if (msg && msg.type === "buyer-files") {
      const oid = String(msg.orderId || "");
      const files = Array.isArray(msg.files) ? msg.files : [];
      if (oid && files.length) {
        FILES_BUF.set(oid, files);
        const cur = BUF.get(oid);
        if (cur && Array.isArray(cur.items) && cur.items[0]) {
          const ex = (cur.items[0].files || []);
          if (files.length >= ex.length) { cur.items[0].files = files; BUF.set(oid, cur); saveBuf(); }
        }
      }
      sendResponse({ ok: true });
      return;
    }
    if (msg && msg.type === "count") { sendResponse({ count: BUF.size }); return; }
    if (msg && msg.type === "clear") { BUF.clear(); saveBuf(); broadcastCount(); sendResponse({ ok: true }); return; }
    if (msg && msg.type === "sync") {
      const { fp_cfg } = await chrome.storage.local.get("fp_cfg");
      const cfg = fp_cfg || {};
      if (!cfg.url || !cfg.token) { sendResponse({ ok: false, error: "Configure Ingest URL + Store token first (Configure)." }); return; }
      const orders = Array.from(BUF.values());
      if (!orders.length) { sendResponse({ ok: false, error: "No captured orders — scroll the Etsy Orders page first." }); return; }
      try {
        const r = await fetch(cfg.url, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: "Bearer " + cfg.token },
          body: JSON.stringify({ orders }),
        });
        const j = await r.json().catch(() => ({}));
        if (r.ok && j.ok) { BUF.clear(); saveBuf(); broadcastCount(); sendResponse({ ok: true, received: j.received, created: j.created, updated: j.updated || 0, skipped: j.skipped, errors: j.errors }); }
        else sendResponse({ ok: false, error: j.error || ("HTTP " + r.status) });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
      return;
    }
    // Repush 1 đơn (kèm ảnh khách quét từ DOM) — dùng khi đơn đã push từ danh sách, giờ mở chi tiết để bổ sung ảnh.
    // KHÔNG xoá BUF. Payload đủ nếu đơn còn trong BUF; nếu không, gửi tối thiểu {externalId, items:[{files}]} để Fusion merge ảnh vào đơn đã có.
    if (msg && msg.type === "repush-one") {
      const { fp_cfg } = await chrome.storage.local.get("fp_cfg");
      const cfg = fp_cfg || {};
      if (!cfg.url || !cfg.token) { sendResponse({ ok: false, error: "Configure URL/token first." }); return; }
      const oid = String(msg.orderId || "");
      const files = Array.isArray(msg.files) ? msg.files : [];
      if (!oid) { sendResponse({ ok: false, error: "no order id" }); return; }
      if (files.length) FILES_BUF.set(oid, files);
      let order = BUF.get(oid);
      if (order) {
        if (files.length && order.items && order.items[0]) order.items[0].files = files;
      } else {
        order = { externalId: oid, items: [{ files: files }] }; // merge-only vào đơn đã có trên Fusion
      }
      if (!files.length && (!order.items || !order.items.some((it) => it.files && it.files.length))) {
        sendResponse({ ok: false, error: "Chưa quét được ảnh — mở đúng trang chi tiết đơn (nơi ảnh hiện) rồi thử lại." }); return;
      }
      try {
        const r = await fetch(cfg.url, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: "Bearer " + cfg.token },
          body: JSON.stringify({ orders: [order] }),
        });
        const j = await r.json().catch(() => ({}));
        if (r.ok && j.ok) sendResponse({ ok: true, created: j.created, updated: j.updated || 0, skipped: j.skipped, photos: files.length });
        else sendResponse({ ok: false, error: j.error || ("HTTP " + r.status) });
      } catch (e) { sendResponse({ ok: false, error: String((e && e.message) || e) }); }
      return;
    }
    if (msg && msg.type === "status") {
      const { fp_cfg } = await chrome.storage.local.get("fp_cfg");
      const cfg = fp_cfg || {};
      if (!cfg.url || !cfg.token) { sendResponse({ ok: false }); return; }
      try {
        const statusUrl = new URL(cfg.url).origin + "/api/ingest/etsy/status";
        const payload = msg.mode === "pending" ? { mode: "pending" } : { externalIds: msg.ids || [] };
        const r = await fetch(statusUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: "Bearer " + cfg.token },
          body: JSON.stringify(payload),
        });
        sendResponse(await r.json().catch(() => ({ ok: false })));
      } catch (_) { sendResponse({ ok: false }); }
      return;
    }
    sendResponse({ ok: false, error: "unknown message" });
  })();
  return true; // async
});

// ===== Check bản mới từ FUSION (badge NEW — Chrome cấm load-unpacked tự update ngầm) =====
function cmpVer(a, b) {
  const pa = String(a).split(".").map(Number), pb = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) { const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d > 0 ? 1 : -1; }
  return 0;
}
async function checkUpdate() {
  try {
    const r = await fetch(UPDATE_BASE + "/api/extension/version?t=" + Date.now(), { cache: "no-store" });
    if (!r.ok) return;
    const j = await r.json();
    const cur = chrome.runtime.getManifest().version;
    if (j.version && cmpVer(j.version, cur) > 0) {
      await chrome.storage.local.set({ updateAvailable: j.version });
      chrome.action.setTitle({ title: "Fusion Etsy Puller — new version " + j.version + " available (open popup to download)" });
    } else {
      await chrome.storage.local.remove("updateAvailable");
      chrome.action.setTitle({ title: "Fusion Etsy Puller" });
    }
    updateBadge();
  } catch (_) { /* offline thì thôi */ }
}

// ===== Shop health =====
// KHÔNG fetch trang Etsy nào cả. Mọi request tự động (kể cả tới shop của chính mình) đều để lại
// dấu vết bất thường: header của fetch() khác người thật (thiếu Sec-Fetch-Dest: document...).
// Với một tính năng chỉ để hiển thị cho đẹp, đánh đổi đó không đáng.
//
// Thay vào đó: content.js ĐỌC DOM của trang Shop Manager dashboard mà seller VỐN ĐÃ tự mở
// (etsy.com/your/shops/me/dashboard) rồi gửi số liệu về. Zero request thêm, zero rủi ro.
// Background chỉ làm trung chuyển để giấu token khỏi trang web.

async function sendShopHealth(data) {
  try {
    const { fp_cfg } = await chrome.storage.local.get("fp_cfg");
    const cfg = fp_cfg || {};
    if (!cfg.url || !cfg.token) return { ok: false };

    // 1 lần / 20 giờ là đủ — số sale không đổi theo giờ
    const { fp_shop_at } = await chrome.storage.local.get("fp_shop_at");
    if (fp_shop_at && Date.now() - fp_shop_at < 20 * 3600 * 1000) return { ok: true, skipped: true };

    let api;
    try { api = new URL(cfg.url).origin + "/api/ingest/etsy/shop"; } catch (_) { return { ok: false }; }

    const r = await fetch(api, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + cfg.token },
      body: JSON.stringify(data),
    });
    if (r.ok) await chrome.storage.local.set({ fp_shop_at: Date.now() });
    return { ok: r.ok };
  } catch (_) { return { ok: false }; }
}

// KEEPALIVE: service worker MV3 hay rơi vào trạng thái "chết ngủ" sau khi máy sleep/Chrome chạy lâu
// (triệu chứng: bấm Push chỉ thấy "Pushing…" mãi, phải vào chrome://extensions bấm Update/reload).
// Alarm mỗi phút đánh thức worker dậy làm việc nhẹ → worker luôn trong trạng thái gọi được.
function ensureAlarms() {
  try {
    chrome.alarms.get("fusion-update-check", (a) => { if (!a) chrome.alarms.create("fusion-update-check", { periodInMinutes: 360 }); });
    chrome.alarms.get("fusion-keepalive", (a) => { if (!a) chrome.alarms.create("fusion-keepalive", { periodInMinutes: 1 }); });
  } catch (_) {}
}
chrome.runtime.onInstalled.addListener(() => { ensureAlarms(); checkUpdate(); loadBuf().then(updateBadge); });
chrome.runtime.onStartup.addListener(() => { ensureAlarms(); checkUpdate(); loadBuf().then(updateBadge); });
ensureAlarms(); // worker restart giữa chừng (không qua onInstalled/onStartup) cũng phải có alarm
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === "fusion-update-check") checkUpdate();
  if (a.name === "fusion-keepalive") loadBuf().then(updateBadge); // việc nhẹ — chỉ để giữ worker tỉnh
});
