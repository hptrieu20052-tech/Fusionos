/*
 * content.js — inject hook + a full FLOATING CONTROL PANEL on the page (no need to click the extension icon).
 * Runs at document_start.
 */
(function () {
  var DEFAULT_INGEST = "https://os.fusiondn.com/api/ingest/etsy";
  var LAST_PHOTOS = { orderId: "", files: [] }; // ảnh khách quét được ở trang chi tiết hiện tại (cho nút Push Images)
  // 1) Inject injected.js early
  try {
    const s = document.createElement("script");
    s.src = chrome.runtime.getURL("injected.js");
    s.onload = () => s.remove();
    (document.head || document.documentElement).appendChild(s);
  } catch (e) { console.error("[FusionPuller] inject fail", e); }

  // 2) Receive data from the page → background
  window.addEventListener("message", (ev) => {
    const d = ev.data;
    if (d && d.__fusion_etsy__ === true) chrome.runtime.sendMessage({ type: "etsy-data", url: d.url, data: d.data });
  });

  // 3) Scan embedded JSON (fallback)
  function scanEmbedded() {
    let hit = 0;
    try {
      for (const sc of document.querySelectorAll("script")) {
        const txt = sc.textContent || "";
        if (txt.length < 40 || txt.length > 8000000) continue;
        if (!/receipt_id|receiptId|order_id|orderId|transactions|grandtotal|first_line|country_name/i.test(txt)) continue;
        const t = txt.trim();
        const tryParse = (str) => { try { chrome.runtime.sendMessage({ type: "etsy-data", url: "embedded", data: JSON.parse(str) }); hit++; return true; } catch (_) { return false; } };
        if ((t[0] === "{" || t[0] === "[") && tryParse(t)) continue;
        const m = t.match(/=\s*(\{[\s\S]*\})\s*;?\s*$/);
        if (m) tryParse(m[1]);
      }
    } catch (_) {}
    return hit;
  }


  // List compact "field paths" from a sample object (collapsing array items) → easy to share with a dev.
  function keyPaths(obj) {
    const lines = [], seen = new Set();
    (function walk(node, path, depth) {
      if (depth > 6 || node == null) return;
      if (Array.isArray(node)) { if (node.length) walk(node[0], path + "[]", depth + 1); return; }
      if (typeof node === "object") { for (const k in node) walk(node[k], path ? path + "." + k : k, depth + 1); return; }
      const val = (typeof node === "number") ? node : (typeof node === "boolean" ? node : "«str»");
      if (seen.has(path)) return; seen.add(path);
      lines.push(path + " = " + val);
    })(obj, "", 0);
    const KW = /(^|[._[])(order_id|receipt_id|id)($|[._[])|name|address|first_line|second_line|line1|line2|city|state|province|region|zip|postal|country|title|product|listing|price|amount|divisor|total|subtotal|quantity|qty|image|img|photo|thumb|url|personal|variation|variant|sku|buyer|recipient|ship|formatted/i;
    const keep = lines.filter((l) => KW.test(l.split(" = ")[0]));
    return "# RELEVANT FIELDS ONLY (Etsy order-management)\n" + keep.slice(0, 90).join("\n");
  }

  if (window.top !== window) return; // only build UI on the top frame

  // 4) Floating control panel
  const S = document.createElement("style");
  S.textContent = `
    #fp-panel{position:fixed;z-index:2147483647;right:18px;bottom:18px;width:300px;background:#fff;border-radius:14px;
      box-shadow:0 14px 40px rgba(6,20,50,.35);font:13px/1.45 system-ui,-apple-system,sans-serif;color:#1e2a3a;overflow:hidden}
    #fp-hd{background:linear-gradient(135deg,#0095e8,#003c84);color:#fff;padding:9px 12px;display:flex;align-items:center;gap:8px;cursor:move;user-select:none}
    #fp-hd b{font-size:13.5px;flex:1}
    #fp-hd .fp-btn{background:rgba(255,255,255,.2);border:0;color:#fff;width:24px;height:24px;border-radius:7px;cursor:pointer;font-size:14px;line-height:1}
    #fp-bd{padding:12px;max-height:calc(100vh - 90px);overflow-y:auto}
    #fp-cnt{font-weight:800;color:#15803d;margin-bottom:10px;font-size:14px}
    #fp-panel button.act{width:100%;border:0;border-radius:10px;padding:11px;font-weight:800;font-size:13.5px;cursor:pointer;color:#fff;margin-top:8px}
    .fp-sync{background:linear-gradient(135deg,#22c55e,#15803d)}
    .fp-cfgtoggle{background:none;border:0;color:#0095e8;font-weight:700;cursor:pointer;font-size:12.5px;margin-top:10px;padding:0}
    #fp-cfg{display:block;margin-top:10px;border-top:1px solid #eef1f4;padding-top:10px}
    #fp-cfg label{display:block;font-weight:700;font-size:11px;color:#33445a;margin:8px 0 3px}
    #fp-cfg input{width:100%;box-sizing:border-box;padding:8px 9px;border:1px solid #dbe1e8;border-radius:8px;font:inherit;font-size:12px}
    #fp-cfg .r{display:flex;gap:6px;margin-top:8px}
    #fp-cfg .r button{flex:1;border:0;border-radius:8px;padding:8px;font-weight:700;font-size:12px;cursor:pointer}
    .fp-save{background:#003c84;color:#fff}.fp-copy{background:#eef1f4;color:#33445a}
    #fp-msg{display:none;margin-top:9px;font-size:12px;padding:7px 9px;border-radius:8px}
    .fp-badge{display:inline-block;margin-left:8px;padding:2px 8px;border-radius:999px;font:700 11px system-ui;vertical-align:middle}
    .fp-badge.copy{cursor:pointer}
    #fp-track{margin-top:10px}
    #fp-track .h{font-weight:800;font-size:12px;color:#33445a;margin-bottom:4px}
    #fp-track .rows{max-height:230px;overflow-y:auto;padding-right:2px}
    #fp-track .row{display:flex;align-items:center;gap:6px;padding:5px 0;border-top:1px solid #eef1f4;font-size:11.5px}
    #fp-track .row .id{font-weight:700;color:#0f1e33}
    #fp-track .row .tk{flex:1;color:#5a6272;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
    #fp-track .row button{border:0;border-radius:7px;padding:4px 8px;font-weight:700;font-size:11px;cursor:pointer;background:#eef1f4;color:#33445a}
    .fp-inline{margin:8px 0;padding:8px 11px;border-radius:9px;background:#E7F6EC;border:1px solid #b7e3c4;color:#15803d;font:600 12.5px/1.45 system-ui;display:flex;align-items:center;gap:7px;flex-wrap:wrap;max-width:560px;box-shadow:0 2px 8px rgba(21,128,61,.12)}
    .fp-inline .nm{color:#0f1e33;font-weight:800}
    .fp-inline .ca{text-transform:uppercase;font-weight:800;color:#2f7d72}
    .fp-inline .tk{font-family:ui-monospace,Menlo,monospace;background:#fff;padding:1px 7px;border-radius:6px;color:#0f1e33;font-weight:700}
    .fp-inline button{border:0;border-radius:7px;padding:3px 10px;font-weight:800;font-size:11px;cursor:pointer;background:#15803d;color:#fff;margin-left:auto}
    .fp-chip{display:inline-flex;align-items:center;gap:8px;margin-left:10px;vertical-align:middle;padding:4px 10px;border-radius:8px;background:#0f3d7a;color:#fff;font:700 12.5px/1.2 system-ui;cursor:pointer;box-shadow:0 2px 8px rgba(15,61,122,.28)}
    .fp-chip:hover{background:#0c3468}
    .fp-chip .fp-chip-l{opacity:.8;font-weight:800;font-size:10.5px;text-transform:uppercase;letter-spacing:.4px}
    .fp-chip .fp-chip-v{font-family:ui-monospace,Menlo,monospace;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
    .fp-chip .fp-chip-c{background:rgba(255,255,255,.22);border-radius:6px;padding:2px 8px;font-size:11px;font-weight:800;flex:none}
    #fp-actions{display:flex;gap:6px;margin-top:8px}
    .fp-mini{flex:1;border:0;border-radius:9px;padding:9px;font-weight:800;font-size:12.5px;cursor:pointer;background:#eef1f4;color:#33445a}
    .fp-mini.danger{background:#FDECEC;color:#D14343}
    #fp-pill{position:fixed;z-index:2147483647;right:18px;bottom:18px;background:#003c84;color:#fff;border-radius:999px;
      padding:9px 14px;font:800 13px system-ui;box-shadow:0 8px 24px rgba(0,0,0,.3);cursor:pointer;display:none;align-items:center;gap:8px}
  `;
  document.documentElement.appendChild(S);

  const _svg = (inner, sz) => '<svg width="' + (sz||13) + '" height="' + (sz||13) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:5px">' + inner + '</svg>';
  const IC_PUSH = _svg('<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>');
  const IC_GEAR = _svg('<circle cx="12" cy="12" r="2.6"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-2.7 1.1V21a2 2 0 0 1-4 0v-.1A1.6 1.6 0 0 0 7 19.4a1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0-1.1-2.7H1a2 2 0 0 1 0-4h.1A1.6 1.6 0 0 0 2.6 7a1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.6 1.6 0 0 0 7 2.6h.1A1.6 1.6 0 0 0 8.6 1V.9a2 2 0 0 1 4 0V1a1.6 1.6 0 0 0 2.7 1.1 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0 1.1 2.7H21a2 2 0 0 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>');

  const P = document.createElement("div");
  P.id = "fp-panel";
  P.innerHTML =
    '<div id="fp-hd"><img src="' + chrome.runtime.getURL("icon32.png") + '" width="18" height="18" style="border-radius:5px"><b>Fusion Etsy Puller</b><button class="fp-btn" id="fp-min" title="Minimize">–</button></div>' +
    '<div id="fp-bd">' +
    '<div id="fp-cnt">Captured: 0 orders</div>' +
    '<div id="fp-photos" style="font-size:12px;color:#2563eb;font-weight:700;margin-bottom:8px"></div>' +
    '<button class="act" id="fp-repush" style="display:none;background:#0e8a5f;margin-bottom:8px">📷 Push Images</button>' +
    '<button class="act fp-sync" id="fp-sync"' + IC_PUSH + 'Push to FUSION</button>' +
    '<div id="fp-actions"><button class="fp-mini" id="fp-recap">Recapture</button><button class="fp-mini" id="fp-status">Load Status</button><button class="fp-mini danger" id="fp-clear">Clear</button></div>' +
    '<div id="fp-cfg">' +
      '<label>Ingest URL</label><input id="fp-url" name="fp-url-nofill" autocomplete="off" data-lpignore="true" data-1p-ignore data-form-type="other" readonly placeholder="https://os.fusiondn.com/api/ingest/etsy">' +
      '<label>Store token</label><input id="fp-token" type="password" name="fp-token-nofill" autocomplete="new-password" data-lpignore="true" data-1p-ignore data-form-type="other" readonly placeholder="Etsy store token from FUSION">' +
      '<div class="r"><button class="fp-save" id="fp-save">Save config</button></div>' +
    '</div>' +
    '<div id="fp-msg"></div>' +
    '</div>';
  const PILL = document.createElement("div");
  PILL.id = "fp-pill";
  PILL.innerHTML = '<img src="' + chrome.runtime.getURL("icon32.png") + '" width="16" height="16"><span id="fp-pillcnt">0</span> orders';

  const mount = () => { if (document.body) { document.body.appendChild(P); document.body.appendChild(PILL); init(); } else setTimeout(mount, 200); };
  mount();

  function msg(t, ok) { const m = P.querySelector("#fp-msg"); m.style.display = "block"; m.textContent = t; m.style.background = ok ? "#E7F6EC" : "#FDECEC"; m.style.color = ok ? "#15803d" : "#D14343"; }

  // ==== safeSend: sendMessage KHÔNG BAO GIỜ treo vô hạn ====
  // 3 kiểu chết trước đây làm nút Push kẹt "Pushing…" mãi:
  //  - "Extension context invalidated": extension vừa reload/update mà trang chưa F5 → sendMessage NÉM lỗi, callback không bao giờ chạy
  //  - Service worker "chết ngủ" (hay gặp sau khi máy sleep qua đêm): không phản hồi, không lỗi
  //  - Worker chết giữa chừng: callback nhận undefined
  // → gói lại: bắt lỗi + timeout + phân loại, hiện hướng xử lý rõ ràng thay vì treo.
  function safeSend(payload, cb, timeoutMs) {
    var done = false;
    var finish = function (r) { if (done) return; done = true; try { cb && cb(r); } catch (_) {} };
    if (!(chrome.runtime && chrome.runtime.id)) return finish({ ok: false, error: "__ctx__" });
    var t = setTimeout(function () { finish({ ok: false, error: "__timeout__" }); }, timeoutMs || 12000);
    try {
      chrome.runtime.sendMessage(payload, function (r) {
        clearTimeout(t);
        if (chrome.runtime.lastError) { /* đọc lastError để Chrome khỏi log warning */ }
        finish(r || { ok: false, error: "__dead__" });
      });
    } catch (_) { clearTimeout(t); finish({ ok: false, error: "__ctx__" }); }
  }
  var ERR_CTX = "Extension was just updated — RELOAD THIS PAGE (F5), then click again.";
  var ERR_DEAD = "Extension is asleep — click the Fusion icon in the Chrome toolbar → \"Restart extension\" (or reload this page), then click again.";
  function friendlyErr(e) { return e === "__ctx__" ? ERR_CTX : (e === "__timeout__" || e === "__dead__") ? ERR_DEAD : "✗ " + e; }

  function refresh() {
    try { chrome.runtime.sendMessage({ type: "count" }, (r) => { if (!r) return; const n = r.count; const c = P.querySelector("#fp-cnt"); if (c) c.textContent = `Captured: ${n} orders`; const pc = PILL.querySelector("#fp-pillcnt"); if (pc) pc.textContent = n; }); } catch (_) {}
  }

  // ==== Overlay trạng thái + tracking từ FUSION lên trang Etsy ====
  var STATUS = {};   // theo id quét được trên trang (badge trạng thái)
  var PENDING = {};  // MỌI đơn đang chờ gán tracking (kèm tên/địa chỉ/tổng tiền) — để nhận diện đơn ở trang add-tracking
  var ORDERMAP = {}; // #ID -> {total,city,state,at} quét từ TRANG DANH SÁCH Orders (nơi Etsy HIỆN #ID) → suy ID cho trang add-tracking
  var LASTCLICK = null; // {id,at}: đơn bạn VỪA CLICK trên danh sách → mang sang trang add-tracking (chính xác nhất)
  var AUTOFILL = true;
  function rec(id) { return PENDING[id] || STATUS[id] || null; }
  function esc(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }

  // Đặt value theo kiểu React nhận diện được (native setter + dispatch event)
  function setNativeValue(el, value) {
    try {
      var proto = el.tagName === "SELECT" ? HTMLSelectElement.prototype : (el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype);
      var setter = Object.getOwnPropertyDescriptor(proto, "value").set;
      setter.call(el, value);
    } catch (_) { el.value = value; }
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function carrierKey(s) {
    s = (s || "").toLowerCase();
    if (/usps|united states postal/.test(s)) return "usps";
    if (/fedex/.test(s)) return "fedex";
    if (/\bups\b/.test(s)) return "ups";
    if (/dhl/.test(s)) return "dhl";
    if (/royal.?mail/.test(s)) return "royal";
    if (/canada.?post/.test(s)) return "canada";
    if (/australia|auspost/.test(s)) return "australia";
    if (/yun.?express|yunexpress/.test(s)) return "yun";
    if (/4px/.test(s)) return "4px";
    if (/china.?post/.test(s)) return "china";
    return "";
  }
  function carrierIsCarrierSelect(sel) {
    var opts = sel.options, cnt = 0;
    for (var j = 0; j < opts.length; j++) if (carrierKey(opts[j].textContent)) cnt++;
    return cnt >= 2;
  }
  function elDist(a, b) {
    try { var ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect(); return Math.abs(ra.top - rb.top) + Math.abs(ra.left - rb.left); } catch (_) { return 1e9; }
  }
  function fillCarrier(near, carrier) {
    var key = carrierKey(carrier); if (!key) return false;
    // 1) Native <select> giống carrier (Etsy Wt-Select thường là select thật) — quét toàn trang, ưu tiên gần ô tracking
    var all = document.querySelectorAll("select"), cands = [];
    for (var i = 0; i < all.length; i++) if (carrierIsCarrierSelect(all[i])) cands.push(all[i]);
    cands.sort(function (a, b) { return elDist(a, near) - elDist(b, near); });
    for (var c = 0; c < cands.length; c++) {
      var sel = cands[c], opts = sel.options;
      for (var j = 0; j < opts.length; j++) {
        if (carrierKey(opts[j].textContent) === key) { setNativeValue(sel, opts[j].value); return true; }
      }
    }
    // 2) Dropdown tùy biến: tìm control gần label "carrier", click mở rồi chọn option khớp
    var combo = findCarrierCombo(near);
    if (combo) { openAndPickCarrier(combo, key); return true; }
    return false;
  }
  function findCarrierCombo(near) {
    // tìm phần tử text "Shipping carrier" rồi lấy control clickable gần nhất trong cùng cụm
    var nodes = document.querySelectorAll("label,span,div,legend,p");
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i]; if (el.children.length) continue;
      var tx = (el.textContent || "").trim().toLowerCase();
      if (tx.indexOf("shipping carrier") === 0 || tx === "carrier") {
        var box = el;
        for (var up = 0; up < 6 && box; up++) {
          var ctrl = box.querySelector('[role="combobox"],[role="listbox"],[aria-haspopup],button,[role="button"],input[readonly]');
          if (ctrl && ctrl.tagName !== "SELECT") return ctrl;
          box = box.parentElement;
        }
      }
    }
    return null;
  }
  function openAndPickCarrier(combo, key) {
    try { combo.click(); combo.dispatchEvent(new MouseEvent("mousedown", { bubbles: true })); } catch (_) {}
    var tries = 0;
    var iv = setInterval(function () {
      tries++;
      var opts = document.querySelectorAll('[role="option"],[role="menuitem"],li,[data-value]');
      for (var i = 0; i < opts.length; i++) {
        var o = opts[i];
        var tx = (o.textContent || "").trim();
        if (tx && tx.length < 30 && carrierKey(tx) === key) {
          try { o.click(); o.dispatchEvent(new MouseEvent("mousedown", { bubbles: true })); o.dispatchEvent(new MouseEvent("mouseup", { bubbles: true })); } catch (_) {}
          clearInterval(iv); return;
        }
      }
      if (tries > 12) clearInterval(iv);
    }, 120);
  }
  // Lấy TEXT cụm chứa đơn quanh ô tracking (tên khách + "City, ST" + "$giá").
  function pageBlockText(el) {
    var node = el, best = "";
    for (var i = 0; i < 9 && node; i++) {
      node = node.parentElement; if (!node) break;
      var t = "";
      try { t = (node.innerText || node.textContent || "").replace(/\s+/g, " ").trim(); } catch (_) {}
      if (t.length >= 12 && t.length <= 1600) { best = t; if (/,\s*[A-Za-z]{2,}\b/.test(t) && /\$\s?\d/.test(t)) break; }
    }
    return best;
  }
  function scorePending(txt, o) {
    if (!txt) return 0;
    var low = txt.toLowerCase(), noSp = txt.replace(/\s/g, ""), s = 0;
    var fn = (o.buyerFirst || "").toLowerCase().trim(), ln = (o.buyerLast || "").toLowerCase().trim();
    if (fn && ln && low.indexOf(fn) >= 0 && low.indexOf(ln) >= 0) s += 4;
    else { if (ln && ln.length > 2 && low.indexOf(ln) >= 0) s += 2; if (fn && fn.length > 2 && low.indexOf(fn) >= 0) s += 1; }
    if (o.city && o.city.length > 1 && low.indexOf(o.city.toLowerCase()) >= 0) s += 2;
    if (o.state) { try { if (new RegExp(",\\s*" + esc(o.state) + "\\b", "i").test(txt)) s += 2; else if (low.indexOf(o.state.toLowerCase()) >= 0) s += 1; } catch (_) {} }
    if (o.zip && String(o.zip).length >= 4 && txt.indexOf(String(o.zip)) >= 0) s += 2;
    if (o.total) { var tp = "$" + Number(o.total).toFixed(2); if (noSp.indexOf(tp) >= 0) s += 2; }
    return s;
  }
  function matchPendingForInput(inp) {
    var ids = Object.keys(PENDING); if (!ids.length) return null;
    var txt = pageBlockText(inp);
    var best = null, bestS = 0, second = 0;
    for (var i = 0; i < ids.length; i++) {
      var sc = scorePending(txt, PENDING[ids[i]]);
      if (sc > bestS) { second = bestS; bestS = sc; best = ids[i]; }
      else if (sc > second) second = sc;
    }
    return (best && bestS >= 4 && bestS - second >= 2) ? best : null;
  }
  // Bóc "$giá" + "City, ST" từ 1 khối text.
  function pageInfo(txt) {
    var out = { total: "", city: "", state: "" };
    var mt = txt.match(/\$\s?(\d[\d,]*\.\d{2})/); if (mt) out.total = mt[1].replace(/,/g, "");
    var mc = txt.match(/([A-Za-z .'\-]{2,}),\s*([A-Za-z]{2})\b/); if (mc) { out.city = mc[1].trim(); out.state = mc[2]; }
    return out;
  }
  // Khớp trang add-tracking với bản đồ #ID quét từ trang danh sách (giá + bang + thành phố), DUY NHẤT mới nhận.
  function matchOrderMap(inp) {
    var ids = Object.keys(ORDERMAP); if (!ids.length) return null;
    var info = pageInfo(pageBlockText(inp));
    if (!info.total && !info.city) return null;
    var best = null, bestS = 0, second = 0;
    for (var i = 0; i < ids.length; i++) {
      var e = ORDERMAP[ids[i]], sc = 0;
      if (info.total && e.total && info.total === e.total) sc += 3;
      if (info.state && e.state && info.state.toLowerCase() === e.state.toLowerCase()) sc += 2;
      if (info.city && e.city && info.city.toLowerCase() === e.city.toLowerCase()) sc += 2;
      if (sc > bestS) { second = bestS; bestS = sc; best = ids[i]; } else if (sc > second) second = sc;
    }
    if (best && bestS >= 5 && bestS - second >= 2) { var r = rec(best); if (r && r.hasTracking) return best; }
    return null;
  }
  // Đơn VỪA được click trên danh sách (mang qua trang add-tracking). Chỉ nhận nếu còn mới & không xung đột giá/bang.
  function matchLastClick(inp) {
    if (!LASTCLICK || !LASTCLICK.id) return null;
    if (Date.now() - (LASTCLICK.at || 0) > 300000) return null;
    var id = LASTCLICK.id, r = rec(id); if (!r || !r.hasTracking) return null;
    var info = pageInfo(pageBlockText(inp)), e = ORDERMAP[id];
    if (info.total && e && e.total && info.total !== e.total) return null;
    if (info.state && e && e.state && info.state.toLowerCase() !== e.state.toLowerCase()) return null;
    return id;
  }
  function resolveOrderId(inp) {
    var byId = orderIdNear(inp); if (byId) return byId;
    var byClick = matchLastClick(inp); if (byClick) return byClick;
    var byMap = matchOrderMap(inp); if (byMap) return byMap;
    var byMatch = matchPendingForInput(inp); if (byMatch) return byMatch;
    var pend = Object.keys(PENDING); if (pend.length === 1) return pend[0];
    return null;
  }
  // Cac document co the truy cap: top + iframe CUNG ORIGIN (form Complete order co the nam trong iframe).
  function accessibleDocs() {
    var docs = [document];
    try { var ifr = document.querySelectorAll("iframe"); for (var i = 0; i < ifr.length; i++) { try { var d = ifr[i].contentDocument; if (d && d.querySelectorAll) docs.push(d); } catch (_) {} } } catch (_) {}
    return docs;
  }
  // === DEEP DOM: xuyen qua Shadow DOM + iframe cung origin (Etsy Complete order dung web-component) ===
  function deepRoots() {
    var roots = [], seen = [];
    function add(r) {
      if (!r || seen.indexOf(r) >= 0) return; seen.push(r); roots.push(r);
      var els; try { els = r.querySelectorAll ? r.querySelectorAll("*") : []; } catch (_) { els = []; }
      for (var i = 0; i < els.length; i++) { var e = els[i]; try { if (e.shadowRoot) add(e.shadowRoot); } catch (_) {} if (e.tagName === "IFRAME") { try { var d = e.contentDocument; if (d) add(d); } catch (_) {} } }
    }
    add(document); return roots;
  }
  function parentDeep(node) { if (!node) return null; if (node.assignedSlot) return node.assignedSlot; var p = node.parentNode; if (p && p.nodeType === 11 && p.host) return p.host; return p; }
  function blockTextDeep(el) {
    var node = el, best = "";
    for (var i = 0; i < 14 && node; i++) { var t = ""; try { t = (node.innerText || node.textContent || "").replace(/\s+/g, " ").trim(); } catch (_) {} if (t.length >= 12 && t.length <= 1800) { best = t; if (/,\s*[A-Za-z]{2,}\b/.test(t) && /\$\s?\d/.test(t)) break; } node = parentDeep(node); }
    return best;
  }
  function resolveByText(txt) {
    var ids = Object.keys(PENDING); if (!ids.length || !txt) return null;
    var best = null, bestS = 0, second = 0;
    for (var i = 0; i < ids.length; i++) { var sc = scorePending(txt, PENDING[ids[i]]); if (sc > bestS) { second = bestS; bestS = sc; best = ids[i]; } else if (sc > second) second = sc; }
    return (best && bestS >= 4 && bestS - second >= 2) ? best : null;
  }
  // Tim nhan khop text tren MOI root (light + shadow + iframe). Giu phan tu nho nhat.
  function findLabelsDeep(targets) {
    var roots = deepRoots(), res = [];
    for (var d = 0; d < roots.length; d++) {
      var all; try { all = roots[d].querySelectorAll("*"); } catch (_) { continue; }
      for (var i = 0; i < all.length; i++) {
        var el = all[i]; if (el.children && el.children.length > 2) continue;
        var raw = ""; try { raw = (el.textContent || "").trim(); } catch (_) {} if (!raw || raw.length > 40) continue;
        var tx = raw.toLowerCase().replace(/\s*\*\s*$/, "").replace(/\s+/g, " ");
        for (var k = 0; k < targets.length; k++) { if (tx === targets[k] || tx.indexOf(targets[k]) >= 0) { res.push(el); break; } }
      }
    }
    return res.filter(function (el) { return !res.some(function (o) { return o !== el && el.contains && el.contains(o); }); });
  }
  // Chen gia tri + Copy NGAY SAU nhan (style NOI TUYEN vi Shadow DOM khong nhan CSS ngoai).
  function injectBeside(labelEl, kind, value) {
    if (!labelEl || !value || !labelEl.parentNode) return;
    var host = labelEl.parentNode;
    var ex = host.querySelector ? host.querySelector('[data-fp-chip="' + kind + '"]') : null;
    if (ex) { if (ex.getAttribute("data-fp-val") === String(value)) return; ex.remove(); }
    var doc = labelEl.ownerDocument || document;
    var c = doc.createElement("span");
    c.setAttribute("data-fp-chip", kind); c.setAttribute("data-fp-val", String(value));
    c.style.cssText = "display:inline-flex;align-items:center;margin-left:8px;vertical-align:middle;padding:2px 10px;border-radius:7px;background:#0f3d7a;color:#fff;font:700 11.5px/1.5 ui-monospace,Menlo,Consolas,monospace;letter-spacing:.2px;cursor:pointer;box-shadow:0 1px 5px rgba(15,61,122,.3);transition:background .15s";
    c.textContent = value; c.title = "Click to copy";
    c.onmouseenter = function () { if (c.getAttribute("data-copied") !== "1") c.style.background = "#0c3468"; };
    c.onmouseleave = function () { if (c.getAttribute("data-copied") !== "1") c.style.background = "#0f3d7a"; };
    c.onclick = function (e) { if (e) { try { e.preventDefault(); e.stopPropagation(); } catch (_) {} } try { navigator.clipboard.writeText(value); } catch (_) {} c.setAttribute("data-copied", "1"); c.textContent = "\u2713 Copied"; c.style.background = "#15803d"; setTimeout(function () { c.textContent = value; c.style.background = "#0f3d7a"; c.removeAttribute("data-copied"); }, 1000); };
    if (labelEl.nextSibling) host.insertBefore(c, labelEl.nextSibling); else host.appendChild(c);
  }
  var CHIP_CSS = ".fp-chip{display:inline-flex;align-items:center;gap:8px;margin-left:10px;vertical-align:middle;padding:4px 10px;border-radius:8px;background:#0f3d7a;color:#fff;font:700 12.5px/1.2 system-ui;cursor:pointer;box-shadow:0 2px 8px rgba(15,61,122,.28)}.fp-chip .fp-chip-v{font-family:ui-monospace,Menlo,monospace;font-weight:700}.fp-chip .fp-chip-c{background:rgba(255,255,255,.22);border-radius:6px;padding:2px 8px;font-size:11px;font-weight:800}";
  function ensureChipStyle(doc) { try { if (doc && !doc.getElementById("fp-chip-style")) { var st = doc.createElement("style"); st.id = "fp-chip-style"; st.textContent = CHIP_CSS; (doc.head || doc.documentElement).appendChild(st); } } catch (_) {} }
  // Nut hien gia tri + BAM DE COPY.
  function copyChip(value, kind, doc) {
    doc = doc || document;
    var c = doc.createElement("div");
    c.className = "fp-chip"; c.setAttribute("data-fp-chip", kind); c.title = "Click to copy";
    c.innerHTML = '<span class="fp-chip-v">' + value + '</span><span class="fp-chip-c">Copy</span>';
    c.onclick = function (e) { if (e) { try { e.preventDefault(); e.stopPropagation(); } catch (_) {} } try { navigator.clipboard.writeText(value); } catch (_) {} var cc = c.querySelector(".fp-chip-c"); if (cc) { cc.textContent = "Copied \u2713"; setTimeout(function () { cc.textContent = "Copy"; }, 1200); } };
    return c;
  }
  function placeChipAbove(fieldEl, kind, value, labelTxt) {
    if (!fieldEl || !value) return;
    var box = (fieldEl.closest && fieldEl.closest("div")) || fieldEl.parentElement || fieldEl;
    var parent = box.parentElement || box;
    var old = parent.querySelector('.fp-chip[data-fp-chip="' + kind + '"]'); if (old) old.remove();
    parent.insertBefore(copyChip(value, kind, labelTxt), box);
  }
  function nearestCarrierField(near) {
    var all = document.querySelectorAll("select"), cands = [];
    for (var i = 0; i < all.length; i++) if (carrierIsCarrierSelect(all[i])) cands.push(all[i]);
    if (cands.length) { cands.sort(function (a, b) { return elDist(a, near) - elDist(b, near); }); return cands[0]; }
    return findCarrierCombo(near);
  }
  // Trên trang Complete order: hiện nút carrier + tracking (BẤM ĐỂ COPY) ngay trên 2 ô. Luôn bật.
  // Tim o nhap tracking: theo THUOC TINH, va (du phong) theo NHAN "Tracking number" 
  // (Etsy render "Enter tracking number" khong bang placeholder that nen do theo thuoc tinh co the truot).
  function findTrackingInputs() {
    var out = [], seen = [];
    function add(el) { if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA") && seen.indexOf(el) < 0) { seen.push(el); out.push(el); } }
    var inputs = document.querySelectorAll("input,textarea");
    for (var i = 0; i < inputs.length; i++) {
      var inp = inputs[i];
      var meta = ((inp.placeholder || "") + " " + (inp.name || "") + " " + (inp.getAttribute("aria-label") || "") + " " + (inp.id || "")).toLowerCase();
      if (/track/.test(meta) && !/url|link/.test(meta)) add(inp);
    }
    var labs = document.querySelectorAll("label,span,div,legend,p,h3");
    for (var j = 0; j < labs.length; j++) {
      var el = labs[j]; if (el.children.length) continue;
      var tx = (el.textContent || "").trim().toLowerCase().replace(/\s*\*\s*$/, "");
      if (tx === "tracking number" || tx.indexOf("tracking number") === 0) {
        var box = el;
        for (var up = 0; up < 6 && box; up++) { var ip = box.querySelector && box.querySelector("input,textarea"); if (ip) { add(ip); break; } box = box.parentElement; }
      }
    }
    return out;
  }
  // Nhan (label) khop text muc tieu, GAN nhat voi 1 phan tu (dung cho nhieu don tren cung trang).
  function nearestLabel(near, targets) {
    var all = ((near && near.ownerDocument) || document).querySelectorAll("label,span,div,legend,p,h3,h4");
    var best = null, bestD = 1e9;
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      var tx = (el.textContent || "").trim().toLowerCase().replace(/\s*\*\s*$/, "").replace(/\s+/g, " ");
      var ok = false; for (var k = 0; k < targets.length; k++) if (tx === targets[k]) { ok = true; break; }
      if (!ok) continue;
      var d = near ? elDist(el, near) : 0;
      if (d < bestD) { bestD = d; best = el; }
    }
    return best;
  }
  // Dat nut copy NGAY CANH nhan (cung dong, ho tro iframe).
  function placeChipBeside(labelEl, kind, value) {
    if (!labelEl || !value) return;
    var doc = labelEl.ownerDocument || document; ensureChipStyle(doc);
    var old = labelEl.querySelector('.fp-chip[data-fp-chip="' + kind + '"]'); if (old) old.remove();
    labelEl.appendChild(copyChip(value, kind, doc));
  }
  // Tim moi NHAN khop text (chap nhan co phan tu con nhu dau *), tren TOP + iframe cung origin.
  function findLabels(targets) {
    var res = [], docs = accessibleDocs();
    for (var d = 0; d < docs.length; d++) {
      var all = docs[d].querySelectorAll("label,span,div,legend,p,h3,h4");
      for (var i = 0; i < all.length; i++) {
        var el = all[i];
        var tx = (el.textContent || "").trim().toLowerCase().replace(/\s*\*\s*$/, "").replace(/\s+/g, " ");
        for (var k = 0; k < targets.length; k++) if (tx === targets[k]) { res.push(el); break; }
      }
    }
    return res.filter(function (el) { return !res.some(function (o) { return o !== el && el.contains(o); }); });
  }
  function tryFillTrackingForm() {
    var labs = findLabelsDeep(["tracking number"]); if (!labs.length) return;
    var cLabs = findLabelsDeep(["shipping carrier", "carrier"]);
    for (var i = 0; i < labs.length; i++) {
      var lab = labs[i];
      var id = resolveByText(blockTextDeep(lab));
      if (!id && LASTCLICK && LASTCLICK.id && (Date.now() - (LASTCLICK.at || 0) < 300000)) { var r0 = rec(LASTCLICK.id); if (r0 && r0.hasTracking) id = LASTCLICK.id; }
      if (!id) continue;
      var st = rec(id); if (!st || !st.hasTracking || !st.tracking) continue;
      injectBeside(lab, "tk", st.tracking);
      if (st.carrier) { var labRoot = lab.getRootNode ? lab.getRootNode() : document, caLab = null; for (var c2 = 0; c2 < cLabs.length; c2++) { if ((cLabs[c2].getRootNode ? cLabs[c2].getRootNode() : document) === labRoot) { caLab = cLabs[c2]; break; } } if (!caLab && cLabs.length) caLab = cLabs[0]; if (caLab) injectBeside(caLab, "ca", st.carrier); }
    }
  }
  function scanDomIds() {
    var ids = new Set();
    var els = document.querySelectorAll("a,span,h1,h2,h3,p,div");
    for (var i = 0; i < els.length; i++) {
      var el = els[i]; if (el.children.length) continue;
      var tx = (el.textContent || "").trim();
      var m = tx.match(/#?(\d{8,13})/);
      if (m) ids.add(m[1]);
    }
    return Array.from(ids).slice(0, 300);
  }
  function loadStatus() {
    try {
      chrome.runtime.sendMessage({ type: "status", ids: scanDomIds() }, function (r) {
        if (!r || !r.ok) return;
        STATUS = r.orders || {};
        renderBadges();
      });
    } catch (_) {}
  }
  // Danh sách MỌI đơn đang chờ gán tracking (không phụ thuộc id trên trang hiện tại) — để nhận diện đơn ở trang add-tracking.
  function loadPending(cb) {
    try {
      chrome.runtime.sendMessage({ type: "status", mode: "pending" }, function (r) {
        if (!r || !r.ok) { if (cb) cb(-1); return; }
        PENDING = r.orders || {};
        tryFillTrackingForm();
        if (cb) cb(Object.keys(PENDING).length);
      });
    } catch (_) { if (cb) cb(-1); }
  }
  // Nhận diện đơn KHÔNG đòi hasTracking (cho chẩn đoán) — dùng bản đồ #ID quét từ danh sách theo giá+bang+thành phố.
  function identifyLenient(inp) {
    var ids = Object.keys(ORDERMAP); if (!ids.length) return null;
    var info = pageInfo(pageBlockText(inp)); if (!info.total && !info.city) return null;
    var best = null, bestS = 0, second = 0;
    for (var i = 0; i < ids.length; i++) {
      var e = ORDERMAP[ids[i]], sc = 0;
      if (info.total && e.total && info.total === e.total) sc += 3;
      if (info.state && e.state && info.state.toLowerCase() === e.state.toLowerCase()) sc += 2;
      if (info.city && e.city && info.city.toLowerCase() === e.city.toLowerCase()) sc += 2;
      if (sc > bestS) { second = bestS; bestS = sc; best = ids[i]; } else if (sc > second) second = sc;
    }
    return (best && bestS >= 5 && bestS - second >= 2) ? best : null;
  }
  // Chẩn đoán chi tiết: in số iframe + số nhãn "Tracking number" + kết quả khớp.
  function diagnose() {
    var pend = Object.keys(PENDING).length;
    var roots = deepRoots();
    var labs = findLabelsDeep(["tracking number"]);
    var base = "pend=" + pend + " roots=" + roots.length + " tkLabelsDeep=" + labs.length;
    try { console.log("[FusionPuller] diagnose:", base); } catch (_) {}
    if (!labs.length) { msg("Loaded " + pend + " orders with tracking. Open a Complete order to see the copy buttons beside the fields.", true); return; }
    if (!pend) { msg("No pending orders from server. " + base, false); return; }
    var lab = labs[0];
    var block = (blockTextDeep(lab) || "").slice(0, 80);
    var id = resolveByText(block);
    if (id) { var st = rec(id); if (st && st.hasTracking && st.tracking) { msg("OK #" + id + " " + (st.carrier || "") + " " + st.tracking + " | " + base, true); return; } }
    msg("Label FOUND (deep) but no order match. " + base + " | block='" + block + "'", false);
  }
  function loadOrderMap() { try { chrome.storage.local.get("fp_ordermap", function (o) { ORDERMAP = o.fp_ordermap || {}; }); } catch (_) {} }
  function loadLastClick() { try { chrome.storage.local.get("fp_lastclick", function (o) { LASTCLICK = o.fp_lastclick || null; }); } catch (_) {} }
  // #ID của HÀNG chứa phần tử được click (ancestor nhỏ nhất có ĐÚNG 1 mã đơn).
  function idOfRow(startEl) {
    var node = startEl;
    for (var i = 0; i < 12 && node; i++) {
      var got = null, many = false;
      var q = node.querySelectorAll ? node.querySelectorAll("a,span,div,h3") : [];
      for (var j = 0; j < q.length; j++) { if (q[j].children.length) continue; var mm = (q[j].textContent || "").trim().match(/^#?(\d{8,13})$/); if (mm) { if (got && got !== mm[1]) { many = true; break; } got = mm[1]; } }
      if (many) return null;
      if (got) return got;
      node = node.parentElement;
    }
    return null;
  }
  // Quét #ID + giá/thành phố/bang trên TRANG DANH SÁCH Orders (nơi Etsy hiện #ID) → lưu để trang add-tracking suy ra đúng đơn.
  function harvestOrderMap() {
    try {
      if (!/\/your\/orders\/sold/.test(location.pathname)) return;
      var els = document.querySelectorAll("a,span,div,h3");
      var found = {};
      for (var i = 0; i < els.length; i++) {
        var el = els[i]; if (el.children.length) continue;
        var m = (el.textContent || "").trim().match(/^#?(\d{8,13})$/); if (!m) continue;
        var id = m[1], row = el, txt = "";
        for (var u = 0; u < 8 && row; u++) { row = row.parentElement; if (!row) break; var t = ""; try { t = (row.innerText || "").replace(/\s+/g, " ").trim(); } catch (_) {}
          if (t.length >= 20 && t.length <= 1400) { txt = t; if (/,\s*[A-Za-z]{2,}\b/.test(t) && /\$\s?\d/.test(t)) break; } }
        if (!txt) continue;
        var info = pageInfo(txt); if (!info.total && !info.city) continue;
        found[id] = { total: info.total, city: info.city, state: info.state, at: Date.now() };
      }
      var ks = Object.keys(found); if (!ks.length) return;
      chrome.storage.local.get("fp_ordermap", function (o) {
        var cur = o.fp_ordermap || {};
        for (var k in found) cur[k] = found[k];
        var all = Object.keys(cur);
        if (all.length > 800) { all.sort(function (a, b) { return (cur[b].at || 0) - (cur[a].at || 0); }); var keep = {}; all.slice(0, 800).forEach(function (k) { keep[k] = cur[k]; }); cur = keep; }
        ORDERMAP = cur; try { chrome.storage.local.set({ fp_ordermap: cur }); } catch (_) {}
      });
    } catch (_) {}
  }
  function badgeStyle(st) {
    // Bảng màu + nhãn đồng bộ với pill trạng thái trên FUSION OS (Shipped = đơn đã có tracking)
    var MAP = {
      new:           { t: "New",           bg: "#E3ECF7", fg: "#1D5FAE" },
      created:       { t: "Created",       bg: "#F9EDE2", fg: "#B36A2D" },
      in_production: { t: "In Production", bg: "#E2F0EE", fg: "#2F7D72" },
      shipped:       { t: "Shipped",       bg: "#EEF4E3", fg: "#6E8B3D" },
      delivered:     { t: "Delivered",     bg: "#ECEAF7", fg: "#5E51A8" },
      completed:     { t: "Completed",     bg: "#E8F1EA", fg: "#3F7D53" },
      has_issues:    { t: "Has Issues",    bg: "#F7E7EC", fg: "#B0526C" },
      cancel:        { t: "Cancel",        bg: "#F5EFDD", fg: "#9A8340" },
      trash:         { t: "Cancel",        bg: "#F5EFDD", fg: "#9A8340" },
      out_of_stock:  { t: "Out of stock",  bg: "#F1E9E1", fg: "#8A6D4A" }
    };
    var m = MAP[st.status];
    return m ? { t: m.t, bg: m.bg, fg: m.fg } : { t: st.status, bg: "#EEF2F7", fg: "#5A6272" };
  }
  function findOrderEl(id) {
    var els = document.querySelectorAll("a,span,h1,h2,h3,p");
    for (var i = 0; i < els.length; i++) { var el = els[i]; if (el.children.length) continue; var tx = (el.textContent || "").trim(); if (tx === "#" + id || tx === id || tx === "Order #" + id) return el; }
    for (var j = 0; j < els.length; j++) { var e2 = els[j]; if (e2.children.length) continue; var t2 = (e2.textContent || "").trim(); if (t2.length < 40 && t2.indexOf(id) !== -1) return e2; }
    return null;
  }
  function renderBadges() {
    Object.keys(STATUS).forEach(function (id) {
      var st = STATUS[id];
      var el = findOrderEl(id); if (!el) return;
      if (el.parentNode && el.parentNode.querySelector('[data-fp="' + id + '"]')) return;
      var b = badgeStyle(st);
      var span = document.createElement("span");
      span.className = "fp-badge";
      span.setAttribute("data-fp", id);
      span.style.background = b.bg; span.style.color = b.fg;
      span.textContent = b.t;
      el.insertAdjacentElement("afterend", span);
    });
  }
  function renderTrackList() { /* danh sách bên panel đã bỏ theo yêu cầu — dùng tự-điền inline trên trang add-tracking */ }

  function init() {
    // load saved config
    chrome.storage.local.get("fp_cfg", (o) => {
      const c = o.fp_cfg || {};
      let url = c.url || "";
      // Mặc định domain mới; tự chuyển các cấu hình cũ trỏ vercel sang os.fusiondn.com
      if (!url || url.indexOf("fusionos-sigma.vercel.app") !== -1) {
        url = DEFAULT_INGEST;
        if (url !== c.url) chrome.storage.local.set({ fp_cfg: { url: url, token: c.token || "", autofill: c.autofill !== false } });
      }
      P.querySelector("#fp-url").value = url;
      P.querySelector("#fp-token").value = c.token || "";
      if (!url || !c.token) P.querySelector("#fp-cfg").style.display = "block";
    });

    P.querySelector("#fp-sync").onclick = () => {
      msg("Pushing…", true);
      safeSend({ type: "sync" }, (r) => {
        if (r && r.ok) { msg(`✓ Received ${r.received} — created ${r.created}, updated ${r.updated || 0}, skipped ${r.skipped}`, true); refresh(); return; }
        var e = r && r.error;
        if (e === "__timeout__" || e === "__dead__") {
          // Worker vừa bị đánh thức bởi chính message trên → chờ 1.5s cho nó dậy hẳn rồi TỰ THỬ LẠI 1 lần
          // (server dedupe theo external_id nên lỡ push trùng cũng an toàn).
          msg("Extension is waking up — retrying…", true);
          setTimeout(() => {
            safeSend({ type: "sync" }, (r2) => {
              if (r2 && r2.ok) { msg(`✓ Received ${r2.received} — created ${r2.created}, updated ${r2.updated || 0}, skipped ${r2.skipped}`, true); refresh(); }
              else msg(friendlyErr(r2 && r2.error || "__dead__"), false);
            }, 45000);
          }, 1500);
          return;
        }
        msg(friendlyErr(e || "Unknown"), false);
      }, 45000); // push cả trăm đơn có thể lâu — chờ tới 45s mới coi là treo
    };

    // Push Images: đẩy RIÊNG ảnh của đơn đang mở về Fusion (merge vào đơn đã có). Không đụng các đơn khác.
    { const rb = P.querySelector("#fp-repush"); if (rb) rb.onclick = () => {
      scanBuyerFiles(); // quét lần cuối cho chắc
      const p = LAST_PHOTOS;
      if (!p.orderId || !p.files.length) return msg("No images found — open the order detail page (where images appear), then try again.", false);
      msg(`Pushing ${p.files.length} image(s)…`, true);
      safeSend({ type: "repush-one", orderId: p.orderId, files: p.files }, (r) => {
        if (r && r.ok) msg(`✓ Pushed ${r.photos} image(s) to order ${p.orderId}`, true);
        else msg(friendlyErr(r && r.error || "__dead__"), false);
      }, 45000);
    }; }
    // Chặn Chrome autofill: field readonly lúc tải, bỏ readonly khi người dùng focus để gõ
    ["#fp-url", "#fp-token"].forEach((sel) => { const el = P.querySelector(sel); if (el) { el.addEventListener("focus", () => el.removeAttribute("readonly")); el.addEventListener("blur", () => { if (!el.value) el.setAttribute("readonly", ""); }); } });

    P.querySelector("#fp-save").onclick = () => { chrome.storage.local.set({ fp_cfg: { url: P.querySelector("#fp-url").value.trim(), token: P.querySelector("#fp-token").value.trim() } }, () => msg("✓ Config saved.", true)); };
    { const ls = P.querySelector("#fp-status"); if (ls) ls.onclick = () => { msg("Loading status from FUSION…", true); try { loadStatus(); } catch (_) {} try { harvestOrderMap(); } catch (_) {} try { loadPending(function () { diagnose(); }); } catch (_) {} }; }
    { const rc = P.querySelector("#fp-recap"); if (rc) rc.onclick = () => { var n = 0; try { n = scanEmbedded(); } catch (_) {} msg("Rescanned this page. Scroll through all pages to capture everything.", true); setTimeout(refresh, 500); }; }
    { const cl = P.querySelector("#fp-clear"); if (cl) cl.onclick = () => { safeSend({ type: "clear" }, (r) => { if (r && r.ok) { msg("Cleared the captured list (now 0). Scroll the page to re-capture, then Push.", true); refresh(); } else msg(friendlyErr(r && r.error || "__dead__"), false); }); }; }
    P.querySelector("#fp-min").onclick = () => { P.style.display = "none"; PILL.style.display = "flex"; };
    PILL.onclick = () => { PILL.style.display = "none"; P.style.display = "block"; };

    // Drag to move via the header
    (function drag() {
      const hd = P.querySelector("#fp-hd"); let sx, sy, ox, oy, on = false;
      hd.addEventListener("mousedown", (e) => { if (e.target.id === "fp-min") return; on = true; const r = P.getBoundingClientRect(); ox = r.left; oy = r.top; sx = e.clientX; sy = e.clientY; e.preventDefault(); });
      window.addEventListener("mousemove", (e) => { if (!on) return; P.style.left = (ox + e.clientX - sx) + "px"; P.style.top = (oy + e.clientY - sy) + "px"; P.style.right = "auto"; P.style.bottom = "auto"; });
      window.addEventListener("mouseup", () => { on = false; });
    })();

    refresh(); scanEmbedded(); setTimeout(refresh, 600);
    chrome.runtime.onMessage.addListener((m) => { if (m && m.type === "count-changed") { refresh(); loadStatus(); loadPending(); } });

    // Overlay trạng thái/tracking lên trang Etsy: nạp lần đầu + định kỳ + khi DOM đổi (Etsy là SPA)
    setTimeout(loadStatus, 1500);
    setInterval(loadStatus, 20000);
    setTimeout(loadPending, 1600);
    setInterval(loadPending, 30000);
    loadOrderMap();
    loadLastClick();
    setTimeout(harvestOrderMap, 1700);
    setInterval(harvestOrderMap, 15000);
    document.addEventListener("click", function (ev) { try { if (!/\/your\/orders\/sold/.test(location.pathname)) return; var id = idOfRow(ev.target); if (id) { LASTCLICK = { id: id, at: Date.now() }; chrome.storage.local.set({ fp_lastclick: LASTCLICK }); } } catch (_) {} }, true);
    setInterval(tryFillTrackingForm, 2500);
    setTimeout(scanBuyerFiles, 1800);
    setInterval(scanBuyerFiles, 5000);
    var dbc = null;
    try { new MutationObserver(function () { clearTimeout(dbc); dbc = setTimeout(function () { renderBadges(); tryFillTrackingForm(); scanBuyerFiles(); harvestOrderMap(); }, 700); }).observe(document.body, { childList: true, subtree: true }); } catch (_) {}
  }

  // Đọc ảnh khách upload TRỰC TIẾP TỪ DOM (trang chi tiết đơn) — chắc chắn có URL đầy đủ (i.etsystatic.com/ipf/...).
  // Chỉ đọc DOM mà seller VỐN đã tự mở, không fetch thêm gì. Gửi kèm order_id lấy từ URL trang.
  function scanBuyerFiles() {
    try {
      var m = (location.search || "").match(/order_id=(\d+)/);
      var orderId = m ? m[1] : "";
      if (!orderId) return;
      var imgs = document.querySelectorAll("img.wt-upload__item__thumbnail__image, .perso-upload-thumbnail-container img");
      if (!imgs.length) return;
      var files = [], seen = {};
      for (var i = 0; i < imgs.length; i++) {
        var src = imgs[i].getAttribute("src") || imgs[i].src || "";
        if (!/i\.etsystatic\.com\/ipf\//i.test(src)) continue;
        var url = src.split("#")[0].replace(/ipf_\d+x\d+/i, "ipf_fullxfull"); // thumbnail → ảnh gốc
        if (seen[url]) continue; seen[url] = 1;
        // tên file gốc (IMG_xxx.jpg): tìm .wt-text-truncate gần thumbnail
        var name = "", p = imgs[i];
        for (var up = 0; up < 6 && p; up++) { p = p.parentElement; if (p && p.querySelector) { var tt = p.querySelector(".wt-text-truncate"); if (tt && tt.textContent && tt.textContent.trim()) { name = tt.textContent.trim(); break; } } }
        if (!name) name = url.split("?")[0].split("/").pop();
        name = name.replace(/\s+\d+(\.\d+)?\s*(kb|mb|gb)\s*$/i, "").trim(); // bỏ đuôi dung lượng nếu dính
        files.push({ name: name.slice(0, 150), url: url });
      }
      try { console.log("[FusionPuller] buyer photos scan:", orderId, "found", files.length, files.map(function (f) { return f.name; })); } catch (_) {}
      LAST_PHOTOS = { orderId: orderId, files: files };
      // Hiện số ảnh + nút Push Images lên popup.
      try {
        var el = P && P.querySelector && P.querySelector("#fp-photos");
        if (el) el.textContent = files.length ? ("📷 " + files.length + " customer photo(s) — order " + orderId) : "";
        var rb = P && P.querySelector && P.querySelector("#fp-repush");
        if (rb) rb.style.display = files.length ? "flex" : "none";
      } catch (_) {}
      if (files.length) { try { chrome.runtime.sendMessage({ type: "buyer-files", orderId: orderId, files: files }); } catch (_) {} }
    } catch (_) {}
  }
})();

// ===== Shop health: ĐỌC DOM trang Shop Manager dashboard =====
// Không fetch, không request thêm. Chỉ đọc trang mà seller VỐN ĐÃ tự mở.
// Etsy không thấy bất kỳ hoạt động bất thường nào — vì không có hoạt động nào cả.
//
// Header dashboard có dạng:
//   What's new, WilliamsshopByDallas?
//   ★ 3.3 (48) | 316 sales | 178 active listings
(function () {
  if (!/^\/your\/shops\/me\/dashboard/.test(location.pathname)) return;

  var sent = false;

  function parseDashboard() {
    var txt = (document.body.innerText || "").slice(0, 6000); // header nằm đầu trang
    var out = { sales: null, rating: null, reviews: null, listings: null, age: null };

    // "316 sales" — lấy số lớn nhất, tránh dính widget phụ ghi "0 sales"
    var sales = [];
    var re = /([\d,]+)\s*sales?\b/gi, m;
    while ((m = re.exec(txt))) sales.push(Number(m[1].replace(/,/g, "")));
    if (sales.length) out.sales = Math.max.apply(null, sales);

    // "178 active listings"
    m = txt.match(/([\d,]+)\s*active listings?\b/i);
    if (m) out.listings = Number(m[1].replace(/,/g, ""));

    // "3.3 (48)" — rating kèm số review
    m = txt.match(/([0-5](?:\.\d)?)\s*\(\s*([\d,]+)\s*\)/);
    if (m) { out.rating = Number(m[1]); out.reviews = Number(m[2].replace(/,/g, "")); }

    // "9 months on Etsy" — có thể không có ở view chủ shop
    m = txt.match(/(\d+\s+(?:month|year|day|week)s?)\s+on\s+Etsy/i);
    if (m) out.age = m[1] + " on Etsy";

    return out;
  }

  function trySend() {
    if (sent) return;
    var d = parseDashboard();
    // Chưa render xong thì thôi, MutationObserver sẽ gọi lại
    if (d.sales == null && d.rating == null && d.listings == null) return;
    sent = true;
    // ok: true = đọc được số liệu THẬT từ trang seller đang mở → shop chắc chắn còn sống
    try { chrome.runtime.sendMessage({ type: "shop-health", data: { ok: true, gone: false, status: 200, sales: d.sales, rating: d.rating, reviews: d.reviews, listings: d.listings, age: d.age } }); } catch (_) {}
  }

  // Dashboard render bằng JS → chờ DOM ổn định rồi mới đọc
  setTimeout(trySend, 1500);
  setTimeout(trySend, 4000);
  try {
    var t = null;
    new MutationObserver(function () { clearTimeout(t); t = setTimeout(trySend, 800); })
      .observe(document.body, { childList: true, subtree: true });
  } catch (_) {}
})();
